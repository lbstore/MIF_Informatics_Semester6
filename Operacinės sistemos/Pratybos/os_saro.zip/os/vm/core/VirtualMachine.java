package vu.os.vm.core;

import vu.os.vm.util.Compiler;
import vu.os.vm.core.VirtualRAM;
import vu.os.vm.core.VirtualCPU;
import vu.os.vm.core.io.VirtualDevice;
import vu.os.vm.core.io.InputDevice;
import vu.os.vm.core.io.OutputDevice;
import vu.os.vm.core.io.DataStorageDevice;

import java.util.Scanner;

public class VirtualMachine {

    String runProgram = "data/Programa.pasm";
    String runMode = "S";

    public VirtualMachine() {
    
    }
    
    public void setSource( String program, String mode ) {
        runProgram = program;
        runMode = mode;
    }
    
    public void build() {
        try {
            //Compiler comp = new Compiler();
            //comp.compileBootFile(runProgram, "data/HDD.txt");
            
            VirtualDevice input = new InputDevice();
            VirtualDevice output = new OutputDevice();
            VirtualDevice externalMemory = new DataStorageDevice("data/HDD.txt");
            
            VirtualRAM ram = new VirtualRAM(10000);
            
            VirtualCPU cpu = new VirtualCPU(ram);
           
            cpu.setDevice(0, input);
            cpu.setDevice(1, output);
            cpu.setDevice(2, externalMemory);
            
            while(true) {
                cpu.start(runMode);
                (new Scanner(System.in)).nextLine();
            }
                
        } catch (Exception e) {
            System.out.println(e);
            (new Scanner(System.in)).nextLine();
        }
    }
}