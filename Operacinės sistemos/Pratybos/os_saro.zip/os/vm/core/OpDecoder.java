package vu.os.vm.core;

import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

public class OpDecoder
{
    
    private HashMap<Integer,String> operations = new HashMap<Integer,String>();
    private Set<Integer> keySet = null;
    
    public OpDecoder()
    {
        // --- LOAD ARITHMETICAL OPERATIONS --- //
        // USER RANGE      : 1000-1029
        // SUPERVISOR RANGE: 2000-2029
        operations.put(1000,"AD");
        operations.put(1001,"SB");
        operations.put(1002,"ML");
        operations.put(1003,"DV");
        operations.put(1004,"MD");
        operations.put(1005,"INCR");
        operations.put(1006,"DECR");
        operations.put(1007,"INCU");
        operations.put(1008,"DECU");
        // ------------------------------------ //
        
        // ----- LOAD LOGICAL OPERATIONS ------ //
        // USER RANGE      : 1030-1039
        // SUPERVISOR RANGE: 2030-2039
        operations.put(1030,"CR");
        operations.put(1031,"SHFL");
        operations.put(1032,"SHFR");  
        // ------------------------------------ //
        
        // ------ LOAD DATA OPERATIONS -------- //
        // USER RANGE      : 1040-1069
        // SUPERVISOR RANGE: 2040-2069
        operations.put(1040,"IR");
        operations.put(1041,"IU");
        operations.put(1042,"LR");
        operations.put(1043,"LU");
        operations.put(1044,"SR");
        operations.put(1045,"SU");
        operations.put(1046,"MR");
        operations.put(1047,"MV");
        operations.put(1048,"CB");
        operations.put(1049,"PUSH");
        operations.put(1050,"POP");
        
// vincas : idejau CLRR ir CLRU
        operations.put(1051,"CLRR");
        operations.put(1052,"CLRU");
        
        operations.put(2040,"SD");
        operations.put(2041,"LD");
        // ------------------------------------ //
        
        // ---- LOAD CHANNEL OPERATIONS ------- //
        // USER RANGE      : 1070-1079
        // SUPERVISOR RANGE: 2070-2079
        operations.put(2070,"INP");
        operations.put(2071,"OUT");
        // ------------------------------------ //
        
        // ----- LOAD BRANCH OPERATIONS ------- //
        // USER RANGE      : 1080-1099
        // SUPERVISOR RANGE: 2080-2099
        operations.put(1080,"JP");
        operations.put(1081,"BE");
        operations.put(1082,"BN");
        operations.put(1083,"BG");
        operations.put(1084,"BL");
        operations.put(1085,"LP");
        operations.put(1086,"CL");
        operations.put(1087,"RETP");
        operations.put(1088,"BO");
        
        operations.put(2080,"LJMP");
        operations.put(2081,"LCAL");
        operations.put(2082,"RETL");
        operations.put(2083,"RETI");
        // ------------------------------------ //
        
        // ---- LOAD ADDITIONAL OPERATIONS ---- //
        // USER RANGE      : 1100-1119
        // SUPERVISOR RANGE: 2100-2119
        operations.put(1100,"SI");
        operations.put(1101,"NOP");
        operations.put(1102,"AADR");
        
        operations.put(2100,"USRM");
        operations.put(2101,"HALT");
        // ------------------------------------ //
        
        // ------- SAVE KEY SET --------------- //
        this.keySet = operations.keySet();
        // ------------------------------------ //
    }
    
    // ------- RETURNS OPERATION CODE ----- //
    public int getCode( String word )
    {
        String currentOperation = null;
        
        int operationCode = 0;
        int currentCode;
        
        if( word.length() == 4 )
        {
            boolean opCodeFound = false;
            
            Iterator<Integer> keySetIterator = keySet.iterator();
    
            while( keySetIterator.hasNext() && !opCodeFound )
            {
                currentCode = keySetIterator.next();
                currentOperation = operations.get(currentCode);
                
                if( word.substring(0,currentOperation.length()).equals(currentOperation) )
                {
                    operationCode = currentCode;
                    opCodeFound   = true;
                }
            }
        }
        
        return operationCode;
    }
    // ------------------------------------ //
}