package vu.os.vm.core;

import vu.os.vm.core.VirtualRAM;
import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.core.Constant;

import vu.os.vm.core.io.VirtualDevice;
import vu.os.vm.exceptions.IlleagalAddressException;
import vu.os.vm.exceptions.EmptyMemoryException;
import vu.os.vm.exceptions.IlleagalNumberException;
import vu.os.vm.exceptions.CPUhaltException;
import vu.os.vm.util.Convert;
import vu.os.vm.ui.VirtualMachineGUI;

import vu.os.vm.ui.GUI;

import java.util.HashMap;

import java.util.Scanner;

import vu.os.vm.os.MOSCore;

public class VirtualCPU {

    private MOSCore os = null;


    private VirtualRAM ram = null;
    private CPUchannel[] chn = new CPUchannel[3];
    
    private HashMap<Integer,Register> regs = new HashMap<Integer,Register>(); 
    
    int modeChangeTimer = -1;
    
    VirtualCPUCore core = null;
    //------------------------------------------------------------------------//
    public VirtualCPU( VirtualRAM ram ) {
    
        this.ram = ram;

        regs.put(0,new Register(4));
        regs.put(1,new Register(4));
        regs.put(10,new Register(1));
        regs.put(11,new Register(2));
        regs.put(20,new Register(4));
        regs.put(21,new Register(4));
        regs.put(12,new Register(2));
        regs.put(13,new Register(2));
        regs.put(14,new Register(2));
        regs.put(22,new Register(1));
        regs.put(30,new Register(3));
        regs.put(41,new Register(3));
        regs.put(42,new Register(1));
        regs.put(43,new Register(2));
        regs.put(44,new Register(1));

        for (int i = 0; i < chn.length; i++) {
            chn[i] = new CPUchannel(ram, i, regs.get(30), regs.get(41));
        }
        
        core = new VirtualCPUCore(regs, ram, chn);
        
        GUI.initiateGUI(core);
    }
    
    //========================================================================//
    //== BUILDING & LOADING ==================================================//
    //========================================================================//
    
    public void setDevice( int channel, VirtualDevice device ) {
        chn[channel].setDevice(device); 
    }
    //------------------------------------------------------------------------//
    public void loadRam() throws Exception {
        int bootDevice = 0;
        boolean found = false;
        for (int i = 0; i < chn.length && !found; i++) {
            if (chn[i].isBootable()) {
                bootDevice = i;
                found = true;
            }
        }
        if (found == false) {
            throw new Exception("CPU: BOOT device not found");
        } else {
            String[] page = null;
            page = chn[bootDevice].getDevice().readPage(0);
            
            int bootProgramAddress = Convert.toInt(page[2]);
            int pagesToLoad = Convert.toInt(page[3]);
            
            for (int i = 0; i < pagesToLoad; i++) {
                page = chn[bootDevice].getDevice().readPage(bootProgramAddress + i);
                ram.writePage(i, page);    
            }
        }
        GUI.log("CPU: ram loaded from boot device");
    }
    //------------------------------------------------------------------------//
    public int start( String mode ) throws Exception {
        Object[] keys = regs.keySet().toArray();
        for (int i=0; i<keys.length; i++) {
            regs.get(keys[i]).set("0000");
        }
        loadRam();
        
        core.PTR.set(ram.readWord(0));
        core.DS.set(ram.readWord(1));
        core.SS.set(ram.readWord(1).substring(0, 2));
    
        return run(mode);
    }
    
    //========================================================================//
    //== ALP =================================================================//
    //========================================================================//
    
    //-- RUN -----------------------------------------------------------------//
    
    public int run( String mode ) {
        core.MODE.set(mode);
        int oldIc = 0;
        
        
        try {
            // update GUI
            GUI.updateGUI(Convert.toInt(core.IC));
            //-- INITIATE MAIN LOOP VARS -------------------------------------//
            OpDecoder opd = new OpDecoder();
            
            boolean userMode = false;
            int opCode;
            int icInt;
            int timerInt;
            int intTest;

            String opWord;
            String paramXY;
            String paramY;
            
            GUI.log("CPU: start-up idle.");
            GUI.waitForResponse(Convert.toInt(core.IC));
            GUI.log("CPU: running");
            
            
            String virtualCallStartUp = null;
            virtualCallStartUp = core.longCall(0); 
            if (virtualCallStartUp != null) {
                callVirtualProgram(virtualCallStartUp);
            }
            
            for (int i=0; i<core.chn.length; i++) {
                core.chn[i].start();
            }
            
            //-- MAIN LOOP ---------------------------------------------------//
            while (true) {
                if (test() == 0) {
                    if (modeChangeTimer >= 0) {
                        if (modeChangeTimer == 0) {
                            modeChangeTimer = -1;
                            core.MODE.set("U");
                        }
                        modeChangeTimer --;
                    }
                    
                    icInt = Convert.toInt(core.IC);
                    oldIc = icInt;
                    
                    opWord = ram.readWord( Convert.toAA( icInt, core.PTR, 0, ram ) );
                    
                    icInt ++;
                    core.IC.set(Convert.toWord(icInt));
                    
                    opCode = opd.getCode(opWord);
                    
                    userMode = core.MODE.get().equals("U");
                    
                    if (userMode && opCode >= 2000) {
                        opCode = 0;
                    }    
                    
                    paramXY = opWord.substring(2,4);
                    paramY = opWord.substring(3,4);
                    
                    switch (opCode) {
                        // --- ARITHMETICAL OPERATIONS --- //
                        case 1000: core.AD(paramXY); decTimer(1, userMode);break;
                        case 1001: core.SB(paramXY); decTimer(1, userMode);break;
                        case 1002: core.ML(paramXY); decTimer(1, userMode);break;
                        case 1003: core.DV(paramXY); decTimer(1, userMode);break;
                        case 1004: core.MD(paramXY); decTimer(1, userMode);break;
                        case 1005: core.INCR(); decTimer(1, userMode);break;
                        case 1006: core.DECR(); decTimer(1, userMode);break;
                        case 1007: core.INCU(); decTimer(1, userMode);break;
                        case 1008: core.DECU(); decTimer(1, userMode);break;
                        // ----- LOGICAL OPERATIONS ------ //
                        case 1030: core.CR(paramXY);decTimer(1, userMode); break;
                        case 1031: core.SHFL(); decTimer(1, userMode);break;
                        case 1032: core.SHFR(); decTimer(1, userMode);break;

                        // ------ DATA OPERATIONS -------- //
                        case 1040: core.IR(paramXY); decTimer(1, userMode);break;
                        case 1041: core.IU(paramXY); decTimer(1, userMode);break;
                        case 1042: core.LR(paramXY); decTimer(1, userMode);break;
                        case 1043: core.LU(paramXY); decTimer(1, userMode);break;
                        case 1044: core.SR(paramXY); decTimer(1, userMode);break;
                        case 1045: core.SU(paramXY); decTimer(1, userMode);break;
                        case 1046: core.MR(paramXY); decTimer(1, userMode);break;
                        case 1047: core.MV(paramXY); decTimer(1, userMode);break;
                        case 1048: core.CB(paramXY); decTimer(1, userMode);break;
                        case 1049: core.PUSH(); decTimer(1, userMode);break;
                        case 1050: core.POP(); decTimer(1, userMode);break;
                        case 1051: core.CLRR(); decTimer(1, userMode);break;
                        case 1052: core.CLRU(); decTimer(1, userMode);break;
                        
                        case 2040: core.SD(paramXY); decTimer(1, userMode);break;
                        case 2041: core.LD(paramXY); decTimer(1, userMode);break;
                        // ---- CHANNEL OPERATIONS ------- //
                        case 2070: core.INP(paramY); decTimer(2, userMode); break;
                        case 2071: core.OUT(paramY); decTimer(2, userMode); break;
                        // ----- BRANCH OPERATIONS ------- //
                        
                        case 1080: core.JP(paramXY); decTimer(1, userMode);break;
                        case 1081: core.BE(paramXY); decTimer(1, userMode);break;
                        case 1082: core.BN(paramXY); decTimer(1, userMode);break;
                        case 1083: core.BG(paramXY); decTimer(1, userMode);break;
                        case 1084: core.BL(paramXY); decTimer(1, userMode);break;
                        case 1085: core.LP(paramXY); decTimer(1, userMode);break;
                        case 1086: core.CL(paramXY); decTimer(1, userMode);break;
                        case 1087: core.RETP(); break;
                        case 1088: core.BO(paramXY); decTimer(1, userMode);break;
                    
                        case 2080: core.LJMP(); decTimer(1, userMode);break;
                        case 2081: {
                                    String virtualCall = null; 
                                    virtualCall = core.LCAL(); 
                                    decTimer(2, userMode); 
                                    if (virtualCall != null) {
                                        callVirtualProgram(virtualCall);
                                    }
                                    break;
                                   }
                        case 2082: core.RETL(); decTimer(2, userMode); break;
                        case 2083: core.RETI(); decTimer(2, userMode); break;
                        // ---- ADDITIONAL OPERATIONS ---- //
                        case 1100: core.SI(paramXY); decTimer(3, userMode); break;
                        case 1101: core.NOP();decTimer(1, userMode); break;
                        case 1102: core.AADR();decTimer(1, userMode); break;
                    
                        case 2100: modeChangeTimer = core.USRM(); decTimer(1, userMode);break;
                        case 2101: core.HALT(); decTimer(1, userMode);break;
                        // ------------------------------------ //
                        case 0: core.PI.set(Constant.intIlleagalOPK); break;
                    }
                }
                
                intTest = test();
                if (intTest != 0 && userMode) {
                    //if (core.TIMER.get().equals("9999") && intTest != 4) { System.out.println("TIMER IS 9999!!! 666!!!! test:"+intTest);(new Scanner(System.in)).nextLine();}
                    String virtualCall = null;
                    virtualCall = core.longCall(intTest*2); 
                    if (virtualCall != null) {
                        callVirtualProgram(virtualCall);
                    }
                    
                    //incTimer(1);
                }

                GUI.waitForResponse(oldIc);
            }
            //-- MAIN LOOP ^ -------------------------------------------------//
            
        } catch (CPUhaltException e) {
            GUI.log("\nCPU: " + e.getMessage());
            GUI.log("CPU: Machine is shutting down..");
            GUI.updateGUI(oldIc);
        } catch (Exception e) {
            GUI.log("CPU:"+e);
            System.out.println("CPU:" +e);
            e.printStackTrace();
        }
        //--------------------------------------------------------------------//
        return 0;
    }
    //------------------------------------------------------------------------//
    
    //-- DECREMENT TIMER -----------------------------------------------------//
    
    private void decTimer(int value, boolean userMode) throws IlleagalNumberException {
        if (userMode) {
            int timer = Convert.toInt(core.TIMER);
            for (int i = 0; i < value; i++) {
                if (timer == 0) {
                    core.TI.set(Constant.intTimer);
                } else {
                    timer --;
                }
            }
            core.TIMER.set(Convert.toWord(timer));
        }
    }
    private void incTimer(int value) throws IlleagalNumberException {
        int timer = Convert.toInt(core.TIMER);
        for (int i = 0; i < value; i++) {
            if (timer == 0) {
                core.TI.set(Constant.intTimer);
            }
            timer ++;
        }
        core.TIMER.set(Convert.toWord(timer));
    }
    //-- TEST FOR INTERRUPTS -------------------------------------------------//
    
    public int test() throws IlleagalNumberException {
        int code = 0;
        try {
            if (Convert.toInt(core.IOI.get()) != 0) {
                code = 1;
            } else if (Convert.toInt(core.PI.get()) != 0) {
                code = 2;
            } else if (Convert.toInt(core.SI.get()) != 0) {
                code = 3;
            } else if (Convert.toInt(core.TI.get()) != 0) {
                code = 4;
            }
        } catch (IlleagalNumberException e) {
            new IlleagalNumberException("Interupt register holds not a number");
        }
        return code;
    }
        
    //------------------------------------------------------------------------//
    //-- VIRTUALIZATION ------------------------------------------------------//    
    //------------------------------------------------------------------------//

    private void callVirtualProgram( String word ) {
        GUI.log("CPU: callVirtualProgram");
        try {
            if (!callVirtualProgram(Convert.toInt(word.substring(1,4)))) {
                throw new IlleagalNumberException("virtual program not found: " + word);
            }
        } catch (IlleagalNumberException e) {
            GUI.log("CPU: virtual program call error:");
            GUI.log("CPU: " + e.getMessage());
        }
    }
    
    private boolean callVirtualProgram( int number ) {
        boolean result = true;
        switch (number) {
            case 1: os.IOInt(); break;                  //virtualInteruptIOI(); break;
            case 2: os.PInt(); break;                   //virtualInteruptPI(); break;
            case 3: os.SInt(); break;                   //virtualInteruptSI(); break;
            case 4: os.TInt(); break;                   //virtualInteruptTI(); break;
            case 99: os = new MOSCore(core); break;     //OS START-UP programa
            default: result = false; break;
        }
        return result;
    }

    //------------------------------------------------------------------------//
    //-- VIRTUAL PROGRAMS ----------------------------------------------------//
    // (jei keicia registru reiksmes, jas turi atstatyti)
    //------------------------------------------------------------------------//

    private void virtualInteruptIOI() {
        GUI.log("CPU: IOI interupt");
        String chnByte;
        if (! core.IOI.getByte(0).equals("0")) {
            chnByte = core.IOI.getByte(0);
            if (chnByte.equals(Constant.intIOIerror)) {
                core.cpuHalt("IOI: channel 0 error");    
            }
            core.IOI.setByte(0,"0");
        } else if (! core.IOI.getByte(1).equals("0")) {
            chnByte = core.IOI.getByte(1);
            if (chnByte.equals(Constant.intIOIerror)) {
                core.cpuHalt("IOI: channel 1 error");    
            }
            core.IOI.setByte(1,"0");
        } else if (! core.IOI.getByte(2).equals("0")) {
            chnByte = core.IOI.getByte(2);
            if (chnByte.equals(Constant.intIOIerror)) {
                core.cpuHalt("IOI: channel 2 error");    
            }
            core.IOI.setByte(2,"0");
        }
    }
    
    private void virtualInteruptPI() {
        GUI.log("CPU: PI interupt");
        int pi = 0;
        try {
            pi = Convert.toInt(core.PI);
        } catch (IlleagalNumberException e) {
            core.cpuHalt(e.toString());
        }
        switch (pi) {
            case 1:
                core.cpuHalt("PI: Division by zero");
                break;
            case 2:
                core.cpuHalt("PI: Illeagal OPK");
                break;
            case 3:
                core.cpuHalt("PI: Illeagal stack memory");
                break;
            case 4:
                core.cpuHalt("PI: Illeagal memory");
                break;
            case 5:
                core.cpuHalt("PI: Empty memory");
                break;
            case 6:
                core.cpuHalt("PI: Channel is busy");
                break;
            case 7:
                core.cpuHalt("PI: Illeagal Operation parameter");
                break;
        }
        core.PI.set(Constant.intNone);
    }
    
    private void virtualInteruptSI() {
        GUI.log("CPU: SI interupt");
        int si = 0;
        try {
            si = Convert.toInt(core.SI);
        } catch (IlleagalNumberException e) {
            core.cpuHalt(e.toString());
        }
        switch (si) {
            case 1:
                core.cpuHalt("SI: exit program");
                break;
            case 10:
            {
                String u = core.U.get();
                String r = core.R.get();

                core.AADR();
                core.SHFR();
                core.CLRU();
                core.IU("01");
                core.OUT("1");
                
                core.U.set(u);
                core.R.set(r);
            }
                break;
            case 11:
            {
                String u = core.U.get();
                String r = core.R.get();
                
                
                core.AADR();
                core.SHFR();
                core.CLRU();
                core.IU("01");
                core.INP("0");
                
                core.U.set(u);
                core.R.set(r);
            }
                break;
        }
        core.SI.set(Constant.intNone);
    }
    
    private void virtualInteruptTI() {
        GUI.log("CPU: TI interupt");
        core.TI.set(Constant.intNone);
    }
}