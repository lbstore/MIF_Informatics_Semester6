package vu.os.vm.core;


public class Constant {
    public static final String intNone =                 "0000";
    // IOI
    //0 � n�ra, 1 � operacija baigta  2 � klaida, 3 � i�orinis �renginio pertraukimas): 
    public static final String intIOIok =               "1";
    public static final String intIOIerror =            "2";
    public static final String intIOIIRQ =              "3";
    // PI
    public static final String intDivByZero =            "0001";
    public static final String intIlleagalOPK =          "0002";
    public static final String intIlleagalStackMemory =  "0003"; 
    public static final String intIlleagalMemory =       "0004"; 
    public static final String intEmptyMemory =          "0005";
    public static final String intChannelBusy =          "0006";    
    public static final String intIlleagalOpParameter =  "0007";
    // SI
    public static final String intHaltProgram =          "0001";
    public static final String intOutputData =           "0010";
    public static final String intInputData =            "0011";
    // TI
    public static final String intTimer =                "0001";
    
    //C:
    public static final String valueEqual =        "0";
    public static final String valueLess =         "1";
    public static final String valueMore =         "2";
    public static final String valueOverflow =     "4";
}