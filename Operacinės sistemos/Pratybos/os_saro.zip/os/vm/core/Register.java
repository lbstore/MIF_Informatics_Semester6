package vu.os.vm.core;

import java.util.Arrays;

public class Register {
    private static final int maxLength  = 4;                                    //max register size
    private char [] bytes               = null;                                 //array
    private int size                    = 0;                                    //current size

    public Register(int size) {                                                    
        if (size < maxLength) {
            this.size = size;
            bytes = new char[size];
        } else {
            this.size = maxLength;
            bytes = new char[maxLength];
        }
        Arrays.fill(bytes, '0');
        
        //System.out.println("REGISTER:::: "+new String(bytes));
    }
    
    // is value paima paskutinius simbolius. 2B registras: string:"1234abcd" -> reg:"cd"
    public void set (String value) { 
        int i, j;
        if (value.length() < size) {
            for(i = size - value.length(), j = 0; i < size; i++, j++) {
                bytes[i] = value.charAt(j);
            }
        } else {
            for (j = value.length() - size, i = 0; i < size; i++, j++) {                 //adding string to char[]
                bytes[i] = value.charAt(j);                                         //str[0] -> char[0], str[1] -> char[1] and so on.. 
            }
        }
    }
    
    public void set (Register r) {
        this.set(r.toString());
    }
    
    public String get () {
        return this.toString();
    }
    
    public String toString () {                                                //converts char[] to 4 symb String
        return new String(bytes);      
    }
    
    public void setByte (int index, String value) {
        bytes[size-index-1] = value.charAt(0);
    }

    public String getByte (int index) {
        return Character.toString(bytes[size-index-1]);
    }    
    
    public Register getCopy () {
        Register copy = new Register(this.size);
        copy.set(this);
        return copy;
    }
}