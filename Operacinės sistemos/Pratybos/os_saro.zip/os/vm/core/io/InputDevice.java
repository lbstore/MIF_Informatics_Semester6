package vu.os.vm.core.io;

import vu.os.vm.core.io.VirtualDevice;
import vu.os.vm.exceptions.VirtualDeviceException;
import vu.os.vm.util.WindowsLib;

import java.util.Arrays;
import java.util.Scanner;
import java.io.IOException;

public class InputDevice extends VirtualDevice {

    private static final char endOfString = '$';
    private WindowsLib winLib = new WindowsLib();
    private boolean IRQ_done = false;
    
    public InputDevice() {
    }
    
    // ivedimui naudojamas adresas 1 
    
    public String[] readPage( int address ) throws VirtualDeviceException{
        // output page
        if (address == 1) {

            String buffer = null;
            Scanner in = new Scanner(System.in);
            buffer = in.nextLine();
            
            if (buffer.length() < 40) {
                char[] emptySpace = new char[40-buffer.length()];
                Arrays.fill(emptySpace, endOfString);
                buffer += new String(emptySpace);
            }
            
            String[] page = new String[10];
            for (int i=0; i<10; i++) {
                page[i] = buffer.substring(i*4,(i+1)*4);
            }
            return page;
            
        // interrupt page
        } else if (address == 2) {
            
            char[] charBuffer = new char[40];
            int count = 0;

            while ( winLib.inputBufferIsCharAvailable() && (count < 40) ) {
                //System.out.print("INPUTDEVICE IRQ: send a char ...");
                charBuffer[count] = winLib.inputBufferGetChar();
                //System.out.println(" char got.");
                count++;   
            }
            
            for (int i=count; i<40; i++) {
                charBuffer[i] = endOfString;
            }

            String buffer = new String(charBuffer);
            
            String[] page = new String[10];
            for (int i=0; i<10; i++) {
                page[i] = buffer.substring(i*4,(i+1)*4);
            }
            
            IRQ_done = false;
            
            return page;
            
        // device page
        } else if (address == 0) {

            String[] page =    {"INPT",
                                "0002",
                                "0001",
                                "0001",
                                "Keyb",
                                "oard",
                                "0000",
                                "0000",
                                "0001",
                                "0002"};
            return page;
        } else {
            throw new VirtualDeviceException("InputDevice: Unreadable memmory address: " + address);
        }
    }
    
    public void writePage( int address, String[] page ) throws VirtualDeviceException {
        throw new VirtualDeviceException("InputDevice: Cannot write to memmory!");
    }
    
    public boolean isBootable() {
        return false;
    }
    
    public int getMemorySize() {
        return 3;
    }
    
    public boolean interruptReguested() {
        boolean irq = false;
        if (winLib.inputBufferIsCharAvailable() && !IRQ_done) {
            IRQ_done = true;
            irq  = true;
        }
        return irq;
    }
}