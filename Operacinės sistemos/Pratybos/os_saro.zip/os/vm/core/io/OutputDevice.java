package vu.os.vm.core.io;

import vu.os.vm.core.io.VirtualDevice;
import vu.os.vm.exceptions.VirtualDeviceException;

public class OutputDevice extends VirtualDevice {
    private static final String newLine = "�";
    private static final char endOfString = '$';
    public OutputDevice() {
    }

    public String[] readPage( int address ) throws VirtualDeviceException {
        if (address == 0) {
            String[] page =    {"OUTP",    
                                "0001",
                                "0001",
                                "0000",
                                "Scre",
                                "en  ",
                                "0000",
                                "0001",
                                "0000",
                                "0000"};
            return page;
        } else {
            throw new VirtualDeviceException("OutputDevice: Unreadable memmory address: " + address);
        }
    }
    // isvedimui naudojamas adresas 1
    public void writePage( int address, String[] page ) throws VirtualDeviceException {
        if (address == 1) {
            String toPrint = new String();
            for (int i=0; i<10; i++) {
                toPrint += page[i];
            }
            
            boolean foundEndOfString = false;
            int endPosition = 0;
            
            for (int i=0; i<toPrint.length() && !foundEndOfString; i++) {
                if (toPrint.charAt(i) == endOfString) {
                    foundEndOfString = true;
                    endPosition = i;
                    
                }
            }
            
            if (foundEndOfString) {
                toPrint = toPrint.substring(0,endPosition);
            }
            
            toPrint = toPrint.replaceAll(newLine, "\n");
            
            System.out.print(toPrint);
        } else {
            throw new VirtualDeviceException("InputDevice: Unwritable memmory address: " + address);
        }
    }
    public boolean isBootable() {
        return false;
    }
    
    public int getMemorySize() {
        return 2;
    }
    
    public boolean interruptReguested() {
        return false;
    }
}