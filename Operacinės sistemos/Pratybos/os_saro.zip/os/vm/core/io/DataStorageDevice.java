package vu.os.vm.core.io;

import vu.os.vm.core.io.VirtualDevice;
import vu.os.vm.exceptions.VirtualDeviceException;
import java.io.File;
import java.lang.Integer;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.RandomAccessFile;


public class DataStorageDevice extends VirtualDevice {
    private static final int pageSize    = 10;       //pageSize in lines
    private static final int lineLength  = 4;         //line length without entersymbol (in bytes)
    private File source                  = null;
    private int size                     = 0;         // file size in pages (lines div 10) 
    private int enterLength              = 0;         // if enter 2B 2, 1B 1 (enter size in bytes)
    private byte [] enterInBytes         = null;      // "enter" key bytes
    
    public DataStorageDevice( String filename ) throws VirtualDeviceException {
        source = new File(filename);
        if (!(source != null && source.isFile() && source.canRead() && source.canWrite())) {
            throw new VirtualDeviceException("DataStorageDevice: Invalid source: " + filename);
        }

        if (!(this.sizeIsCorrect())) {
            throw new VirtualDeviceException("DataStorageDevice: Memory size set != real memory size");
        }
        
        this.setEnterSize();
    }
    
    
    // method counts enter key (enterLength ) size and put values into array of enter simbols (enterInBytes)
    private void setEnterSize() throws VirtualDeviceException {

        RandomAccessFile hdd = null;
        int i = 0, b;
        byte firstB;
        try {
            hdd = new RandomAccessFile(source, "r");
        } catch (Exception e) {
            throw new VirtualDeviceException("DataStorageDevice: Unable to read");
        }
        try{
            while (true) {
                b = hdd.read();
                i++;

                if (b == 13) {                                              //CR
                    firstB = (byte) b;
                    if (hdd.read() == 10) {                                 //LF
                        i++;
                }
                    break;
                }

                if (b == 10) {                                              //LF
                    firstB = (byte) b;
                    break;
                }
            } 

            enterLength = i - lineLength;
            enterInBytes = new byte[enterLength];
            enterInBytes[0] = firstB;
            if (enterLength == 2) {
                enterInBytes[1] = 10;
            }
            hdd.close();
        } catch (Exception e) {
            throw new VirtualDeviceException("DataStorageDevice: Unable to read");
        }
    }

    //cheks file real lenght and added lenght in 2 line of file
    
    private boolean sizeIsCorrect() throws VirtualDeviceException {
        FileReader fileReader           = null;
        BufferedReader hdd              = null;

        try {
            fileReader = new FileReader(source);
            hdd = new BufferedReader(fileReader);
        } catch (Exception e) {
            throw new VirtualDeviceException("DataStorageDevice: Unable to read");
        }

        String line, hddSize = "####";
        int numbOfLines = 0;
        try {
            while ((line = hdd.readLine()) != null) {
                numbOfLines++;       
                if (numbOfLines == 2) {
                    hddSize = line; 
                }
            }
            hdd.close();
        } catch (Exception e) {
            throw new VirtualDeviceException("DataStorageDevice: Failed while reading");
        }

        try {
            size = Integer.parseInt(hddSize);
        } catch (NumberFormatException e) {
            throw new VirtualDeviceException("DataStorageDevice: Unable to identify size (not a number)");
        }
        
        if (((numbOfLines % pageSize) == 0) && ((size+1) == (numbOfLines / pageSize))) {
            return true;
        } else {
            return false;
        }
        
    }
    
    // read one page (default 10 lines) from DataStorageDevice (hdd)
    
    public String[] readPage( int address ) throws VirtualDeviceException {
        String [] page = new String[pageSize];
        int i;
        
        if ((address >= 0) && (address <= size)) {
            FileReader fileReader            = null;
            BufferedReader hdd                = null;
        
            try {
                fileReader = new FileReader(source);
                hdd = new BufferedReader(fileReader);
            } catch (Exception e) {
                throw new VirtualDeviceException("DataStorageDevice: Unable to read");
            }
            i = 0;
            try {
                while (i < (address * pageSize)) {
                    i++;
                    hdd.readLine();
                }
                for (i=0; i < pageSize; i++) {
                    page[i] = hdd.readLine();
                }
                hdd.close();
                fileReader.close();
            } catch (Exception e) {
                throw new VirtualDeviceException("DataStorageDevice: Failed while reading");
            }
           

        } else {
            for (i = 0; i < pageSize; i++) {
                page[i] = "0000";
            }
        
        }
        

        return page;  
    }
    
    // write one page (default 10 lines) to DataStorageDevice (hdd)
    
    public void writePage( int address, String[] page ) throws VirtualDeviceException {

        int i;
        if ((address >= 0) && (address <= size)) {
            RandomAccessFile hdd = null;

            try {
                hdd = new RandomAccessFile(source, "rw");
            } catch (Exception e) {
                throw new VirtualDeviceException("DataStorageDevice: Unable to open for writing");
            }
            
            try {
                int addressInBytes = (lineLength + enterLength) * pageSize * address;
                int hddSizeInBytes = (lineLength + enterLength) * pageSize * (size+1);
                hdd.seek(addressInBytes);

                for(i = 0; i < pageSize; i++) {
                    if (( ((i*(lineLength + enterLength)) + addressInBytes)) != (hddSizeInBytes - (lineLength + enterLength))) {
                        hdd.writeBytes(page[i]+new String(enterInBytes));
                    } else {
                        hdd.writeBytes(page[i]);
                    }
                } 
                hdd.close();    
            } catch (Exception e) {
                throw new VirtualDeviceException("DataStorageDevice: Unable to write");
            }
        } else {
            throw new VirtualDeviceException("DataStorageDevice: Unable to write");
        }
    }
    
    //cheks if 1 line is "BOOT"
    
    public boolean isBootable() throws VirtualDeviceException {
        
        FileReader fileReader            = null;
        BufferedReader hdd                = null;
        
        String line = "";
        
        try {
            fileReader = new FileReader(source);
            hdd = new BufferedReader(fileReader);
        } catch (Exception e) {
            throw new VirtualDeviceException("DataStorageDevice: Unable to read");
        }    
        
        try {
            line = hdd.readLine();
            hdd.close();
            fileReader.close();
        } catch (Exception e) {
            throw new VirtualDeviceException("DataStorageDevice: Failed while reading");
        }

 
        
        if (line.equals("BOOT")) {
            return true;
        } else {
            return false;
        }        

    }

    //retuns DataStorageDevice size in pages
    
    public int getMemorySize() {
        return size;
    }
    
    public boolean interruptReguested() {
        return false;
    }
}