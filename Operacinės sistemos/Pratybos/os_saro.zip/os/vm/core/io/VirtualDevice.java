package vu.os.vm.core.io;

import vu.os.vm.exceptions.VirtualDeviceException;

public abstract class VirtualDevice {
    abstract public String[] readPage( int address ) throws VirtualDeviceException;
    abstract public void writePage( int address, String[] page ) throws VirtualDeviceException;
    abstract public boolean isBootable() throws VirtualDeviceException;
    abstract public int getMemorySize();
    abstract public boolean interruptReguested();
}