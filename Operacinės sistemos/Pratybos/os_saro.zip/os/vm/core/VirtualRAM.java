package vu.os.vm.core;

// ADRESACIJA ABSOLIUTI!
// zodzius imam zodziu adresais (zodis 0, zodis 1..)
// puslapius puslapiu adresais (puslapis 0, puslapis 1..

import vu.os.vm.exceptions.IlleagalAddressException;
import java.util.Arrays;

public class VirtualRAM {
        
    private String[] memory = null;
    private int size        = 0;
    
    public VirtualRAM( int sizeWords ) {
        this.size = sizeWords;
        memory = new String[sizeWords];
        for (int i = 0; i < sizeWords; i++) {
            memory[i] = new String("0000");
        }
    }
    
    public String correctWord( String source ) {
        String word = null;
        if (source.length() < 4) {
            char[] emptySpace = new char[4 - source.length()];
            Arrays.fill(emptySpace, '0');
            word = new String(emptySpace) + source;
        } else if (source.length() > 4) {
            word = source.substring(source.length() - 4, source.length());    
        } else {
            word = source;
        }
        return new String(word);
    }
    
    public void writeWord( int wordAddress, String word ) throws IlleagalAddressException {
        try {
            memory[wordAddress] = correctWord(word);
        } catch (Exception e) {
            throw new IlleagalAddressException("RAM: Invalid word address: " + wordAddress);
        }
    }

    public String readWord( int wordAddress ) throws IlleagalAddressException {
        try {
            return new String(memory[wordAddress]);
        } catch (Exception e) {
            throw new IlleagalAddressException("RAM: Invalid word address: " + wordAddress);
        }
    }

    public void writePage( int pageAddress, String[] page ) throws IlleagalAddressException {
        try {
            for (int i = 0; (i < 10) && (i < page.length); i++) {
                memory[pageAddress*10+i] = correctWord(page[i]);
            }
        } catch (Exception e) {
            throw new IlleagalAddressException("RAM: Invalid page address: " + pageAddress);
        }
    }
    
    public String[] readPage( int pageAddress ) throws IlleagalAddressException {
        try {
            String[] page = new String[10];
            for (int i = 0; i < 10; i++) {
                page[i] = memory[pageAddress*10+i];
            }
            return page;
        } catch (Exception e) {
            throw new IlleagalAddressException("RAM: Invalid page address: " + pageAddress);
        }
    }
    
    public int size() {
        return size;
    }
}