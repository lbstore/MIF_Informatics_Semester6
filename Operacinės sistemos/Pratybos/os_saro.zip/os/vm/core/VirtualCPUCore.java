package vu.os.vm.core;

import vu.os.vm.core.VirtualRAM;
import vu.os.vm.core.Constant;

import vu.os.vm.exceptions.IlleagalAddressException;
import vu.os.vm.exceptions.EmptyMemoryException;
import vu.os.vm.exceptions.IlleagalNumberException;
import vu.os.vm.exceptions.CPUhaltException;
import vu.os.vm.util.Convert;

import java.util.HashMap;

public class VirtualCPUCore {

    public HashMap <Integer, Register> regs = null;
    public VirtualRAM                  ram = null;

    public Register R = null;
    public Register U = null;
    public Register C = null;
    public Register IC = null;
    public Register DS = null;
    public Register SS = null;
    public Register SP = null;
    public Register TIMER = null;
    public Register MODE = null;
    public Register PTR = null;
    public Register PI = null;
    public Register SI = null;
    public Register TI = null;
    public Register CAST = null;
    public Register IOI = null;
    
    public CPUchannel[] chn = null;

    public VirtualCPUCore(HashMap <Integer, Register> regs, VirtualRAM ram, CPUchannel[] channels) {
        this.regs = regs;
        this.ram = ram;
        
        R   = regs.get(0);
        U   = regs.get(1);
        C   = regs.get(10);
        IC  = regs.get(11);
        PTR = regs.get(20);
        TIMER = regs.get(21);
        DS  = regs.get(12);
        SS  = regs.get(13);
        SP  = regs.get(14);
        MODE = regs.get(22);
        CAST = regs.get(30);
        IOI = regs.get(41);
        PI  = regs.get(42);
        SI  = regs.get(43);
        TI  = regs.get(44);
        
        this.chn = channels;
    }

    //========================================================================//
    //-- STACK ---------------------------------------------------------------//
    //========================================================================//
    
    public void stackPush(Object objWord, Register stackPointer, Object objPtrValue, Object objStackSegment) 
        throws IlleagalNumberException, IlleagalAddressException, EmptyMemoryException 
    { 
        Register ptrValue, segment;      
        
        ptrValue = new Register(4);
        ptrValue.set(objPtrValue.toString());
        
        segment = new Register(2);
        segment.set(objStackSegment.toString());
        
        stackPush(objWord.toString(), stackPointer, ptrValue, segment);    
    }
    
    public void stackPush(String word, Register stackPointer, Register ptrValue, Register stackSegment) 
        throws IlleagalNumberException, IlleagalAddressException, EmptyMemoryException 
    { 
        int sp = Convert.toInt(stackPointer.get());
        ram.writeWord(Convert.toAA(sp, ptrValue, stackSegment, ram), word);
        sp++;
        stackPointer.set(Convert.toWord(sp));       
    }

    public String stackPop(Register stackPointer, Object objPtrValue, Object objStackSegment) 
        throws IlleagalNumberException, IlleagalAddressException, EmptyMemoryException 
    {
        Register ptrValue, segment;
        
        ptrValue = new Register(4);
        ptrValue.set(objPtrValue.toString());
        
        segment = new Register(2);
        segment.set(objStackSegment.toString());

        return stackPop(stackPointer, ptrValue, segment);
    } 
    
    public String stackPop(Register stackPointer, Register ptrValue, Register stackSegment) 
        throws IlleagalNumberException, IlleagalAddressException, EmptyMemoryException 
    {
        String wordS = "";

        int word = Convert.toInt(stackPointer.get());
        word--;
        if (word < 0) {
            throw new IlleagalAddressException("stackPop: SP < 0");
        }
        wordS = ram.readWord(Convert.toAA(word, ptrValue, stackSegment, ram));
        stackPointer.set(Convert.toWord(word));
        
        return wordS;
    } 
    
    //========================================================================//
    //== OPK =================================================================//
    //========================================================================//
    
    //------------------------------------------------------------------------//
    // Vincas: Aritmetines komandos, Logines komandos, Komandos su kanalais, POP PUSH
    // Tautvydas: Sakojimolsi komandos
    // Mindaugas: Komandos su duomenimis, Papildomos komandos
    //------------------------------------------------------------------------//
    
    //========================================================================//
    //-- ARITMETINES KOMANDOS ------------------------------------------------//
    //========================================================================//
    
    //-- AD ------------------------------------------------------------------//
    
    public void AD( String xy ) {
        try {
            int word = Convert.toInt(ram.readWord(Convert.toAA(Convert.toInt(xy), PTR, DS, ram)));
            int r = Convert.toInt(R);
            int result = r + word;
            if (result > 9999) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //-- SB ------------------------------------------------------------------//

    public void SB( String xy ) {
        try {
            int word = Convert.toInt(ram.readWord(Convert.toAA(Convert.toInt(xy), PTR, DS, ram)));
            int r = Convert.toInt(R);
            int result = r - word;
            if (result < 0) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //-- ML ------------------------------------------------------------------//

    public void ML( String xy ) {
        try {
            int word = Convert.toInt(ram.readWord(Convert.toAA(Convert.toInt(xy), PTR, DS, ram)));
            int r = Convert.toInt(R);
            int result = r * word;
            if (result > 9999) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //-- DV ------------------------------------------------------------------//

    public void DV( String xy ) {
        try {
            int word = Convert.toInt(ram.readWord(Convert.toAA(Convert.toInt(xy), PTR, DS, ram)));
            int r = Convert.toInt(R);
            
            if (word == 0) {
                PI.set(Constant.intDivByZero);
            } else {
                int result = r / word;
                if (result > 9999) { 
                    C.set(Constant.valueOverflow); 
                }
                R.set(Convert.toWord(result));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //-- MD ------------------------------------------------------------------//

    public void MD( String xy ) {
        try {
            int word = Convert.toInt(ram.readWord(Convert.toAA(Convert.toInt(xy), PTR, DS, ram)));
            int r = Convert.toInt(R);
            int result = r % word;
            if (result > 9999) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //-- INCR ----------------------------------------------------------------//

    public void INCR() {
        try {
            int r = Convert.toInt(R);
            int result = r + 1;
            if (result > 9999) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //-- DECR ----------------------------------------------------------------//

    public void DECR() {
        try {
            int r = Convert.toInt(R);
            int result = r - 1;
            if (result > r) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //-- INCU ----------------------------------------------------------------//
    
    public void INCU() {
        try {
            int u = Convert.toInt(U);
            int result = u + 1;
            if (result > 9999) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //-- DECU ----------------------------------------------------------------//
    
    public void DECU() {
        try {
            int u = Convert.toInt(U);
            int result = u - 1;
            if (result > u) { 
                C.set(Constant.valueOverflow); 
            }
            R.set(Convert.toWord(result));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } 
    }
    
    //========================================================================//
    //-- LOGINES KOMANDOS ----------------------------------------------------//
    //========================================================================//
    
    //-- CR ------------------------------------------------------------------//
    
    public void CR( String xy ) {
        try {
            String word = ram.readWord(Convert.toAA(Convert.toInt(xy), PTR, DS, ram));
            if (R.get().equals(word)) {
                C.set(Constant.valueEqual);
            } else {
                int wordInt;
                int rInt;
                
                try {
                    wordInt = Convert.toInt(word);
                    rInt = Convert.toInt(R);
                } catch (IlleagalNumberException e) {
                    String r = R.get();
                    
                    byte[] wordBytes = word.getBytes();
                    byte[] rBytes = r.getBytes();
                    
                    wordInt = wordBytes[0] * 1000 + 
                              wordBytes[1] * 100 +
                              wordBytes[2] * 10 +
                              wordBytes[3];
                                  
                    rInt =    rBytes[0] * 1000 + 
                              rBytes[1] * 100 +
                              rBytes[2] * 10 +
                              rBytes[3];
                }
                
                if (rInt < wordInt) {
                    C.set(Constant.valueLess);
                } else if (rInt > wordInt) {
                    C.set(Constant.valueMore);
                }
            }
        } catch(IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }
    }
    
    //-- SHFL ----------------------------------------------------------------//
    
    public void SHFL() {
        String r = R.get();
        r = r.substring(1,4) + "0";
        R.set(r);
    }
    
    //-- SHFR ----------------------------------------------------------------//

    public void SHFR() {
        String r = R.get();
        r = "0" + r.substring(0,3);
        R.set(r);
    }
    
    //========================================================================//
    //-- KOMANDOS SU DUOMENIMIS ----------------------------------------------//
    //========================================================================//
    
    //-- IR ------------------------------------------------------------------//
    // R <-- xy
    
    public void IR( String xy ){
        R.set(xy);
    }

    //-- IU ------------------------------------------------------------------//
    // U <-- xy
    
    public void IU( String xy ){
        U.set(xy);
    }

    //-- LR ------------------------------------------------------------------//
    // R <-- [xy]
    
    public void LR( String xy ){
        try{
            int address = Convert.toAA( Convert.toInt(xy) , PTR , DS, ram );
            R.set(ram.readWord(address));
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

    //-- LU ------------------------------------------------------------------//
    // U <-- [xy]
    
    public void LU( String xy ){
        try{
            int address = Convert.toAA( Convert.toInt(xy) , PTR , DS, ram );
            U.set(ram.readWord(address));
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

    //-- SR ------------------------------------------------------------------//
    // [xy] <- R
    
    public void SR( String xy ){
        try{
            int address = Convert.toAA( Convert.toInt(xy) , PTR , DS, ram );
            ram.writeWord( address , R.toString() );
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

    //-- SU ------------------------------------------------------------------//
    // [xy] <- U
    
    public void SU( String xy ){
        try{
            int address = Convert.toAA( Convert.toInt(xy) , PTR , DS, ram );
            ram.writeWord( address , U.toString() );
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

    //-- SD ------------------------------------------------------------------//
    // [R] <- [xy]
    
    public void SD( String xy ){
        try{
            int address1 = Convert.toAA( Convert.toInt(xy) , PTR , DS, ram );
            int address2 = Convert.toInt(R);       
            ram.writeWord( address2 , ram.readWord(address1) );
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

    //-- LD ------------------------------------------------------------------//
    // [xy] <- [R]
    
    public void LD( String xy ){
        try{
            int address1 = Convert.toInt(R);                          
            int address2 = Convert.toAA( Convert.toInt(xy) , PTR , DS, ram );
            ram.writeWord( address2 , ram.readWord(address1) );
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

    //-- MR ------------------------------------------------------------------//
    // R <- value in register xy
    
    public void MR( String xy ){
        try{
            int registerNr = Convert.toInt(xy);
            if( MODE.get().equals("U") ){
                if( registerNr <= 19 && regs.containsKey(registerNr) ){
                    R.set( regs.get(registerNr) );
                } else { 
                    PI.set(Constant.intIlleagalOpParameter);
                }
            }
            else if( MODE.get().equals("S") ){
                if( registerNr <= 99 && regs.containsKey(registerNr) ){
                    R.set( regs.get(registerNr) );
                }else{
                    PI.set(Constant.intIlleagalOpParameter);
                }
            }
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    //-- MV ------------------------------------------------------------------//
    // register identified by xy <- R
    
    public void MV( String xy ){
        try{
            int registerNr = Convert.toInt(xy);
            if( MODE.get().equals("U") ){
                if( registerNr <= 19 && regs.containsKey(registerNr)){
                    regs.get(registerNr).set(R);
                }else{
                    PI.set(Constant.intIlleagalOpParameter);
                }
            }
            else if( MODE.get().equals("S") ){
                if( regs.containsKey(registerNr) ){
                    regs.get(registerNr).set(R);
                }else{
                    PI.set(Constant.intIlleagalOpParameter);
                }
            }
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //-- CB ------------------------------------------------------------------//
    
    public void CB( String xy ){
        try{
            Register params = new Register(4);
            params.set(stackPop(SP,PTR,SS));
            stackPush(params,SP,PTR,SS);
            
            int sourceRegNr = Convert.toInt(xy);
            int destinationRegNr = Convert.toInt( params.get().substring(0,2) );
            int byteToCopy = Convert.toInt(params.getByte(1));
            int byteToPaste = Convert.toInt(params.getByte(0));
            if( regs.get(sourceRegNr).toString().length() > byteToCopy &&
                regs.get(destinationRegNr).toString().length() > byteToPaste)
            {
                if( MODE.get().equals("U") ){
                    if( sourceRegNr <= 19 && destinationRegNr <= 19 && 
                        regs.containsKey(sourceRegNr) && regs.containsKey(destinationRegNr) )
                    {
                        regs.get(destinationRegNr).setByte( byteToPaste , regs.get(sourceRegNr).getByte(byteToCopy) );
                    }
                    else{
                        PI.set(Constant.intIlleagalOpParameter);
                    }
                }
                else if( MODE.get().equals("S") ){
                    if( regs.containsKey(sourceRegNr) && regs.containsKey(destinationRegNr) ){
                        regs.get(destinationRegNr).setByte( byteToPaste , regs.get(sourceRegNr).getByte(byteToCopy) );
                    }
                    else{
                        PI.set(Constant.intIlleagalOpParameter);
                    }
                }
            }else{
                PI.set(Constant.intIlleagalOpParameter);
            }
        } catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        } catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //------------------------------------------------------------------------//
    //PUSH value to stack stekas = R; SP = SP + 1
    //------------------------------------------------------------------------//
    
    public void PUSH () {
        try {
            int word = Convert.toInt(SP.get());
            ram.writeWord(Convert.toAA(word, PTR, SS, ram), R.get());
            word++;
            SP.set(Convert.toWord(word));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }
    
    //------------------------------------------------------------------------//
    //POP value from stack SP = SP � 1; R = stekas
    //------------------------------------------------------------------------//
    
    public void POP () {
        try {
            int word = Convert.toInt(SP.get());
            word--;
            
            int maxStack = Convert.toInt(PTR.get().substring(0,1));
            if (word < 0 ) {
                PI.set(Constant.intIlleagalStackMemory);
            } else {
                R.set(ram.readWord(Convert.toAA(word, PTR, SS, ram)));
                SP.set(Convert.toWord(word));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }    
    
    //-- CLRR ----------------------------------------------------------------//
    
    public void CLRR () {
        R.set("0000");
    }
    
    public void CLRU () {
        U.set("0000");
    }
    
    //========================================================================//
    //-- SAKOJIMOSI KOMANDOS -------------------------------------------------//
    //========================================================================//
    
    //------------------------------------------------------------------------//
    // JumP IC = [x1x2]
    //------------------------------------------------------------------------//
    
    public void JP (String xy) {
        try {
                IC.set(Convert.toWord(Convert.toInt(xy)));
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //------------------------------------------------------------------------//
    //Branch if Equal if C = 0, IC = [x1x2]
    //                else IC = IC + 1
    //------------------------------------------------------------------------//
    
    public void BE (String xy) {
        try {
            int c  = Convert.toInt(C.get());
            int ic = Convert.toInt(IC.get());
            
            if (c == 0) {
                IC.set(Convert.toWord(Convert.toInt(xy)));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //------------------------------------------------------------------------//
    //Branch if NotEqual if C != 0, IC = [x1x2]
    //                   else IC = IC + 1    
    //------------------------------------------------------------------------//
    
    public void BN (String xy) {
        try {
            int c  = Convert.toInt(C.get());
            int ic = Convert.toInt(IC.get());
        
            if (c != 0) {
                IC.set(Convert.toWord(Convert.toInt(xy)));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //------------------------------------------------------------------------//
    //Branch if Greater if C = 2, IC = [x1x2]
    //                  else IC = IC + 1  
    //------------------------------------------------------------------------// 
 
    public void BG (String xy) {
        try {
            int c  = Convert.toInt(C.get());
            int ic = Convert.toInt(IC.get());
        
            if (c == 2) {
                IC.set(Convert.toWord(Convert.toInt(xy)));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }
    
    //------------------------------------------------------------------------//
    //Branch if Less if C = 1, IC = [x1x2]
    //               else IC = IC + 1    
    //------------------------------------------------------------------------//
    
    public void BL (String xy) {
        try {
        int c  = Convert.toInt(C.get());
        int ic = Convert.toInt(IC.get());
        
            if (c == 1) {
                IC.set(Convert.toWord(Convert.toInt(xy)));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } 
    }
    
    //-- Branch if overflow --------------------------------------------------//
    
    public void BO (String xy) {
        try {
        int c  = Convert.toInt(C.get());
        int ic = Convert.toInt(IC.get());
        
            if (c == 4) {
                IC.set(Convert.toWord(Convert.toInt(xy)));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } 
    }
    
    //------------------------------------------------------------------------//
    //Loop U = U ?1
    //     if U > 0 then IC = [x1x2] 
    //     else IC = IC + 1
    //------------------------------------------------------------------------//
    
    public void LP (String xy) {
        try {
            int u  = Convert.toInt(U.get());
            int ic = Convert.toInt(IC.get());
        
            u--;
            U.set(Convert.toWord(u));
            if (u > 0) {
                IC.set(Convert.toWord(Convert.toInt(xy)));
            }
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } 
    }      
    
    //------------------------------------------------------------------------//
    //Long JuMP PTR = [R]; SS:DS = [R+1]; IC = 0;
    //Pagal programos aprasa  paleidziama programa. R ?absoliutus apraso adresas
    //------------------------------------------------------------------------//
    
    public void LJMP () {
        try {
            int r  = Convert.toInt(R.get());
            
            PTR.set(Convert.toWord(Convert.toInt(ram.readWord(r))));
            r++;
            R.set(Convert.toWord(r));

            String wordS = Convert.toWord(Convert.toInt(ram.readWord(r)));
            SS.set(wordS.substring(0,2));
            DS.set(wordS);
            IC.set("00");
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        }  
    }
    
    //------------------------------------------------------------------------//
    //Long CALL PTR = [R]; SS:DS = [R+1]; SP = 0; IC = 0;
    //I kvieciamos programos steks saugoma:
    //stekas = SS:DS (senos reiksmes)
    //stekas = IC:SP (senos reiksmes)
    //stekas = PTR (sena reiksme)
    //R ?absoliutus programos apraso adresas. Valdymo perdavimas programai.
    //------------------------------------------------------------------------//
    public String LCAL () {
        String virtualProgramCall = null;
        try {
            virtualProgramCall = null;
            int r, word, i = 0;
            String wordS, ptr, ss, ds, ic, sp;
            
            r = Convert.toInt(R.get());
            
            if (ram.readWord(r).substring(0,1).equals("#")) {
                // paleidzia virtualia programa
                virtualProgramCall = ram.readWord(r);
            } else {              
                ptr = PTR.get();
                ss = SS.get();
                ds = DS.get();
                ic = IC.get();
                sp = SP.get();
                
                PTR.set(Convert.toWord(Convert.toInt(ram.readWord(r))));
                
                r++;
                R.set(Convert.toWord(r));
                wordS = Convert.toWord(Convert.toInt(ram.readWord(r)));
                 
                SS.set(wordS.substring(0,2));
                DS.set(wordS);
                IC.set("00");
                SP.set("00");

                stackPush(ss+ds, SP, PTR, SS);
                stackPush(ic+sp, SP, PTR, SS);
                stackPush(ptr, SP, PTR, SS);
            }

        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        }  catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        } 
        return virtualProgramCall;
    }

    public String longCall ( int descriptionAddress ) 
        throws IlleagalNumberException, IlleagalAddressException, EmptyMemoryException
    {
        String virtualProgramCall = null;
        int r, word, i = 0;
        String wordS, ptr, ss, ds, ic, sp;
        
        r = descriptionAddress;
        
        if (ram.readWord(r).substring(0,1).equals("#")) {
            // paleidzia virtualia programa
            virtualProgramCall = ram.readWord(r);
        } else {    
          
            ptr = PTR.get();
            ss = SS.get();
            ds = DS.get();
            ic = IC.get();
            sp = SP.get();
            
            PTR.set(Convert.toWord(Convert.toInt(ram.readWord(r))));
            
            r++;
            R.set(Convert.toWord(r));
            wordS = Convert.toWord(Convert.toInt(ram.readWord(r)));
             
            SS.set(wordS.substring(0,2));
            DS.set(wordS);
            IC.set("00");
            SP.set("00");

            stackPush(ss+ds, SP, PTR, SS);
            stackPush(ic+sp, SP, PTR, SS);
            stackPush(ptr, SP, PTR, SS);
        }
        return virtualProgramCall;
    }
    
    //------------------------------------------------------------------------//
    //Long RETurn MODE = S; PTR = stekas; IC:SP = stekas; SS:DS = stekas;
    //            Valdymo grzinimas supervizorinei programai
    //------------------------------------------------------------------------//
    
    public void RETL() {        
        try {
            MODE.set("S");
            String ptr = PTR.get(), ss = SS.get();
            Register sp = new Register(4);
            sp.set(SP.get());
            PTR.set(Convert.toWord(Convert.toInt(stackPop(sp, ptr, ss))));
           
            String wordS = Convert.toWord(Convert.toInt(stackPop(sp, ptr, ss)));
            IC.set(wordS.substring(0,2));
            SP.set(wordS);
            
            wordS = Convert.toWord(Convert.toInt(stackPop(sp, ptr, ss)));
            SS.set(wordS.substring(0,2));
            DS.set(wordS);
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }
    }
    
    //------------------------------------------------------------------------//
    //Interrupt RETurn MODE = U; PTR = stekas; IC:SP = stekas; SS:DS = stekas;
    //                  Valdymo grazinimas vartotojo programai is pertraukimo apdorojimo programos
    //------------------------------------------------------------------------//
    
    public void RETI() {
        try {
            MODE.set("U");
            String ptr = PTR.get(), ss = SS.get();
            Register sp = new Register(4);
            sp.set(SP.get());            
            PTR.set(Convert.toWord(Convert.toInt(stackPop(sp, ptr, ss))));
           
            String wordS = Convert.toWord(Convert.toInt(stackPop(sp, ptr, ss)));
            IC.set(wordS.substring(0,2));
            SP.set(wordS);
            
            wordS = Convert.toWord(Convert.toInt(stackPop(sp, ptr, ss)));
            SS.set(wordS.substring(0,2));
            DS.set(wordS);
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }        
    }
    
    //------------------------------------------------------------------------//
    //CaLl stekas = IC; IC = x1x2; 
    //Valdymo perdavimas paprogramei
    //------------------------------------------------------------------------//
    
    public void CL (String xy) {
        try {
            stackPush("00"+IC.get(), SP, PTR, SS);
            IC.set(Convert.toWord(Convert.toInt(xy))); 
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }
            
    }
    
    //-- RETP ----------------------------------------------------------------//
    //CaLl IC = stekas; 
    //Valdymo grazinimas programai is paprogrames
    //------------------------------------------------------------------------//
    
    public void RETP() {
        try {
            IC.set(Convert.toWord(Convert.toInt(stackPop(SP, PTR, SS).substring(2,4)))); 
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        } catch (IlleagalAddressException e) {
            PI.set(Constant.intIlleagalMemory);
        } catch (EmptyMemoryException e) {
            PI.set(Constant.intEmptyMemory);
        }  
    }   
    
    //========================================================================//
    //-- KOMANDOS SU KANALAIS ------------------------------------------------//
    //========================================================================//
    
    //-- INP -----------------------------------------------------------------//
    
    public void INP ( String y ) {
        try {
            int chnNr = Convert.toInt(y);
            int sourcePageAddress = Convert.toInt(U);
            int destPageAddress = Convert.toInt(R);
            
            //System.out.println("INPUT : destination:"+R +"source:"+U+" chn: "+y);
            
            if (CAST.getByte(chnNr).equals("0")) {
                chn[chnNr].setForReadData(destPageAddress, sourcePageAddress);
            } else {
                PI.set(Constant.intChannelBusy);
            }
            
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
        }
    }

    //-- OUT -----------------------------------------------------------------//
    
    public void OUT ( String y ) {
        try {
            //System.out.print("\nOUTPUTTTING TEXXTT \n");
            
            int chnNr = Convert.toInt(y);
            int sourcePageAddress = Convert.toInt(R);
            int destPageAddress = Convert.toInt(U);

            //System.out.print("\nOUTPUTTTING TEXXTT s"+sourcePageAddress+" d"+destPageAddress+" "+"CAST+ "+CAST.getByte(chnNr)+"\n");
            
            if (CAST.getByte(chnNr).equals("0")) {
                
                chn[chnNr].setForWriteData(sourcePageAddress, destPageAddress);
                //chn[chnNr].run();
                //chn[chnNr].exchangeData();
            } else {
                PI.set(Constant.intChannelBusy);
            }
        
        } catch (IlleagalNumberException e) {
            PI.set(Constant.intIlleagalOpParameter);
            e.printStackTrace();
        }
    }

    //========================================================================//
    //-- PAPILDOMOS KOMANDOS -------------------------------------------------//
    //========================================================================//
    
    //-- SI ------------------------------------------------------------------//

    public void SI( String xy ){
        try{
            int interruptNr = Convert.toInt(xy);
            SI.set(Convert.toWord(interruptNr));
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
            e.printStackTrace();
        }
    }

    //-- USRM ----------------------------------------------------------------//
    
    public int USRM(){
        return 1;
    }

    //-- HALT ----------------------------------------------------------------//
    
    public void HALT() {
        throw new CPUhaltException("HALT operation initiated.");
    }

    public void cpuHalt( String str ) {
        throw new CPUhaltException(str);
    }
    
    //-- NOP -----------------------------------------------------------------//
    
    public void NOP(){
    }
    
    //-- AADR ----------------------------------------------------------------//
    
    public void AADR(){
        try{
            String tempDS = R.get().substring(2,4);
            int localAddress = Convert.toInt(tempDS);
            R.set( Convert.toWord(Convert.toAA(localAddress,PTR,DS, ram)) );
        }
        catch(IlleagalNumberException e){
            PI.set(Constant.intIlleagalOpParameter);
        }
        catch(IlleagalAddressException e){
            PI.set(Constant.intIlleagalMemory);
        }
        catch(EmptyMemoryException e){
            PI.set(Constant.intEmptyMemory);
        }
    }

}