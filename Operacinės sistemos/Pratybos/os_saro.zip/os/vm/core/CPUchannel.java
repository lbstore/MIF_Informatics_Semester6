package vu.os.vm.core;

import vu.os.vm.core.io.VirtualDevice;
import vu.os.vm.exceptions.VirtualDeviceException;

public class CPUchannel extends Thread{
    private VirtualDevice device = null;
    private VirtualRAM ram = null;
    
    private Register CAST, IOI;
    
    private int chnNr;
    private int SA;     //adresacija puslapiais
    private int DA;     //adresacija puslapiais
    private int DD;     //1: chn <- ram, 2: ram <- chn // 0 - no operation pending
    private boolean runnable = false;
    private boolean exchange = false;
    //------------------------------------------------------------------------//
    public CPUchannel( VirtualRAM ram, int chnNr, Register cast, Register ioi) {
        this.ram = ram;
        this.CAST = cast;
        this.IOI = ioi;
        this.chnNr = chnNr;
    }
    //------------------------------------------------------------------------//
    public void setDevice( VirtualDevice device ) {
        this.device = device;
        runnable = true;
    }
    //------------------------------------------------------------------------//
    public VirtualDevice getDevice() {
        return device;
    }
    //------------------------------------------------------------------------//
    private void setChannel(int sourceAddress, int destAddress, int dataDirection) {
        this.SA = sourceAddress;
        this.DA = destAddress;
        this.DD = dataDirection;
        exchange = true;
    }
    //------------------------------------------------------------------------//
    public void setForReadData(int ramPageAddressToWrite, int devicePageAddressToRead) {
        setChannel(devicePageAddressToRead, ramPageAddressToWrite, 2);
    }
    //------------------------------------------------------------------------//
    public void setForWriteData(int ramPageAddressToRead, int devicePageAddressToWrite) {
        setChannel(ramPageAddressToRead, devicePageAddressToWrite, 1);
    }
    //------------------------------------------------------------------------//
    public void exchangeData() {
        while (CAST.getByte(chnNr).equals("1"));       // laukia kol pasibaigs preita operacija, jei tokia buvo
        CAST.setByte(chnNr, "1");                      // pazymi kad einamasis kanalas uzimtas
        //System.out.println("\nCAST.setByte(chnNr, \"1\")\n");
        boolean error = false;
        if (DD == 2) {                  // ram <- chn
            try {
                String[] page;
                page = device.readPage(SA);
                ram.writePage(DA, page);
                
            } catch (Exception e) {
                e.printStackTrace();
                error = true;
            }
        } else if (DD == 1) {          // chn <- ram
            try {
                String[] page;
                page = ram.readPage(SA);
                device.writePage(DA, page);
            } catch (Exception e) {
                error = true;
            }
        }
        if (!error) {
            IOI.setByte(chnNr, Constant.intIOIok);
        } else {
            IOI.setByte(chnNr, Constant.intIOIerror);
        }
        CAST.setByte(chnNr, "0");
        //System.out.println("\nCAST.setByte(chnNr, \"0\")\n");
        exchange = false;
    }
    //------------------------------------------------------------------------//
    public void run() {
        while (runnable) {
            if (exchange) {
                exchangeData();
            }
            if (device.interruptReguested()) {
                IOI.setByte(chnNr, Constant.intIOIIRQ);
            }
            
            try {
                Thread.currentThread().sleep(10);
            } catch (Exception e) {
                System.out.println("ERROR! CPUchannel nr " + chnNr + " " + e);

            }
            
        }
    }
    public void stopChannel() {
        runnable = false;
    }
    //------------------------------------------------------------------------//
    public boolean isBootable() {
        boolean bootable = false;
        if (device != null) {
            try {
                bootable = device.isBootable();
            } catch (VirtualDeviceException e) {
                bootable = false;
            }
        }
        return bootable;
    }
}