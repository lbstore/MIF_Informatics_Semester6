package vu.os.vm.exceptions;

public class MOSException extends RuntimeException {
    
    public MOSException(String e) {
        super(e);
    }
}