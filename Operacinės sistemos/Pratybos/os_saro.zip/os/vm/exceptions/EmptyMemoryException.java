package vu.os.vm.exceptions;

// Skirta darbui su operatyvia atmintimi (RAM)
// Exception'as metamas kai:
//  * puslapiu lenteleje randamas adresas pazymetas kaip tuscias 
//    (standartiskai "****")

public class EmptyMemoryException extends RuntimeException {

    public EmptyMemoryException(String e) {
        super(e);
    }
}