package vu.os.vm.exceptions;

public class HDDFormatterException extends RuntimeException {
    
    public HDDFormatterException (String e) {
        super(e);
    }
}