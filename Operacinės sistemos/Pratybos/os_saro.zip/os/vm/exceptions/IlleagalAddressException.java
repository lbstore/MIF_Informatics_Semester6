package vu.os.vm.exceptions;

// Skirta darbui su operatyvia atmintimi (RAM)
// Exception'as metamas kai:
//  * bandoma pasiekti neprieinama atmintis RAM'e
//  * netinkamas adreso formatas

public class IlleagalAddressException extends RuntimeException {

    public IlleagalAddressException(String e) {
        super(e);
    }
}