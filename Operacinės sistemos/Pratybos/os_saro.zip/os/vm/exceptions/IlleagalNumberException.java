package vu.os.vm.exceptions;

// Skirta darbui su VirtualCPU.toInt metodu
// Exception'as metamas kai:
//  * paduotas String'as nera skaicius
//  * paduotas String'as yra neigiamas skaicius (pvz "-1")

public class IlleagalNumberException extends RuntimeException {

    public IlleagalNumberException(String e) {
        super(e);
    }
}