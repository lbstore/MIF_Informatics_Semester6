package vu.os.vm.exceptions;

public class CPUhaltException extends RuntimeException {
    
    public CPUhaltException(String e) {
        super(e);
    }
}