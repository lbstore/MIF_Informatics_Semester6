package vu.os.vm.exceptions;

public class VirtualDeviceException extends RuntimeException {
    
    public VirtualDeviceException(String e) {
        super(e);
    }
}