package vu.os.vm.exceptions;

public class PrecompilerException extends RuntimeException {
    
    public PrecompilerException(String e) {
        super(e);
    }
}