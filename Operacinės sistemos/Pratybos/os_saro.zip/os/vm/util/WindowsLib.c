
#include <jni.h>
#include "vu_os_vm_util_WindowsLib.h"
#include <stdio.h>
#include <windows.h>

JNIEXPORT jboolean JNICALL JNICALL Java_vu_os_vm_util_WindowsLib_inputBufferIsCharAvailable(JNIEnv *env, jobject obj) {
    HANDLE hStdin;
    hStdin = GetStdHandle(STD_INPUT_HANDLE);
    INPUT_RECORD irInBuf[20];
    DWORD cNumRead;
    int i = 0, pt = 0;
    PeekConsoleInput( hStdin, irInBuf, 20, &cNumRead);
    for (i = 0; i < cNumRead; i++) {
        if (irInBuf[i].EventType == KEY_EVENT) {
            if (irInBuf[i].Event.KeyEvent.bKeyDown == TRUE) {
                pt = 1;
                break;                                    
            }
        }
    }
    
    if (pt == 1) {
        return TRUE;
    } else return FALSE;
}



JNIEXPORT jchar JNICALL JNICALL Java_vu_os_vm_util_WindowsLib_inputBufferGetChar(JNIEnv *env, jobject obj) {
    char c;
    
    HANDLE hStdin;
    hStdin = GetStdHandle(STD_INPUT_HANDLE);
    INPUT_RECORD irInBuf[20];
    DWORD cNumRead;
    int i = 0, pt = 0;
    PeekConsoleInput( hStdin, irInBuf, 20, &cNumRead);
    for (i = 0; i < cNumRead; i++) {
        if (irInBuf[i].EventType == KEY_EVENT) {
            if (irInBuf[i].Event.KeyEvent.bKeyDown == TRUE) {
                c = irInBuf[i].Event.KeyEvent.uChar.AsciiChar;
                break;
            }
        }
    }
    FlushConsoleInputBuffer(hStdin);
    
    return c;
}


