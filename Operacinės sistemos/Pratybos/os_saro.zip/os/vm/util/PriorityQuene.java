package vu.os.vm.util;

import java.util.LinkedList;
import java.lang.Class;
import java.lang.reflect.Array;


import vu.os.vm.exceptions.MOSException;
// Encapsulates lists as different priority quenes
// priorities 0 -- maxPriority

public class PriorityQuene<T> {

    private LinkedList<T>[] priorityArray;

    public PriorityQuene( int maxPriority ) {
        priorityArray = (LinkedList<T>[]) Array.newInstance(new LinkedList<T>().getClass(),maxPriority+1);
        
        for (int i=0; i<=maxPriority; i++) {
            priorityArray[i] = new LinkedList<T>();
        }
    }

    public void include( int priority, T object ) {
        priorityArray[priority].addLast(object);
    }
    
    public T peekFirst( int priority) {
        return priorityArray[priority].peek();
    }

    public T peekElement( int priority, int elementIndex ) {
        T element;
        try {
            element = priorityArray[priority].get(elementIndex);
        } catch (IndexOutOfBoundsException e) {
            element = null;
        }
        return element;
    } 
    
    public T pollFirst( int priority ) {
        return priorityArray[priority].poll();
    }

    public int size( int priority ) {
        return priorityArray[priority].size();
    }

    public int size() {
        int size = 0;
        for (int i=0; i<priorityArray.length; i++) {
            size += priorityArray[i].size();
        }
    
        return size;
    }

    public boolean remove(T object) {
        boolean found = false;

        //if (object.toString().equals("13")) { throw new MOSException("REMOVED MY IDLE");}
        for (int i=0; i<priorityArray.length; i++) {
            if (priorityArray[i].remove(object) == true) {
                found = true;
            }
        }
        
        return found;
    }

    public T removeElement( int priority, int elementIndex ) {
        return priorityArray[priority].remove(elementIndex);
    }
    
    public boolean contains(T object) {
        boolean found = false;
        
        for (int i=0; i<priorityArray.length && !found; i++) {
            //*
            //System.out.println("@ READY PROCESS LIST: PRIORITY:"+i+" size: "+priorityArray[i].size());
            for (int j=0; j<priorityArray[i].size() && !found; j++) {
                //System.out.println("@ READY PROCESS LIST: PRIORITY:"+i+" is process id :"+priorityArray[i].get(j) );
                if (priorityArray[i].get(j) == object) {
                    found = true;
                }
            }
            //*/
            /*if (priorityArray[i].contains(object) == true) {
                found = true;
            }*/
        }
        //System.out.println("@ READY PROCESS LIST: found "+object+"? "+found );
        return found;
    }
    
    public int maxPriority() {
        return priorityArray.length-1;
    }
}