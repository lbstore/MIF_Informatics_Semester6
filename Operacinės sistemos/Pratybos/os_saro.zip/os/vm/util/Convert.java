package vu.os.vm.util;

import vu.os.vm.core.Register;
import vu.os.vm.core.VirtualRAM;
import vu.os.vm.exceptions.EmptyMemoryException;
import vu.os.vm.exceptions.IlleagalNumberException;
import vu.os.vm.exceptions.IlleagalAddressException;

public class Convert {
    private static String emptyPointer = "****";

    //-- CONVERT LOCAL ADDRESS TO ABSOLUTE ADDRESS ---------------------------//
    // paskaiciuoja absoliutu zodzio adresa RAM'e. Parametrai:
    // * addressInSegment - adresas programos segmente
    // * valuePtr - PTR registro reiksme 
    // * segmentPageAddress - segmento pradzios puslapio adresas programoje 
    //    (paduodami SS,DS arba "0" (CS atvieju))
    //------------------------------------------------------------------------//
    
    public static int toAA( int addressInSegment, Object valuePtr, Object segmentPageAddress, VirtualRAM ram ) 
            throws EmptyMemoryException, IlleagalAddressException 
    {   
        return toAA(addressInSegment, valuePtr.toString(), segmentPageAddress.toString(), ram);
    }
    
    public static int toAA( int addressInSegment, String valuePtr, String segmentPageAddress, VirtualRAM ram ) 
            throws EmptyMemoryException, IlleagalAddressException 
    {     
        try {
            int ptPageAddress = toInt(valuePtr.substring(2,4));
            int ptSize = toInt(valuePtr.substring(0,2)) + 1;
            int spAddress = toInt(segmentPageAddress);
            
            int localWordAddress = spAddress*10 + addressInSegment;
            
            String pagePointer = ram.readWord(ptPageAddress*10 + (localWordAddress / 10));
            
            
            
            if (pagePointer.equals(emptyPointer)) {
                throw new EmptyMemoryException("Empty page pointer: " + pagePointer);
            } else if ((localWordAddress / 10) >= ptSize) {
                throw new IlleagalAddressException("Illeagal memmory access. Local address: " + 
                                                    localWordAddress + 
                                                    ". Program page count: " + 
                                                    ptSize);
            } else {
                return toInt(pagePointer)*10 + (addressInSegment % 10);
            }
        } catch (EmptyMemoryException e) {
            throw e;
        } catch (IlleagalAddressException e) {
            throw e;
        } catch (Exception e) {
            throw new IlleagalAddressException("getAAinSeg: local address: " + addressInSegment 
                + " PTR:"+valuePtr+" SEG:"+segmentPageAddress);
        }
    }
    
    //-- TO INTEGER ----------------------------------------------------------//
    // grazina teigiama int (negiamas int == IlleagalNumberException)
    //------------------------------------------------------------------------//
    
    public static int toInt( Register reg ) throws IlleagalNumberException {
        return toInt(reg.toString());
    }
    
    public static int toInt( String word ) throws IlleagalNumberException {
        try {
            int integer = new Integer(word);
            if (integer < 0) {
                throw new Exception();
            }
            return integer;
        } catch (Exception e) {
            throw new IlleagalNumberException("Illeagal number: " + word);
        }
    }

    public static int toSInt( String word ) throws IlleagalNumberException {
        try {
            int integer = new Integer(word);
            return integer;
        } catch (Exception e) {
            throw new IlleagalNumberException("Illeagal number: " + word);
        }
    }
    //Convert.toInt
    //-- TO WORD -------------------------------------------------------------//
    // grazina 4 simboliu String'a
    //------------------------------------------------------------------------//
    
    public static String toWord( int integer ) {
        Integer i = new Integer( (10000 + (integer % 10000)) % 10000 );
        Register r = new Register(4);
        r.set("0000");
        
        r.set((new Integer(i)).toString());
        return r.toString();
    }
    
    // ARRAY TO STRING
    public static String arrayToString( String[] array ) {
        String str = new String();
        for (int i=0; i < array.length; i++) {
            str += array[i] + "\n";
        }
        return str;
    }
} 