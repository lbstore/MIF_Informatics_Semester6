package vu.os.vm.util;

import vu.os.vm.util.ProgramStructure;
import vu.os.vm.exceptions.PrecompilerException;

import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Precompiler
{   
    private static final int SS_MAX_SIZE = 10;
    private static final int SS_MIN_SIZE = 1;
    private static final int DS_MAX_SIZE = 10;
    private static final int DS_MIN_SIZE = 0;
    private static final int CS_MAX_SIZE = 10;
    private static final int CS_MIN_SIZE = 1;
    
    private static final String STACK_SEGMENT = ".STACK";
    private static final String CODE_SEGMENT  = ".CODE";
    private static final String DATA_SEGMENT  = ".DATA";
    private static final String MODE_KEYWORD  = ".MODE";
    
    private static final String[] SUPPORTED_MODES = {"U","S"};
    
    private static final String OS_NAME = "MOS1";
    private static final String FILE_FORMAT_VERSION = "0001";
    
    private static final int WORD_LENGTH = 4;
    private static final int PAGE_SIZE   = 10;
    
    //private static final String[] SUPPORTED_TYPES = { "PRGR" , "IMGE" };
    
    private ArrayList<String[]> sourceFiles = null;
    private ArrayList<ProgramStructure> precompiledPrograms = null;
    
    // ========= COMPILER CONSTRUCTOR ============== //
    public Precompiler()
    {
        sourceFiles   = new ArrayList<String[]>();
        precompiledPrograms = new ArrayList<ProgramStructure>();
    }
    // ============================================= //
    
    // = CHECK IF SOURCE FILE'S TYPE IS SUPPORTED == //
    /*
    private boolean typeIsSupported( String type )
    {
        String tempType = type;
        boolean isSupported = false;
        
        if( tempType.length() <= WORD_LENGTH )
        {
            if( tempType.length() < WORD_LENGTH )
            {
                tempType = addSpaces( tempType );
            }
            
            for( int i = 0 ; i < SUPPORTED_TYPES.length ; i++ )
            {
                if( tempType.equals( SUPPORTED_TYPES[i] ) )
                {
                    isSupported = true;
                    break;
                }
            }
        }
        
        return isSupported;
    }
    */
    // ============================================= //
    
    // ======== ADD SOURCE FILE TO THE LIST ======== //
    public void addSourceFile( String path /*, String name , String type*/ )
                                                        throws PrecompilerException
    {
        String[] sourceFile = new String[1];
        sourceFile[0] = path;
        /*
        String[] sourceFile = null;
        if( path != null && name != null && type != null )
        {
            if( name.length() <= WORD_LENGTH )
            {
                if( typeIsSupported( type ) )
                {
                    sourceFile = new String[3];
                    sourceFile[0] = path;
                    sourceFile[1] = name;
                    sourceFile[2] = type;
                    
                    sourceFiles.add(sourceFile);
                }
                else
                {
                    throw new PrecompilerException("Illegal source file type: "
                                                                         +type);
                }
            }
            else
            {
                throw new PrecompilerException("Illegal source file name: "+name);
            }
        }
        else
        {
            throw new PrecompilerException("Illegal parameter(NULL was found)!");
        }
        */
    }
    // ============================================= //
    
    // ====== COMPILE ALL SOURCE FILES LIST ======== //
    public ArrayList<ProgramStructure> precompileAll()
    {
        ProgramStructure programStructure = null;
        for( int i = 0 ; i < sourceFiles.size() ; i++ )
        {
            programStructure = precompile( sourceFiles.get(i)[0] );
            precompiledPrograms.add(programStructure);
        }
        
        return precompiledPrograms;
    }
    // ============================================= //
    
    // ============ 2BYTES+2BYTES = WORD =========== //
    private String formatFirstTwoAndLastTwoBytes( int firstTwoBytes , int lastTwoBytes )
    {
        String word = null;
        
        if( firstTwoBytes > 9 )
        {
            word = Integer.toString(firstTwoBytes);   
        }
        else
        {
            word = "0"+Integer.toString(firstTwoBytes);
        }
        
        if( lastTwoBytes > 9 )
        {
            word = word+Integer.toString(lastTwoBytes);
        }
        else
        {
            word = word+"0"+Integer.toString(lastTwoBytes);
        }
        
        return word;
    }
    // ============================================= //
    
    // ========= ANALYZE START-UP MODE ============= //
    private String getStartUpMode( String modeLine )
    {
        String detectedMode = null;
        
        int keywordLength = MODE_KEYWORD.length();
        
        for( int i = 0 ; i < SUPPORTED_MODES.length ; i++ )
        {
            if( SUPPORTED_MODES[i].equals( modeLine.substring(keywordLength) ) )
            {
                detectedMode = "000"+SUPPORTED_MODES[i];
                break;
            }
        }
        
        return detectedMode; // if mode was not detected, returns null
    }
    // ============================================= //
    
    // ========= ANALYZE SEGMENT'S SIZE ============ //
    private int getSegmentSize( String segmentLine , String segment )
    {
        int segmentSize = -1; // if size is illegal, returns -1
        int keywordLength;
        
        if( segment.equals(STACK_SEGMENT) )
        {
            keywordLength = STACK_SEGMENT.length();
            segmentSize = toNNInteger(segmentLine.substring(keywordLength));
        }
        else if( segment.equals(CODE_SEGMENT) )
        {
            keywordLength = CODE_SEGMENT.length();
            segmentSize = toNNInteger(segmentLine.substring(keywordLength));
        }
        else if( segment.equals(DATA_SEGMENT) )
        {
            keywordLength = DATA_SEGMENT.length();    
            segmentSize = toNNInteger(segmentLine.substring(keywordLength));
        }
        
        return segmentSize;
    }
    // ============================================= //
    
    // ====== STRING TO NON-NEGATIVE INTEGER ======= //
    private int toNNInteger( String number )
    {
        int nonNegativeInteger; // if number is illegal, returns -1
        
        try
        {
            nonNegativeInteger = Integer.parseInt(number);
            
            if( nonNegativeInteger < 0 )
            {
                nonNegativeInteger = -1;
            }
        }
        catch( NumberFormatException e )
        {
            nonNegativeInteger = -1;
        }
        
        return nonNegativeInteger;
    }
    // ============================================= //
    
    // =========== IDENTIFY SEGMENT ================ //
    private int identifySegment( String line )
    {
        int segmentID = -1; // CS = 1 , DS = 2 , SS = 3 , MODE = 4 , NONE = -1
        
        int keywordLength;
        
        if( line.length() >= CODE_SEGMENT.length() )
        {
            if( line.length() > STACK_SEGMENT.length() )
            {
                keywordLength = STACK_SEGMENT.length();
                
                if( line.substring(0, keywordLength).equals(STACK_SEGMENT) )
                {
                    segmentID = 3;
                }
            }
            else
            {
                keywordLength = CODE_SEGMENT.length();
                
                if( line.substring(0, keywordLength).equals(CODE_SEGMENT) )
                {
                    segmentID = 1;
                }
                else if( line.substring(0, keywordLength).equals(DATA_SEGMENT) )
                {
                    segmentID = 2;
                }
                else if( line.substring(0, keywordLength).equals(MODE_KEYWORD) )
                {
                    segmentID = 4;
                }
            }
        }
        
        return segmentID;
    }
    // ============================================= //
    
    // ============== ADD SPACES =================== //
    private String addSpaces( String line )
    {
        String tempLine = line;
        
        if( tempLine.length() < WORD_LENGTH )
        {
            if( tempLine.length() == 0 )
            {
                tempLine = "    ";
            }
            else if( tempLine.length() == 1 )
            {
                tempLine += "   ";
            }
            else if( tempLine.length() == 2 )
            {
                tempLine += "  ";
            }
            else
            {
                tempLine += " ";
            }
        }
        return tempLine;
    }
    // ============================================= //
    
    // ======== CONSTRUCT PROGRAM HEADER =========== //
    private String[] makeHeader( int CSRealSize , int DSRealSize , 
                                 int SSRealSize , int currentDSSize, 
                                 String startUpMode )
    {
        String[] tempHeader = new String[10];
        tempHeader = erasePage( tempHeader );
        int programSize = CSRealSize+DSRealSize+SSRealSize;
        tempHeader[0] = OS_NAME;
        tempHeader[1] = FILE_FORMAT_VERSION;
        tempHeader[2] = formatFirstTwoAndLastTwoBytes( 0 , CSRealSize+currentDSSize );
        tempHeader[3] = formatFirstTwoAndLastTwoBytes( 0 , CSRealSize+
                                                           DSRealSize+
                                                           SSRealSize );
        tempHeader[4] = formatFirstTwoAndLastTwoBytes( programSize - SSRealSize,
                                                       programSize -SSRealSize -
                                                       DSRealSize);
        tempHeader[5] = startUpMode;
        tempHeader[6] = formatFirstTwoAndLastTwoBytes( 0 , CSRealSize );
        tempHeader[7] = formatFirstTwoAndLastTwoBytes( 0 , DSRealSize );
        tempHeader[8] = formatFirstTwoAndLastTwoBytes( 0 , SSRealSize );
        
        return tempHeader;
    }
    // ============================================= //
    
    // ================ ERASE PAGE ================ //
    public String[] erasePage( String[] page )
    {
        String[] tempPage = page;
        
        if( tempPage != null )
        {
            for( int i = 0 ; i < page.length ; i++ )
            {
                tempPage[i] = "0000";
            }
        }
        
        return tempPage;
    }
    // ============================================ //
    
    public ProgramStructure precompile( String filePath ) throws PrecompilerException
    {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        
        boolean stackSegmentFound = false;
        boolean dataSegmentFound  = false;
        boolean codeSegmentFound  = false;
        boolean modeKeywordFound  = false;
        
        boolean formatStackSegment = false;
        boolean formatCodeSegment  = false;
        boolean formatDataSegment  = false;
        
        int dataSegmentLines = 0;
        int codeSegmentLines = 0;
        
        int dataSegmentRealSize  = 0;
        int stackSegmentRealSize = 0;
        int codeSegmentRealSize  = 0;
        
        String startUpMode = null;
        
        int dataSegmentCurrentSize = 0;
        
        int pageTableSize = 0;
        int programSize   = 0;
        
        int ptrFirstTwoBytes = 0;
        int ptrLastTwoBytes  = 0;
        
        String ptrValue  = null;
        String ssdsValue = null;
        
        String currentLine = null;
        
        String[] codePage = new String[10];
        String[] dataPage = new String[10];
        
        int codePageIndex = 0;
        int dataPageIndex = 0;
        
        ProgramStructure programStructure = new ProgramStructure();
        
        codePage = erasePage( codePage );
        dataPage = erasePage( dataPage );
        
        // ============ TRY TO OPEN AN INPUT FILE ====== //
        try
        {
            fileReader = new FileReader( filePath );
            bufferedReader = new BufferedReader(fileReader);
            
            // ========== READ AND CHECK EACHLINE ========== //
            while( ( currentLine = bufferedReader.readLine() ) != null )
            {
                // ========== CHECK LINE'S LENGTH ============== //
                if( currentLine.length() > WORD_LENGTH )
                {
                    // ========= CHECK IF SEGMENT KEYWORD ========== //
                    switch( identifySegment(currentLine) )
                    {
                        case 1:
                            // === CHECK IF SEGMENT OCCURED JUST ONCE ====== //
                            if( codeSegmentFound )
                            {
                                throw new PrecompilerException("Code segment keyword was found twice!");
                            }
                            else
                            {
                                codeSegmentFound = true;
                                formatCodeSegment = true;
                                
                                formatStackSegment = false;
                                formatDataSegment  = false;
                            }
                            // ============================================= //
                            break;
                        case 2:
                            // === CHECK IF SEGMENT OCCURED JUST ONCE ====== //
                            if( dataSegmentFound )
                            {
                                throw new PrecompilerException("Data segment keyword was found twice!");
                            }
                            else
                            {   
                                // ======== CHECK IF SIZES ARE VALID ======== //
                                dataSegmentRealSize = getSegmentSize( currentLine , DATA_SEGMENT );
                                
                                if( dataSegmentRealSize < DS_MIN_SIZE || 
                                    dataSegmentRealSize > DS_MAX_SIZE ||
                                    dataSegmentRealSize < 0)
                                {
                                    throw new PrecompilerException("Illegal data segment size: "+currentLine);
                                }
                                // ========================================== //
                                
                                dataSegmentFound = true;
                                formatDataSegment = true;
                                
                                formatStackSegment = false;
                                formatCodeSegment  = false;
                            }
                            // ============================================= //
                            break;
                        case 3:
                            // === CHECK IF SEGMENT OCCURED JUST ONCE ====== //
                            if( stackSegmentFound )
                            {
                                throw new PrecompilerException("Stack segment keyword was found twice!");
                            }
                            else
                            {
                                // ======== CHECK IF SIZES ARE VALID ======== //
                                stackSegmentRealSize = getSegmentSize( currentLine , STACK_SEGMENT );
                                
                                if( stackSegmentRealSize < SS_MIN_SIZE || 
                                    stackSegmentRealSize > SS_MAX_SIZE ||
                                    stackSegmentRealSize < 0)
                                {
                                    throw new PrecompilerException("Illegal stack segment size: "+currentLine);
                                }
                                // ========================================== //
                                
                                stackSegmentFound = true;
                                formatStackSegment = true;
                                
                                formatDataSegment = false;
                                formatCodeSegment = false;
                            }
                            // ============================================= //
                            break;
                        case 4:
                            // == CHECK IF MODE KEYWORD OCCURED JUST ONCE == //
                            if( modeKeywordFound )
                            {
                                throw new PrecompilerException("Mode keyword was found twice!");
                            }
                            else
                            {
                                startUpMode = getStartUpMode( currentLine );
                                
                                if( startUpMode == null )
                                {
                                    throw new PrecompilerException("Illegal mode parameter found: "+currentLine);
                                }
                                
                                modeKeywordFound = true;
                            }
                            // ============================================= //
                            break;
                        default:
                            throw new PrecompilerException("Illegal line found: "+currentLine);
                    }
                    // ============================================= //
                    
                }
                else
                {
                    if( currentLine.length() < WORD_LENGTH )
                    {
                        // ========== FORMAT LINE'S LENGTH ============= //
                        currentLine = addSpaces( currentLine );
                        // ============================================= //
                    }
                    
                    // ========== FORMAT CURRENT SEGMENT =========== //
                    if( formatStackSegment )
                    {
                        throw new PrecompilerException("Stack segment is not empty!");
                    }
                    else if( formatDataSegment )
                    {
                        dataPage[dataPageIndex] = currentLine;
                        dataPageIndex++;
                        
                        // ========== ADD PAGE TO DATA SEGMENT ========= //
                        if( dataPageIndex == PAGE_SIZE )
                        {
                            programStructure.addPage( dataPage , "DS" );
                            dataPage = new String[10];
                            dataPage = erasePage(dataPage);
                            dataPageIndex = 0;
                        }
                        // ============================================= //
                        
                        dataSegmentLines++;
                    }
                    else if( formatCodeSegment )
                    {
                        codePage[codePageIndex] = currentLine;
                        codePageIndex++;
                        
                        // ========== ADD PAGE TO CODE SEGMENT ========= //
                        if( codePageIndex == PAGE_SIZE )
                        {
                            programStructure.addPage( codePage , "CS" );
                            codePage = new String[10];
                            codePage = erasePage(codePage);
                            codePageIndex = 0;
                        }
                        // ============================================= //
                        
                        codeSegmentLines++;
                    }
                    // ============================================= //
                    
                }
                // ============================================= //
            }
            // ============================================= //
            
            // ========= CHECK LAST PAGES ================== //
            if( codePageIndex > 0 )
            {
                programStructure.addPage( codePage , "CS" );
                codePage = new String[10];
                codePage = erasePage(codePage);
                codePageIndex = 0;
            }
            
            if( dataPageIndex > 0 )
            {
                programStructure.addPage( dataPage , "DS" );
                dataPage = new String[10];
                dataPage = erasePage(dataPage);
                dataPageIndex = 0;
            }
            // ============================================= //
            
            // ================ ANALIZE DATA =============== //
            if( Math.ceil(codeSegmentLines/PAGE_SIZE) > CS_MAX_SIZE || 
                Math.ceil(codeSegmentLines/PAGE_SIZE) < CS_MIN_SIZE ||
                Math.ceil(codeSegmentLines/PAGE_SIZE) < 0 )
            {
                throw new PrecompilerException("Illegal code segment size: "+
                                    (int)Math.ceil(codeSegmentLines/PAGE_SIZE));
            }
            
            if( Math.ceil(dataSegmentLines/PAGE_SIZE) > dataSegmentRealSize )
            {
                throw new PrecompilerException("Illegal data segment size: "+
                                    dataSegmentRealSize);
            }
            
            if( startUpMode == null )
            {
                startUpMode = "000U";
            }
            // ============================================= //

            // =========== CALCULATE REST VALUES =========== //
            codeSegmentRealSize = (int)Math.ceil( (float)codeSegmentLines/
                                                  (float)PAGE_SIZE );
            programSize = codeSegmentRealSize + 
                          dataSegmentRealSize +
                          stackSegmentRealSize;
            
            ssdsValue = formatFirstTwoAndLastTwoBytes( programSize - 
                                                       stackSegmentRealSize,
                                                       programSize -
                                                       stackSegmentRealSize -
                                                       dataSegmentRealSize);
            dataSegmentCurrentSize = (int)Math.ceil( (float)dataSegmentLines/
                                                     (float)PAGE_SIZE);
            // ============================================= //
            
            // =========== SAVE ALL ANALIZED DATA ========== //
            programStructure.setSegmentRealSize( codeSegmentRealSize , "CS" );
            programStructure.setSegmentRealSize( dataSegmentRealSize , "DS" );
            programStructure.setSegmentRealSize( stackSegmentRealSize, "SS" );
            
            programStructure.setDSCurrentSize(dataSegmentCurrentSize);
            
            programStructure.setProgramSize( programSize );
            programStructure.setSSDSValue( ssdsValue );
            
            String[] programHeader = makeHeader( codeSegmentRealSize,
                                                 dataSegmentRealSize,
                                                 stackSegmentRealSize,
                                                 dataSegmentCurrentSize,
                                                 startUpMode );
            programStructure.addPage( programHeader , "PH" );
            // ============================================= //
            
            // ============= FINALIZE PAGE ADDING ========== //
            if( codePageIndex != 0 )
            {
                programStructure.addPage( codePage , "CS" );
            }
            
            if( dataPageIndex != 0 )
            {
                programStructure.addPage( dataPage , "DS" );
            }
            // ============================================= //
            
            // ############## TESTING BLOCK ################ //
            /*
            System.out.println("==== COMPILED SUCCESSFULLY ====");
            System.out.println();
            System.out.println("Input file name   : "+filePath );
            System.out.println();
            System.out.println("Code segment lines: "+codeSegmentLines);
            System.out.println("Data segment lines: "+dataSegmentLines);
            System.out.println();
            System.out.println("Code  segment real size: "+codeSegmentRealSize);
            System.out.println("Data  segment real size: "+dataSegmentRealSize);
            System.out.println("Stack segment real size: "+stackSegmentRealSize);
            System.out.println();
            System.out.println("Program size   : "+programSize);
            System.out.println();
            System.out.println("SS:DS value: "+ssdsValue);
            System.out.println();
            System.out.println("Start-up mode: "+startUpMode);
            programStructure.test();
            */
            // ############################################# //
        }
        catch( IOException e )
        {
            throw new PrecompilerException("Cannot open "+filePath+" file!");
        }
        finally
        {
            
            // ======== TRY TO CLOSE AN INPUT FILE ========= //
            try
            {
                fileReader.close();
            }
            catch( IOException e )
            {
                throw new PrecompilerException("Cannot close "+filePath+" file!");
            }
            // ============================================= //
            
        }
        // ============================================= //
        return programStructure;
    }
}
