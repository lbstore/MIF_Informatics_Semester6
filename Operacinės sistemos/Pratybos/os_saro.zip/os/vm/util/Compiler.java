package vu.os.vm.util;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Compiler
{
    private static final String stackKeyword = ".STACK";
    private static final String codeKeyword  = ".CODE";
    private static final String dataKeyword  = ".DATA";
    
    private static final int totalKeywords = 3;
    
    private static final int stackKeywordValue = 1;
    private static final int codeKeywordValue  = 2;
    private static final int dataKeywordValue  = 3;
    
    private static final int codeLineLength = 4;
    
    private static final int maxSegmentSize = 10;
    
    private static final int pageSize = 10; // 10 words ( 4 bytes for each )
    
    private int ssValue;
    private int dsValue;
    private int ptrValue;
    
    private int ptrFirstTwoBytes;
    private int ptrLastTwoBytes;
    
    // Size is measured in pages
    private int codeSegmentSize;
    private int dataSegmentSize;
    private int stackSegmentSize;
    private int pageTableSize;
    
    // Real segment size (currently used)
    private int currentCodeSegmentSize;
    private int currentDataSegmentSize;
    private int currentStackSegmentSize;
    
    private int pagesToCopy;
    private int programSize;
    
    public Compiler()
    {
        
    }
    
    // =========== SET SEGMENT SIZE =========== //
    private boolean setSegmentSize( String codeLine )
    {
        boolean errorFound = false;
        switch( getKeywordType( codeLine ) )
        {
            case(stackKeywordValue):
                try
                {
                    stackSegmentSize = Integer.parseInt( codeLine.substring( stackKeyword.length() ) );
                }
                catch( Exception e )
                {
                    System.out.println("Exception: "+e.getMessage() );
                    errorFound = true;
                }
                break;
            case(dataKeywordValue):
                try
                {
                    dataSegmentSize = Integer.parseInt( codeLine.substring( dataKeyword.length() ) );
                }
                catch( Exception e )
                {
                    System.out.println("Exception: "+e.getMessage() );
                    errorFound = true;
                }
                break;
            case(codeKeywordValue):
                break;
            default:
        }
        return errorFound;
    }
    // ======================================== //
    
    // == CHECKS IF GIVEN LINE IS A KEYWORD === //
    private int getKeywordType( String codeLine )
    {
        // 0 - not a keyword
        // 1 - stack keyword
        // 2 - code keyword  
        // 3 - data keyword
        int keyWordIdentifier = 0;
        
        if( codeLine.length() > codeLineLength )
        {
            if( codeLine.length() > codeKeyword.length() && codeLine.substring(0,stackKeyword.length()).equals(stackKeyword) )
            {    
                keyWordIdentifier = stackKeywordValue;
            }
            else if( codeLine.substring(0,codeKeyword.length()).equals(codeKeyword) )
            {
                keyWordIdentifier = codeKeywordValue;
            }
            else if( codeLine.substring(0,dataKeyword.length()).equals(dataKeyword) )
            {
                keyWordIdentifier = dataKeywordValue;
            }
        }
        
        return keyWordIdentifier;
    }
    // ======================================== //
    
    // ==== CHECK IF INPUT FILE IS CORRECT ==== //
    private boolean isCorrect( String fileName )
    {   
        String codeLine = null;
       
        boolean errorFound = false;
        
        FileReader fileReader = null;
        
        int keywordsFound = 0;
        int keywordValue  = 0;
        
        int totalStackLines = 0;
        int totalCodeLines  = 0;
        int totalDataLines  = 0;
        
        boolean startCountingStackLines = false;
        boolean startCountingDataLines  = false;
        boolean startCountingCodeLines  = false;
        
        try
        {
            fileReader = new FileReader( fileName );
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            while( ( codeLine = bufferedReader.readLine() ) != null && !errorFound )
            {              
                // Check if code line length is correct
                if( codeLine.length() > codeLineLength )
                {
                    if( (keywordValue = getKeywordType( codeLine )) == 0 )
                    {
                        errorFound = true;
                    }
                    else
                    {
                        // counts keywords and checks if duplicate is found
                        keywordsFound++;
                        if( keywordsFound > totalKeywords )
                        {
                            errorFound = true;
                        }
                        
                        // sets segment size and returns TRUE if no error is found
                        if( setSegmentSize(codeLine) )
                        {
                            errorFound = true;
                        }
                        
                        // If keyword found, start counting segment's lines
                        if( keywordValue == stackKeywordValue )
                        {
                            startCountingStackLines = true;
                            startCountingDataLines  = false;
                            startCountingCodeLines  = false;
                        }
                        else if( keywordValue == dataKeywordValue )
                        {
                            startCountingDataLines  = true;
                            startCountingCodeLines  = false;
                            startCountingStackLines = false;
                        }
                        else if( keywordValue == codeKeywordValue )
                        {
                            startCountingCodeLines  = true;
                            startCountingStackLines = false;
                            startCountingDataLines  = false;
                        }
                    }
                }
                else
                {
                    if( startCountingCodeLines )
                    {
                        totalCodeLines++;
                    }
                    else if( startCountingStackLines )
                    {
                        totalStackLines++;
                    }
                    else if( startCountingDataLines )
                    {
                        totalDataLines++;
                    }
                }
            }
        }
        catch( IOException e )
        {
            System.out.println( "Exception: "+ e.getMessage() );
            errorFound = true;
        }
        finally
        {
            try
            {
                if( fileReader != null )
                {
                    fileReader.close();
                }
            }
            catch( IOException e )
            {
                System.out.println("Exception: "+e.getMessage() );
            }
        }
        
        // == CHECK IF ALL SIZES ARE APPROPRIATE == //
        if( Math.ceil((float)totalCodeLines/(float)pageSize) > maxSegmentSize )
        {
            errorFound = true;
        }
        else if( Math.ceil((float)totalDataLines/(float)pageSize) > dataSegmentSize 
                 || Math.ceil((float)totalDataLines/(float)pageSize) > maxSegmentSize
                 || dataSegmentSize < 0
                 || dataSegmentSize > maxSegmentSize)
        {
            errorFound = true;
        }
        else if( totalStackLines != 0 || stackSegmentSize > maxSegmentSize || stackSegmentSize < 1 )
        {
            errorFound = true;
        }
        // ======================================== //

        if( !errorFound )
        {
            codeSegmentSize = (int)Math.ceil((float)totalCodeLines/(float)pageSize);
            pageTableSize   = (int)Math.ceil( (float)(stackSegmentSize+dataSegmentSize+codeSegmentSize)/(float)pageSize );
            
            currentCodeSegmentSize  = codeSegmentSize;
            currentStackSegmentSize = (int)Math.ceil((float)totalStackLines/(float)pageSize);
            currentDataSegmentSize  = (int)Math.ceil((float)totalDataLines/(float)pageSize);
            
            // 1 is added because one additional page is used for START-UP and other vectors
            pagesToCopy = currentCodeSegmentSize+currentDataSegmentSize+pageTableSize+1;
            
            programSize = codeSegmentSize+dataSegmentSize+stackSegmentSize;
            
            ptrFirstTwoBytes = programSize-1;
            
            ptrLastTwoBytes  = 1; // 1 because first page in RAM is Vectors' page 
                                  //pageTableSize; 
            
            ssValue = programSize-stackSegmentSize;
            dsValue = programSize-stackSegmentSize-dataSegmentSize;
        }
        
        return !errorFound;
    }
    // ======================================== //
    
    // ========= 2BYTES+2BYTES = WORD ========= //
    private String formatFirstTwoAndLastTwoBytes( int firstTwoBytes , int lastTwoBytes )
    {
        String word = null;
        
        if( firstTwoBytes > 9 )
        {
            word = Integer.toString(firstTwoBytes);   
        }
        else
        {
            word = "0"+Integer.toString(firstTwoBytes);
        }
        
        if( lastTwoBytes > 9 )
        {
            word = word+Integer.toString(lastTwoBytes);
        }
        else
        {
            word = word+"0"+Integer.toString(lastTwoBytes);
        }
        
        return word;
    }
    // ======================================== //
    
    // ========= FILL PAGE WITH ZEROS ========= //
    private String[] erasePage( String[] page )
    {
        String[] tempPage = page;
        for( int i = 0 ; i < page.length ; i++ )
        {
            page[i] = "0000";
        }
        
        return tempPage;
    }
    // ======================================== //
    
    // ========== FORMAT DEVICE PAGE ========== //
    private String[] formatDevicePage()
    {
        String[] page = new String[10];
        
        page = erasePage( page );
        
        page[0] = "BOOT";
        page[1] = formatFirstTwoAndLastTwoBytes(0,pagesToCopy);
        page[2] = "0001";
        page[3] = formatFirstTwoAndLastTwoBytes(0,pagesToCopy);
        
        return page;
    }
    // ======================================== //
    
    // ========== FORMAT VECTORS PAGE ========= //
    private String[] formatVectorsPage()
    {
        String[] page = new String[10];
        
        page = erasePage( page );
        
        page[0] = formatFirstTwoAndLastTwoBytes(ptrFirstTwoBytes,ptrLastTwoBytes);
        page[1] = formatFirstTwoAndLastTwoBytes(ssValue,dsValue);
        page[2] = "#001";
        page[4] = "#002";
        page[6] = "#003";
        page[8] = "#004";
        
        return page;
    }
    // ======================================== //
    
    // ======== FORMAT PAGE-TABLE PAGE ======== //
    private String[] formatPageTable( int startAddress , int pageNumber , int wordsToFill)
    {
        String[] page = new String[10];
        
        page = erasePage( page );
        
        for( int i = 0 ; i < wordsToFill ; i++ )
        {
            page[i] = formatFirstTwoAndLastTwoBytes( 0 , pageNumber*pageSize+startAddress+i);
        }
        
        return page;
    }
    // ======================================== //
    
    // ====== WRITE PAGE TO OUTPUT FILE ======= //
    private void writePageToFile( String[] page , PrintWriter printWriter , boolean firstTimeWriting ) throws IOException
    {
        boolean firstLineWriting = firstTimeWriting;
        for( int i = 0 ; i < page.length ; i++ )
        {
            if( !firstLineWriting )
            {
                printWriter.println();
            }
            else
            {
                firstLineWriting = false;
            }
            printWriter.write(page[i]);
        }
    }
    // ======================================== //
    
    // ====== FORMAT LINE IF LENGTH < 4 ======= //
    private String formatLine( String line )
    {
        String formatedLine = null;
        
        if( line.length() < codeLineLength )
        {
            if( line.length() == 0 )
            {
                formatedLine = "    ";
            }
            else if( line.length() == 1 )
            {
                formatedLine = line+"   ";
            }
            else if( line.length() == 2 )
            {
                formatedLine = line+"  ";
            }
            else if( line.length() == 3 )
            {
                formatedLine = line+" ";
            }
        }
        else
        {
            formatedLine = line;
        }
        
        return formatedLine;
    }
    // ======================================== //
    
    public void compileBootFile( String inputFile ,String outputFile )
    {   
        if( isCorrect( inputFile ) )
        {   
            FileReader fileReader         = null;
            BufferedReader bufferedReader = null;
            
            FileWriter fileWriter   = null;
            PrintWriter printWriter = null;
            
            int programPagesLeft = programSize;
            
            String line = null;
            
            boolean startCodeCopying = false;
            int codeLineNumber = -1;
            
            boolean startDataCopying = false;
            int dataLineNumber = -1;
            
            try
            {
                fileReader = new FileReader(inputFile);
                bufferedReader = new BufferedReader(fileReader);
                
                fileWriter  = new FileWriter(outputFile);
                printWriter = new PrintWriter(fileWriter);
                
                // ====== PRINT DEVICE PAGE ======= //
                writePageToFile( formatDevicePage() , printWriter , true);
                // ================================ //
                
                // ====== PRINT VECTORS PAGE ====== //
                writePageToFile( formatVectorsPage() , printWriter, false );
                // ================================ //
                
                // ======= PRINT PAGE TABLE ======= //
                for( int i = 0 ; i < pageTableSize ; i++ )
                {
                    if( (programPagesLeft - pageSize ) < 0 )
                    {
                        writePageToFile( formatPageTable( pageTableSize+1 , i , programPagesLeft ) , printWriter , false );
                        programPagesLeft = 0;
                    }
                    else
                    {
                        writePageToFile( formatPageTable( pageTableSize+1 , i , pageSize ) , printWriter , false );
                        programPagesLeft -= pageSize;
                    }
                }
                // ================================ //
                
                // ====== PRINT CODE SEGMENT ====== //
                String[] tempPage = new String[10];
                tempPage = erasePage(tempPage);
                
                while( ( line = bufferedReader.readLine() ) != null )
                {
                    if( getKeywordType( line ) == 2 )
                    {
                        startCodeCopying = true;
                    }
                    else
                    {
                        if( startCodeCopying )
                        {
                            codeLineNumber++;
                            tempPage[codeLineNumber] = formatLine( line );
                        }
                    }
                    
                    if( codeLineNumber == (pageSize-1) )
                    {
                        writePageToFile( tempPage , printWriter , false );
                        codeLineNumber = -1;
                        tempPage = erasePage(tempPage);
                    }
                }
                
                if( codeLineNumber < (pageSize-1) && codeLineNumber != -1 )
                {
                    writePageToFile( tempPage , printWriter , false);
                    codeLineNumber = -1;
                    startCodeCopying = false;
                    tempPage = erasePage(tempPage);
                }
                // ================================ //
                
                // ======= RESET FILE POINTER ===== //
                fileReader.close();
                fileReader = new FileReader(inputFile);
                bufferedReader = new BufferedReader(fileReader);
                // ================================ //
                
                // ======= PRINT DATA SEGMENT ===== //
                while( ( line = bufferedReader.readLine() ) != null  && getKeywordType( line ) != 2 )
                {
                    if( getKeywordType( line ) == 3 )
                    {
                        startDataCopying = true;
                    }
                    else
                    {
                        if( startDataCopying )
                        {
                            dataLineNumber++;
                            tempPage[dataLineNumber] = formatLine( line );
                        }
                    }
                    
                    if( dataLineNumber == (pageSize-1) )
                    {
                        writePageToFile( tempPage , printWriter , false);
                        dataLineNumber = -1;
                        tempPage = erasePage(tempPage);
                    }    
                }
                
                if( dataLineNumber < (pageSize-1) && dataLineNumber != -1)
                {
                    writePageToFile( tempPage , printWriter , false);
                    dataLineNumber = -1;
                    startDataCopying = false;
                    tempPage = erasePage(tempPage);
                }
                // ================================ //
                
            }
            catch( IOException e )
            {
                System.out.println( "Exception: "+ e.getMessage() );
            }
            finally
            {
                try
                {
                    if( fileReader != null )
                    {
                        fileReader.close();
                    }
                    
                    if( fileWriter != null )
                    {
                        fileWriter.close();
                    }
                }
                catch( IOException e )
                {
                    System.out.println("Exception: "+e.getMessage() );
                }
            }
        }
        else
        {
            throw new RuntimeException("Cannot compile!");
        }
    }
}
