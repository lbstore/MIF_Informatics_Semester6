package vu.os.vm.util;

import vu.os.vm.util.Precompiler;
import vu.os.vm.util.ProgramStructure;
import vu.os.vm.exceptions.HDDFormatterException;

import java.util.ArrayList;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;

public class HDDFormatter
{
    private static final String DEVICE = "BOOT";
    
    private static final int MAX_HDD_ADDRESS = 9999;
    private static final int PAGE_SIZE = 10; 
    private static final int LINE_LENGTH = 4; // in bytes
    
    private static final String BOOT_FILE_NAME = "BOOT";
    
    private static final int FILE_NAME_LENGTH = 4;
    private static final int FILE_DESCRIPTION_SIZE = 4; // in words
    
    private static final String FILE_SYSTEM_NAME    = "FS4B";
    private static final String FILE_SYSTEM_VERSION = "0001";
    
    private String[] supportedFileTypes = {"IMG","PRG"};
    
    private ArrayList<String[]> descriptions = null;
    private ArrayList<ProgramStructure> programStructures = null;
    
    private ArrayList<String[]> bootFileStructure = null;
    private String[] bootFileDescription = null;
    
    private Precompiler precompiler = null; 
    
    private String[] fileSystemDescription = null;
    private String[] hddDeviceDescription  = null;
    
    private boolean bootFileAdded = false;
    
    private ArrayList<String> completeFileNames = null;
    
    // ================ CONSTRUCTOR ================ //
    public HDDFormatter()
    {
        descriptions = new ArrayList<String[]>();
        programStructures = new  ArrayList<ProgramStructure>();
        
        completeFileNames = new ArrayList<String>();
        
        precompiler = new Precompiler();
    }
    // ============================================= //
    
    // ====== CHECK IF FILE NAME IS CORRECT ======== //
    private boolean fileNameIsCorrect( String fileName )
    {
        boolean isCorrect = true;
        if( fileName != null )
        {
            if( fileName.length() > FILE_NAME_LENGTH || fileName.length() == 0 )
            {
                isCorrect = false;
            }
            /*
            else if ()
            {
                IF THERE IS MORE RESTRICTIONS    
            }
            */
        }
        else
        {
            isCorrect = false;
        }
        
        return isCorrect;
    }
    // ============================================= //
    
    // ====== CHECK IS FILE TYPE IS CORRECT ======== //
    private int getFileType( String fileType )
    {
        int detectedType = -1;
        
        if( fileType != null )
        {
            for( int i = 0 ; i < supportedFileTypes.length ; i++ )
            {
                if( supportedFileTypes[i].equals( fileType ) )
                {
                    detectedType = i;
                    break;
                }
            }
        }
        
        return detectedType;
    }
    // ============================================= //
    
    // =========== CHECK IF FILE NAME IS UNIQUE ==== //
    private boolean fileExists( String fileName )
    {
        boolean exists = false;
        for( int i = 0 ; i < completeFileNames.size() ; i++ )
        {
            if( completeFileNames.get(i).equals( fileName ) )
            {
                exists = true;
                break;
            }
        }
        
        return exists;
    }
    // ============================================= //
    
    // ====== ADDS NEW FILE FOR FORMATTING ========= //
    public void addHDDFile( String sourceFile , String name , String type ) 
                                                    throws HDDFormatterException
    {
        int fileType = getFileType( type );
        if( (getFileType( type ) >= 0) && fileNameIsCorrect( name ) )
        {
            if( fileType != 0 )
            {
                if( !fileExists( name+"."+type) )
                {
                    completeFileNames.add( name+"."+type );
                    
                    String[] fileDescription  = 
                                              new String[FILE_DESCRIPTION_SIZE];
                    fileDescription = erasePage( fileDescription );
                    fileDescription[0] = name;
                    fileDescription[1] = "."+type;
                    descriptions.add( fileDescription );
                    programStructures.add( precompiler.precompile(sourceFile) );
                }
                else
                {
                    throw new HDDFormatterException("File duplicate found: "+
                                                    name+"."+type);
                }
            }
            else
            {
                throw new HDDFormatterException("IMG file type cannot "+
                                             "be included using this command!");
            }
        }
        else
        {
            throw new HDDFormatterException("Invalid file name or file type!");
        }
    }
    // ============================================= //
    
    // ================ ERASE PAGE ================ //
    private String[] erasePage( String[] page )
    {
        String[] tempPage = page;
        
        if( tempPage != null )
        {
            for( int i = 0 ; i < page.length ; i++ )
            {
                tempPage[i] = "0000";
            }
        }
        
        return tempPage;
    }
    // ============================================ //
    
    // =============== READ BOOT FILE ============= //
    private ArrayList<String[]> readBootFile( String filePath )
                                                    throws HDDFormatterException
    {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        
        String currentLine = null;
        
        int linesCount = 0;
        
        String[] vectorsPage = new String[10];
        vectorsPage = erasePage(vectorsPage);
        
        ArrayList<String[]> tempVectorsStructure = new ArrayList<String[]>();
        
        try
        {
            fileReader = new FileReader( filePath );
            bufferedReader = new BufferedReader(fileReader);
            
            while( ( currentLine = bufferedReader.readLine() ) != null )
            {
                // =============== CHECK LINE'S LENGTH ======== //
                if( currentLine.length() == LINE_LENGTH )
                {
                    vectorsPage[linesCount] = currentLine;
                    linesCount++;
                    
                    if( linesCount == PAGE_SIZE )
                    {
                        linesCount = 0;
                        tempVectorsStructure.add(vectorsPage);
                        vectorsPage = new String[PAGE_SIZE];
                        vectorsPage = erasePage(vectorsPage);
                    }
                }
                else
                {
                    throw new HDDFormatterException("Illegal line found: "+
                                            currentLine+"! Source: BOOT file.");
                }
                // ============================================ //
            }
            
            if( linesCount > 0 )
            {
                tempVectorsStructure.add(vectorsPage);
            }
        }
        catch( IOException e )
        {
            throw new HDDFormatterException("Cannot open "+filePath+" file!");
        }
        finally
        {
            
            // ======== TRY TO CLOSE AN INPUT FILE ========= //
            try
            {
                fileReader.close();
            }
            catch( IOException e )
            {
                throw new HDDFormatterException("Cannot close "
                                                            +filePath+" file!");
            }
            // ============================================= //
            
        }
        
        return tempVectorsStructure;
    }
    // ============================================ //
    
    // ======= ADDS BOOT FILE FOR FORMATTING ======= //
    public void addHDDBootFile( String sourceFile , String name , String type )
                                                    throws HDDFormatterException
    {
        if( name.equals(BOOT_FILE_NAME) && 
            getFileType( type ) == 0 && 
            !bootFileAdded)
        {
            bootFileStructure = readBootFile( sourceFile );
            
            bootFileDescription  = new String[FILE_DESCRIPTION_SIZE];
            bootFileDescription = erasePage( bootFileDescription );
            bootFileDescription[0] = name;
            bootFileDescription[1] = "."+type;
            
            bootFileAdded = true;
        }
        else
        {
            throw new HDDFormatterException("Invalid BOOT file: "
                                                                +name+"."+type);
        }
    }
    // ============================================= //
    
    // ======== NON-NEGATIVE INTEGER TO WORD ======= //
    private String convertNNIntToWord( int nonNegativeInteger )
    {
        String tempString = null;
        
        if( nonNegativeInteger >= 0 && nonNegativeInteger <= MAX_HDD_ADDRESS)
        {
            if( nonNegativeInteger < 10 )
            {
                tempString = "000"+Integer.toString(nonNegativeInteger);
            }
            else if( nonNegativeInteger >= 10 && nonNegativeInteger < 100 )
            {
                tempString = "00"+Integer.toString(nonNegativeInteger);
            }
            else if( nonNegativeInteger >= 100 && nonNegativeInteger < 1000 )
            {
                tempString = "0"+Integer.toString(nonNegativeInteger);
            }
            else
            {
                tempString = Integer.toString(nonNegativeInteger);
            }
        }
        
        return tempString;
    }
    // ============================================= //
    
    // ============ FORMAT DEVICE PAGE ============= //
    private String[] formatDevicePage( int dataAddress , 
                                       int exactHddSize,
                                       int bootFileSize)
    {
        String[] devicePage = new String[PAGE_SIZE];
        devicePage = erasePage(devicePage);
        devicePage[0] = DEVICE;
        devicePage[1] = convertNNIntToWord( exactHddSize-1 );
        devicePage[2] = convertNNIntToWord( dataAddress );
        devicePage[3] = convertNNIntToWord( bootFileSize );
        
        return devicePage;
    }
    // ============================================= //
    
    // ======== FORMAT FILE SYSTEM DESCRIPTION ===== //
    private String[] formatFileSystemPage( int maxFiles , 
                                           int fileDescriptionsAddress,
                                           int fileDataAddress,
                                           int totalFiles,
                                           int totalPagesUsed,
                                           int exactHddSize)
    {
        String[] fileSystemPage = new String[PAGE_SIZE];
        fileSystemPage = erasePage(fileSystemPage);
        fileSystemPage[0] = FILE_SYSTEM_NAME;
        fileSystemPage[1] = FILE_SYSTEM_VERSION;
        fileSystemPage[2] = convertNNIntToWord( maxFiles );
        fileSystemPage[3] = convertNNIntToWord( fileDescriptionsAddress );
        fileSystemPage[4] = convertNNIntToWord( fileDataAddress );
        fileSystemPage[5] = convertNNIntToWord( totalFiles );
        fileSystemPage[6] = convertNNIntToWord( totalPagesUsed );
        fileSystemPage[7] = convertNNIntToWord( exactHddSize-totalPagesUsed );
        
        return fileSystemPage;
    }
    // ============================================= //
    
    // ========= WRITE PAGE TO OUTPUT FILE ========= //
    private void writePageToFile( String[] page , PrintWriter printWriter , 
                                   boolean firstTimeWriting ) throws IOException
    {
        boolean firstLineWriting = firstTimeWriting;
        for( int i = 0 ; i < page.length ; i++ )
        {
            if( !firstLineWriting )
            {
                printWriter.println();
            }
            else
            {
                firstLineWriting = false;
            }
            printWriter.write(page[i]);
        }
    }
    // ============================================= //
    
    // ============= FORMAT FILES' DESCRIPTIONS ==== //
    private void formatDescriptions( int descriptionsAddress, 
                                     int descriptionsPages)
    {
        int freeDataAddress = descriptionsAddress+descriptionsPages;
        
        for( int i = 0 ; i < descriptions.size()+1 ; i++ )
        {
            if( i == 0  )
            {
                bootFileDescription[2] = convertNNIntToWord(freeDataAddress);
                bootFileDescription[3] = convertNNIntToWord(bootFileStructure.size());
                freeDataAddress += bootFileStructure.size();
            }
            else
            {
                descriptions.get(i-1)[2] = convertNNIntToWord(freeDataAddress);
                descriptions.get(i-1)[3] = 
                        convertNNIntToWord(
                              programStructures.get(i-1).getTotalCurrentSize());
                        
                freeDataAddress += 
                               programStructures.get(i-1).getTotalCurrentSize();
            }
        }
    }
    // ============================================= //
    
    // =================== FORMATS HDD ============= //
    public void formatHDD( String destinationFile , int preferedHDDSize )
    {
        if(bootFileAdded && 
           preferedHDDSize <= (MAX_HDD_ADDRESS+1) && 
           preferedHDDSize > 0)
        {
            int totalFiles = programStructures.size()+1; // one is added because there is one additional BOOT file
            
            int pagesUsedForDescriptions = (int)Math.ceil(((float)totalFiles*
                                (float)FILE_DESCRIPTION_SIZE)/(float)PAGE_SIZE);
            
            int maxFiles = (int)Math.floor(((float)pagesUsedForDescriptions*
                                (float)PAGE_SIZE)/(float)FILE_DESCRIPTION_SIZE);
            
            // ======= CALCULATE PAGES USED FOR DATA ======= //
            int pagesUsedForFilesData = bootFileStructure.size();
            for( int i = 0 ; i < programStructures.size() ; i++ )
            {
                pagesUsedForFilesData += 
                                 programStructures.get(i).getTotalCurrentSize();
            }
            // ============================================= //
            
            int totalPagesUsed = pagesUsedForDescriptions +
                                 pagesUsedForFilesData + 2;
            
            // =========== CALCULATE EXACT HDD SIZE ======== //
            int exactHddSize = totalPagesUsed;
            if( preferedHDDSize > totalPagesUsed )
            {
                exactHddSize = preferedHDDSize;
            }
            // ============================================= //
            
            int fileDescriptionsAddress = 2;
            int dataAddress = pagesUsedForDescriptions +fileDescriptionsAddress;
            
            hddDeviceDescription = formatDevicePage( dataAddress , 
                                                     exactHddSize,
                                                     bootFileStructure.size() );
            
            fileSystemDescription = formatFileSystemPage(maxFiles , 
                                                         fileDescriptionsAddress,
                                                         dataAddress,
                                                         totalFiles,
                                                         totalPagesUsed,
                                                         exactHddSize );

            formatDescriptions( fileDescriptionsAddress , 
                                pagesUsedForDescriptions );
            // ================== WRITE HDD ================ //
            FileWriter fileWriter = null;
            PrintWriter printWriter = null;
            
            try
            {
                fileWriter = new FileWriter(destinationFile);
                printWriter = new PrintWriter( fileWriter );
                
                // ============= WRITE DEVICE PAGE ============= //
                writePageToFile( hddDeviceDescription , printWriter , true );
                // ============================================= //
                
                // ========= WRITE FILE SYSTEM PAGE ============ //
                writePageToFile( fileSystemDescription , printWriter , false );
                // ============================================= //
                
                // ========== WRITE FILES' DESCRIPTIONS ======== //
                for( int i = 0 ; i < totalFiles ; i++ )
                {
                    if( i == 0 )
                    {
                        writePageToFile( bootFileDescription , printWriter , false );
                    }
                    else
                    {
                        writePageToFile( descriptions.get(i-1) , printWriter , false );
                    }
                }
                int emptySpaceLeft = pagesUsedForDescriptions*PAGE_SIZE -
                                               totalFiles*FILE_DESCRIPTION_SIZE;
                            
                if( emptySpaceLeft > 0 )
                {
                    String[] tempPage = new String[emptySpaceLeft];
                    tempPage = erasePage( tempPage );
                    writePageToFile( tempPage , printWriter , false );
                    tempPage = null;
                }
                // ============================================= //
                
                // ========== WRITE FILES' DATA ================ //
                for( int i = 0 ; i < totalFiles ; i++ )
                {
                    if( i == 0 )
                    {
                        for( int j = 0 ; j < bootFileStructure.size() ; j++ )
                        {
                            writePageToFile( bootFileStructure.get(j) , printWriter , false );
                        }
                    }
                    else
                    {
                        ProgramStructure prStructure = programStructures.get(i-1);
                        
                        ArrayList<String[]> csSegment = 
                                              prStructure.getCodeSegment();
                                              
                        ArrayList<String[]> dsSegment = 
                                              prStructure.getDataSegment();
                                              
                        ArrayList<String[]> programHeader = 
                                             prStructure.getProgramHeader();
                                             
                        for( int j = 0 ; j < programHeader.size() ; j++ )
                        {
                            writePageToFile( programHeader.get(j) , printWriter , false );
                        }
                        
                        for( int j = 0 ; j < csSegment.size() ; j++ )
                        {
                            writePageToFile( csSegment.get(j) , printWriter , false );
                        }
                        
                        for( int j = 0 ; j < dsSegment.size() ; j++ )
                        {
                            writePageToFile( dsSegment.get(j) , printWriter , false );
                        }
                    }
                }
                // ============================================= //
                
                // =========== FORMAT EMPTY SPACE ============== //
                if( exactHddSize-totalPagesUsed > 0 )
                {
                    String[] emptyPage = new String[PAGE_SIZE];
                    emptyPage = erasePage(emptyPage);
                    
                    for( int i = 0 ; i < exactHddSize-totalPagesUsed ; i++ )
                    {
                        writePageToFile( emptyPage , printWriter , false );
                    }
                }
                // ============================================= //
            }
            catch( IOException e)
            {
                throw new HDDFormatterException("Unable to write to "+
                                                      destinationFile+" file!");
            }
            finally
            {
                // ======== TRY TO CLOSE AN OUTPUT FILE ======== //
                try
                {
                    fileWriter.close();
                }
                catch( IOException e )
                {
                    throw new HDDFormatterException("Cannot close "+
                                                      destinationFile+" file!");
                }
                // ============================================= //
            }
            // ============================================= //
            
            // ============ TEST =========================== //
            /*
            System.out.println();
            System.out.println("========== HDD TEST ==========");
            System.out.println("Total files: "+ totalFiles);
            System.out.println("Pages used for descriptions: "+ pagesUsedForDescriptions);
            System.out.println("Maximum files: "+ maxFiles);
            System.out.println("Pages used for data: "+ pagesUsedForFilesData);
            System.out.println("Data block address: "+ dataAddress);
            System.out.println("Total pages in HDD: "+ totalPagesUsed);
            System.out.println("Exact HDD size: "+ exactHddSize);
            System.out.println("==============================");
            */
            // ============================================= //
        }
        else
        {
            throw new HDDFormatterException("Unable to format!");
        }
    }
    // ============================================= //
}