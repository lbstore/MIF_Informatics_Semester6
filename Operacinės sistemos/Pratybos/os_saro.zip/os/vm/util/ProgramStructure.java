package vu.os.vm.util;

import java.util.ArrayList;

public class ProgramStructure
{
    // Page size is 10 words ( word = 4 bytes )
    private static final int pageSize = 10;
    
    // All sizes below are measured in pages (pageSize)
    private int csRealSize;
    private int dsRealSize; 
    private int ssRealSize;
    
    private int dsCurrentSize;
    
    private String ssdsValue = null;
    
    private int programSize;
    
    private ArrayList<String[]> codeSegment  = null;
    private ArrayList<String[]> dataSegment  = null;
    private ArrayList<String[]> programHeader = null;
    
    // ======== FILE STRUCTURE CONSTRUCTOR ======== //
    public ProgramStructure()
    {
        this.csRealSize = 0;
        this.dsRealSize = 0;
        this.ssRealSize = 0;
        
        this.dsCurrentSize = 0;
        
        this.programSize = 0;
        
        codeSegment   = new ArrayList<String[]>();
        dataSegment   = new ArrayList<String[]>();
        programHeader = new ArrayList<String[]>();
    }
    // ============================================ //
    
    // =========== SET REAL SEGMENT'S SIZE ======== //
    public void setSegmentRealSize( int size , String segment )
    {
        if( segment.equals("CS") )
        {
            this.csRealSize = size;
        }
        else if( segment.equals("DS") )
        {
            this.dsRealSize = size;
        }
        else if( segment.equals("SS") )
        {
            this.ssRealSize = size;
        }
    }
    // ============================================ //
    
    // ========= SET SS:DS VALUE ================== //
    public void setSSDSValue( String ssdsValue )
    {
        this.ssdsValue = ssdsValue;
    }
    // ============================================ //
    
    // ========= SET PROGRAM SIZE ================= //
    public void setProgramSize( int programSize )
    {
        this.programSize = programSize;
    }
    // ============================================ //
    
    // ========= SET CURRENT SEGMENT'S SIZE ======= //
    public void setDSCurrentSize( int dsCurrentSize )
    {
        this.dsCurrentSize = dsCurrentSize;
    }
    // ============================================ //
    
    // ========== RETURN SS:DS VALUE ============== //
    public String getSSDSValue()
    {
        return this.ssdsValue;
    }
    // ============================================ //
    
    // ========== RETURN PROGRAM SIZE ============= //
    public int getProgramSize()
    {
        return this.programSize;
    }
    // ============================================ //
    
    // ==== RETURN CURRENT DATA SEGMENT SIZE ====== //
    public int getDSCurrentSize()
    {
        return this.dsCurrentSize;
    }
    // ============================================ //
    
    // ====== RETURN REAL CODE SEGMENT SIZE ======= //
    public int getCSRealSize()
    {
        return this.csRealSize;
    }
    // ============================================ //
    
    // ====== RETURN REAL DATA SEGMENT SIZE ======= //
    public int getDSRealSize()
    {
        return this.dsRealSize;
    }
    // ============================================ //
    
    // ====== RETURN REAL STACK SEGMENT SIZE ====== //
    public int getSSRealSize()
    {
        return this.ssRealSize;
    }
    // ============================================ //
    
    // ======== RETURN PROGRAM HEADER SIZE ======== //
    public int getProgramHeaderSize()
    {
        return this.programHeader.size();
    }
    // ============================================ //
    
    // ======== RETURN TOTAL CURRENT SIZE ========= //
    public int getTotalCurrentSize()
    {
        return codeSegment.size()+dataSegment.size()+programHeader.size();
    }
    // ============================================ //
    
    // ========== RETURN CODE SEGMENT ============= //
    public ArrayList<String[]> getCodeSegment()
    {
        return this.codeSegment;
    }
    // ============================================ //
    
    // ========== RETURN DATA SEGMENT ============= //
    public ArrayList<String[]> getDataSegment()
    {
        return this.dataSegment;
    }
    // ============================================ //
    
    // ========== RETURN PROGRAM HEADER =========== //
    public ArrayList<String[]> getProgramHeader()
    {
        return this.programHeader;
    }
    // ============================================ //
    
    // ============ ADD PAGE TO A LIST ============ //
    public void addPage( String[] page , String location )
    {
        // String location parameter: "CS,"DS"
        if( location.equals("CS") )
        {
            this.codeSegment.add(page);
        }
        else if( location.equals("DS") )
        {
            this.dataSegment.add(page);
        }
        else if( location.equals("PH") )
        {
            this.programHeader.add(page);
        }
    }
    // ============================================ //
    
    // ############## TEST METHOD ################# //
    public void test()
    {
        System.out.println("=========== CODE SEGMENT ===========" );
        for( int i = 0 ; i < codeSegment.size() ; i++ )
        {
            for( int j=0 ; j < codeSegment.get(i).length ; j++ )
            {
                System.out.println( codeSegment.get(i)[j] );
            }
        }
        System.out.println("=========== DATA SEGMENT ===========" );
        for( int i = 0 ; i < dataSegment.size() ; i++ )
        {
            for( int j=0 ; j < dataSegment.get(i).length ; j++ )
            {
                System.out.println( dataSegment.get(i)[j] );
            }
        }
        System.out.println("============= HEADER ===============" );
        for( int i = 0 ; i < programHeader.size() ; i++ )
        {
            for( int j=0 ; j < programHeader.get(i).length ; j++ )
            {
                System.out.println( programHeader.get(i)[j] );
            }
        }
        
        System.out.println("=========== PROGRAM INF ============" );
        System.out.println("Program size: "+programSize);
        System.out.println();
        System.out.println("CS real size: "+csRealSize);
        System.out.println("DS real size: "+dsRealSize);
        System.out.println("SS real size: "+ssRealSize);
        System.out.println();
        System.out.println("DS current size: "+dsCurrentSize);
        System.out.println();
        System.out.println("SS:DS value: "+ssdsValue);
        System.out.println("Total current size: "+ getTotalCurrentSize() );
    }
    // ############################################ //
}
