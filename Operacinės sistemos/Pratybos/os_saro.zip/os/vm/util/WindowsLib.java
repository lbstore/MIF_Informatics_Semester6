package vu.os.vm.util;

public class WindowsLib {

    public WindowsLib() {

        try {
            System.load(new java.io.File(".").getCanonicalPath() + "\\util\\dll\\InOut.dll");
        } catch (java.io.IOException e) {
            System.out.println("WinConsole: " + e);
        }

    }
    
    public native boolean inputBufferIsCharAvailable();
    public native char inputBufferGetChar();
}