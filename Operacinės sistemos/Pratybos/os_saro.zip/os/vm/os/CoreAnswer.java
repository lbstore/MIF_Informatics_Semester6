package vu.os.vm.os;

import vu.os.vm.os.descriptors.ProcessDescriptor;

public class CoreAnswer {
    
    public Integer  creatorId = null;
    public Integer  resourcePart = null;
    public String   resourceElement = null;
    
    public Integer  createdProcessId = null;
    public Integer  createdResourceId = null;
   
    public ProcessDescriptor stoppedProcessDescriptor = null;
   
    public CoreAnswer() {
    }
}