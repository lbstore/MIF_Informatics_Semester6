package vu.os.vm.os.descriptors;

import vu.os.vm.exceptions.MOSException;
import vu.os.vm.util.Convert;

import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;
import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.CurrentResourceElement;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.os.Constant;

import java.util.LinkedList;
import java.util.HashMap;

public class ResourceDescriptorMemory extends ResourceDescriptor {

    /*
    public String                      name = null;
    public Boolean                     reusable = null;
    public Integer                     creator = null;
    public LinkedList<ResourceElement> elements = null;
    
        element.resourcePart : puslapio adresas
        element.resourceElement : ""
        element.creatorId : creatorId
    
    public PriorityQuene <WaitingProcessElement> waitingProcessList = null;
    
        waitingProcess.processId = laukiantis procesas
        waitingProcess.resourcePart = 1xx arba 2xx
    
    */
    
    /*
        USER MEMORY:
            REQUESTR: 
                resourcePart - 1xx, 2xx : 1-atmintis 1-99, 2-atmintis 100-9999. xx - prasomas puslapiu kiekis
            
            FREER:
                resourcePart - 0
                resourceElement - p1|p2|p3|..|pn, pi: puslapio adresas atlaisvinimui
    */
    
    private String listSeperator = "|";
    
    public int[] DISTRIBUTOR(int resourceId, HashMap <Integer, ProcessDescriptor> processes) {
        if (!reusable) { throw new MOSException("DISTRIBUTOR USER MEMORY: boolean reusable must be TRUE"); }
        int priority = Constant.maxPriority;
        
        LinkedList<Integer> servedProcesses = new LinkedList<Integer>();
        ResourceElement element = null;
        WaitingProcessElement waitingProcess;
        
        //System.out.println("DISTRIBUTOR USER MEMORY: elements.size():"+elements.size());

        // WHILE: BEGA PER VISUS PRIORITETUS
        while (priority >= 0 && elements.size() > 0) {
            //System.out.println("DISTRIBUTOR USER MEMORY: waitingProcessList prior:"+priority+" size:"+waitingProcessList.size(priority));
            
            //----------------------------------------------------------------//
            // WHILE: BEGA PER VISUS LAUKIANCIUS TOKIO PRIORITETO PROCESUS
            int iProc = waitingProcessList.size(priority)-1;
            while(iProc >= 0) {
                
                // waitingProcess - resurso laukiantis procesas
                waitingProcess = waitingProcessList.peekElement(priority, iProc);
                
                // KO PROCESAS NORI?
                if (waitingProcess.resourcePart < 100) { throw new MOSException("DISTRIBUTOR USER MEMORY: incorrect request resourcePart: "+waitingProcess.resourcePart); }
                
                int requestedAddressMinimum = 0;
                int requestedAddressMaximum = 0;
                
                if ((waitingProcess.resourcePart / 100) == 1) {
                    requestedAddressMinimum = 1;
                    requestedAddressMaximum = 99;
                } else if ((waitingProcess.resourcePart / 100) == 2) {
                    requestedAddressMinimum = 100;
                    requestedAddressMaximum = 9999;
                } else {
                    throw new MOSException("DISTRIBUTOR USER MEMORY: incorrect request resourcePart: "+waitingProcess.resourcePart);
                }
                
                int requestedPageCount = waitingProcess.resourcePart % 100;

                //System.out.println("DISTRIBUTOR USER MEMORY: requestedAddressMinimum: "+requestedAddressMinimum+" requestedAddressMaximum: "+requestedAddressMaximum+" requestedPageCount: "+requestedPageCount);

                // WHILE: BEGA PER VISUS RESURSO ELEMENTUS (PER TURIMUS PUSLAPIUS)
                LinkedList<Integer> potentialElements = new LinkedList<Integer>();
                
                boolean foundAllRequestedPages = false;
                for(int i=0; i < elements.size() && !foundAllRequestedPages; i++) {
                    // PASIIMA EINAMAJI ELEMENTA 
                    element = elements.get(i);
                    
                    // AR PUSLAPIS TINKAMAS?
                    if (requestedAddressMinimum <= element.resourcePart &&
                        element.resourcePart <= requestedAddressMaximum) {
                            
                            // PATINKRINIMAS ar prasantis resursas dar neturi tokio tuslapio
                            if (processes.get(waitingProcess.processId).ramResources.contains(element.resourcePart)) { throw new MOSException("DISTRIBUTOR USER MEMORY: process "+processes.get(waitingProcess.processId).name+" allready have UserMemmory resource: "+element.resourcePart); }
                            
                            potentialElements.add(i);
                        }
                        
                    if (potentialElements.size() >= requestedPageCount) {
                        //System.out.println("DISTRIBUTOR USER MEMORY: found potential pages "+potentialElements.size());
                        foundAllRequestedPages = true;
                    }
                }
                
                // JEI PROCESAS GAVO VISUS PRASYTUS PUSLAPIUS, JAM JIE PASKIRIAMI
                if (foundAllRequestedPages) {
                    ProcessDescriptor process = processes.get(waitingProcess.processId);
                
                    String addressList = new String();
                    for (int i=0;i<potentialElements.size();i++) {
                        int pageAddress = elements.get(potentialElements.get(i)-i).resourcePart;
                        
                        addressList += Convert.toWord(pageAddress);             // puslapiai (word) dedami i sarasa, kuris bus grazinamas procesui
                        process.ramResources.add(pageAddress);                  // puslapiai (Integer) dedami i proceso deskriptoriu
                        
                        //System.out.println("\n@ DISTRIBUTOR USERMEM: served process process:"+process.name+" page:"+pageAddress);
                        
                        if ((i+1)<potentialElements.size()) {
                            addressList += listSeperator;
                        }
                        elements.remove(potentialElements.get(i)-i);            // ka pasiiemem ta pasalinam
                    }

                    CoreAnswer answer = new CoreAnswer();
                    
                    answer.creatorId = Constant.ProcessNone;
                    answer.resourcePart = waitingProcess.resourcePart;
                    answer.resourceElement = addressList;
                        
                    process.resource = answer;
                    
                    servedProcesses.add(waitingProcess.processId);
                    
                    waitingProcessList.remove(waitingProcess);
                }
                iProc--;
            }
            //----------------------------------------------------------------//
            priority--;
        }
        
        int[] returnServedProcesses = new int[servedProcesses.size()];
        for (int i=0; i<servedProcesses.size(); i++) {
            returnServedProcesses[i] = servedProcesses.get(i);
        }
        return returnServedProcesses;
    }
}