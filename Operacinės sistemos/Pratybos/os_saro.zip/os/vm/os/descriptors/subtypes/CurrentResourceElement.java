package vu.os.vm.os.descriptors.subtypes;

public class CurrentResourceElement {

    public Integer creatorId = null;
    public Integer resourceId = null;
    public Integer resourcePart = null;
    public String  resourceElement = null;

}