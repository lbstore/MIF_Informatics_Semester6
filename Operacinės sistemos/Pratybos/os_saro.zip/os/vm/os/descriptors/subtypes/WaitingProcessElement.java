package vu.os.vm.os.descriptors.subtypes;

public class WaitingProcessElement {
    
    public Integer processId = null;
    public Integer resourcePart = null;

}