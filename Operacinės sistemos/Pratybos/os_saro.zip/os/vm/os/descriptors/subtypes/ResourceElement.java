package vu.os.vm.os.descriptors.subtypes;

public class ResourceElement {

    public Integer creatorId = null;
    public Integer resourcePart = null;
    public String  resourceElement = null;

}