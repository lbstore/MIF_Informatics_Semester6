package vu.os.vm.os.descriptors.subtypes;

import vu.os.vm.core.Register;
import vu.os.vm.core.VirtualCPUCore;

public class CPUState {

    // CPU STATE SAUGO VISUS REGISTRUS ISSKYRUS IOI ir CAST - tai sisteminiai registrai, jie negali buti perdengiamai

    public Register R = null;
    public Register U = null;
    public Register C = null;
    public Register IC = null;
    public Register DS = null;
    public Register SS = null;
    public Register SP = null;
    public Register TIMER = null;
    public Register MODE = null;
    public Register PTR = null;
    public Register PI = null;
    public Register SI = null;
    public Register TI = null;
    //public Register CAST = null;
    //public Register IOI = null;
    
    public CPUState( VirtualCPUCore cpuCore ) {
        this.R = cpuCore.R.getCopy();
        this.U = cpuCore.U.getCopy();
        this.C = cpuCore.C.getCopy();
        this.IC = cpuCore.IC.getCopy();
        this.DS = cpuCore.DS.getCopy();
        this.SS = cpuCore.SS.getCopy();
        this.SP = cpuCore.SP.getCopy();
        this.TIMER = cpuCore.TIMER.getCopy();
        this.MODE = cpuCore.MODE.getCopy();
        this.PTR = cpuCore.PTR.getCopy();
        this.PI = cpuCore.PI.getCopy();
        this.SI = cpuCore.SI.getCopy();
        this.TI = cpuCore.TI.getCopy();
        //this.CAST = cpuCore.CAST.getCopy();
        //this.IOI = cpuCore.IOI.getCopy();
    }
    
    public CPUState() {
    }
    
    public void loadCPUState( VirtualCPUCore cpuCore ) {
        //System.out.println("LOAD CPU STATE");
        cpuCore.R.set(this.R.getCopy());
        cpuCore.U.set(this.U.getCopy());
        cpuCore.IC.set(this.IC.getCopy());
        cpuCore.DS.set(this.DS.getCopy());
        cpuCore.SS.set(this.SS.getCopy());
        cpuCore.SP.set(this.SP.getCopy());
        cpuCore.TIMER.set(this.TIMER.getCopy());
        cpuCore.MODE.set(this.MODE.getCopy());
        cpuCore.PTR.set(this.PTR.getCopy());
        cpuCore.PI.set(this.PI.getCopy());
        cpuCore.SI.set(this.SI.getCopy());
        cpuCore.TI.set(this.TI.getCopy());
        //cpuCore.CAST.set(this.CAST.getCopy());
        //cpuCore.IOI = this.IOI.getCopy();
    }
    
    public void saveCPUState( VirtualCPUCore cpuCore ) {
        //System.out.println("SAVE CPU STATE");
        this.R = cpuCore.R.getCopy();
        this.U = cpuCore.U.getCopy();
        this.C = cpuCore.C.getCopy();
        this.IC = cpuCore.IC.getCopy();
        this.DS = cpuCore.DS.getCopy();
        this.SS = cpuCore.SS.getCopy();
        this.SP = cpuCore.SP.getCopy();
        this.TIMER = cpuCore.TIMER.getCopy();
        this.MODE = cpuCore.MODE.getCopy();
        this.PTR = cpuCore.PTR.getCopy();
        this.PI = cpuCore.PI.getCopy();
        this.SI = cpuCore.SI.getCopy();
        this.TI = cpuCore.TI.getCopy();
        //this.CAST = cpuCore.CAST.getCopy();
        //this.IOI = cpuCore.IOI.getCopy();
    }
}