package vu.os.vm.os.descriptors;

import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;

import vu.os.vm.util.PriorityQuene;
import vu.os.vm.os.Constant;

import java.util.LinkedList;

import java.util.HashMap;

public abstract class ResourceDescriptor {

    public String                      name = null;
    public Boolean                     reusable = null;
    public Integer                     creator = null;
    public LinkedList<ResourceElement> elements = null;
    public PriorityQuene <WaitingProcessElement> waitingProcessList = null;
 
    public ResourceDescriptor() {
    }
    
    public int[] DISTRIBUTOR(int resourceId, HashMap <Integer, ProcessDescriptor> processes) {
        /*
            da fun is here
        */
        return new int[1];
    }
}