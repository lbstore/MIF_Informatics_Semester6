package vu.os.vm.os.descriptors;

import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;
import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.CurrentResourceElement;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.CoreAnswer;

import vu.os.vm.os.Constant;

import java.util.LinkedList;
import java.util.HashMap;

import vu.os.vm.os.ProcessId;

public class ResourceDescriptorMessage extends ResourceDescriptor {
    
    /*
    public String                      name = null;
    public Boolean                     reusable = null;
    public Integer                     creator = null;
    public LinkedList<ResourceElement> elements = null;
    public PriorityQuene <WaitingProcessElement> waitingProcessList = null;
    */
    
    /*
        MESSAGES:
            REQUESTR: 
                resourcePart - laukiancio proceso id. 
            
            FREER:
                resourcePart - gavejo proceso id. 0 - jei siunciama betkuriam laukianciam.
                resourceElement - pagal pranesimo tipa
    */
    
    public int[] DISTRIBUTOR(int resourceId, HashMap <Integer, ProcessDescriptor> processes) {
        //System.out.println("~~~~~DISTRIBUTOR message");
        if (reusable) { throw new MOSException("DISTRIBUTOR MESSAGE: messages mus be not reusable"); }
        
        int priority = Constant.maxPriority;
        
        LinkedList<Integer> servedProcesses = new LinkedList<Integer>();
        
        ResourceElement element = null;
        
        //System.out.println("DISTRIBUTOR: elements.size():"+elements.size());
        
        WaitingProcessElement waitingProcess=null;
        while (priority >= 0 && elements.size() > 0) {
            //System.out.println("DISTRIBUTOR: waitingProcessList prior:"+priority+" size:"+waitingProcessList.size(priority));
            for (int i = waitingProcessList.size(priority)-1; i >= 0; i--) {

                waitingProcess = waitingProcessList.peekElement(priority, i);
                int r = 0;
                boolean processNotServed = true;
                while( r < elements.size() && processNotServed ) {
                
                    element =  elements.get(r);
                    if ((element.resourcePart == waitingProcess.processId) || element.resourcePart == 0) {
                    
                    /*
                        if (ProcessId.CurrentProcess == 3) {
                            System.out.println("~~~~~~DISTRIBUTOR: waitingProcessList size " +waitingProcessList.size());
                        }   
                        */
                        
                        CoreAnswer answer = new CoreAnswer();
                        
                        answer.creatorId = element.creatorId;
                        answer.resourcePart = element.resourcePart;
                        answer.resourceElement = element.resourceElement;
                        
                        processes.get(waitingProcess.processId).resource = answer;
                        
                        servedProcesses.add(waitingProcess.processId);
                        
                        waitingProcessList.remove(waitingProcess);

                        elements.remove(r);
                        r--;
                        processNotServed = false;
                    }
                    r++;
                }
            }
            priority--;
        }
        
        int[] returnServedProcesses = new int[servedProcesses.size()];
        
        for (int i=0; i<servedProcesses.size(); i++) {
            returnServedProcesses[i] = servedProcesses.get(i);
        }
        
        return returnServedProcesses;
    }
}