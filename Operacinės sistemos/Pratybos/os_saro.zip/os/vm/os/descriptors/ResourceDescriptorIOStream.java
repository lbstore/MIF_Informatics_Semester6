package vu.os.vm.os.descriptors;

import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;
import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.CurrentResourceElement;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.os.Constant;

import java.util.HashMap;
import java.util.LinkedList;

import vu.os.vm.exceptions.MOSException;

public class ResourceDescriptorIOStream extends ResourceDescriptor {

    
    /*
    public String                      name = null;
    public Boolean                     reusable = null;
    public Integer                     creator = null;
    public LinkedList<ResourceElement> elements = null;
    public PriorityQuene <WaitingProcessElement> waitingProcessList = null;
    */
    
    /*
        IOSTREAM:
            REQUESTR: 
                resourcePart - 1,2,3
            
            FREER:
                resourcePart - 1,2,3 (negalima atlaisvinti jei neturi tokio resurso dalies, arba jei tokia jau yra)
                resourceElement - ""
    */
    
    public int[] DISTRIBUTOR(int resourceId, HashMap <Integer, ProcessDescriptor> processes) {
        if (!reusable) { throw new MOSException("DISTRIBUTOR IOStream: boolean reusable must be TRUE"); }
        //System.out.println("DISTRIBUTOR IOStream");
        
        int priority = Constant.maxPriority;
        
        LinkedList<Integer> servedProcesses = new LinkedList<Integer>();
        LinkedList<Integer> elementResourcePart =  new LinkedList<Integer>();
        
        for (int i=0; i<elements.size();i++) {
            elementResourcePart.add(elements.get(i).resourcePart);
        }
        
        ResourceElement element = null;
        
        //System.out.println("DISTRIBUTOR: elements.size():"+elements.size());

        WaitingProcessElement waitingProcess;
        while (priority >= 0 && elements.size() > 0) {
            //System.out.println("DISTRIBUTOR: waitingProcessList prior:"+priority+" size:"+waitingProcessList.size(priority));
            
            int i = waitingProcessList.size(priority)-1;
            while(i >= 0) {

                waitingProcess = waitingProcessList.peekElement(priority, i);
                
                int r = 0;
                while( r < elements.size() ) {
                    element =  elements.get(r);
                    //System.out.println("DISTRIBUTOR IOS: i:"+i+" r:"+r);
                    //System.out.println("DISTRIBUTOR: resourcePart needed: "+waitingProcess.resourcePart+" resource has: "+element.resourcePart);
                    if (element.resourcePart == waitingProcess.resourcePart) {
                    
                        if (((waitingProcess.resourcePart == Constant.InputOutputStream && 
                             elementResourcePart.contains(Constant.InputStream) &&
                             elementResourcePart.contains(Constant.OutputStream)) ||
                            (waitingProcess.resourcePart == Constant.InputStream &&
                             elementResourcePart.contains(Constant.InputOutputStream)) ||
                            (waitingProcess.resourcePart == Constant.OutputStream &&
                             elementResourcePart.contains(Constant.InputOutputStream)))) {
                             
                            //System.out.println("DISTRIBUTOR: resourcePart needed: "+waitingProcess.resourcePart+" resource has: "+element.resourcePart);
                            
                            // PATINKRINTI ar prasantis resursas dar neturi tokio elemento
                            ProcessDescriptor process = processes.get(waitingProcess.processId);
                            for(int j = 0; j < process.currentResources.size(); j++) {
                                if (process.currentResources.get(j).resourceId == resourceId) {
                                    if (process.currentResources.get(j).resourcePart == waitingProcess.resourcePart) {
                                        throw new MOSException("DISTRIBUTOR IOStream: process pid:"+waitingProcess.processId+" name:"+process.name+" allready have resourcePart:"+ waitingProcess.resourcePart);
                                    }
                                }
                            }
                            
                            // NETURI TOKIO ELEMENTO DAR
                            
                            CurrentResourceElement res = new CurrentResourceElement();
                            
                            res.creatorId = element.creatorId;
                            res.resourceId = resourceId;
                            res.resourcePart = element.resourcePart;
                            res.resourceElement = element.resourceElement;
                            
                            processes.get(waitingProcess.processId).currentResources.add(res);
                            
                            CoreAnswer answer = new CoreAnswer();
                            
                            answer.creatorId = element.creatorId;
                            answer.resourcePart = element.resourcePart;
                            answer.resourceElement = element.resourceElement;
                            
                            processes.get(waitingProcess.processId).resource = answer;
                            
                            servedProcesses.add(waitingProcess.processId);
                            
                            waitingProcessList.remove(waitingProcess);
                            //i++;
                            elements.remove(r);
                            elementResourcePart.removeFirstOccurrence(waitingProcess.resourcePart);
                            r--;
                        }
                    }
                    r++;
                }
                i--;
            }
            priority--;
        }
        
        int[] returnServedProcesses = new int[servedProcesses.size()];
        
        for (int i=0; i<servedProcesses.size(); i++) {
            returnServedProcesses[i] = servedProcesses.get(i);
        }
        
        return returnServedProcesses;
    }
}