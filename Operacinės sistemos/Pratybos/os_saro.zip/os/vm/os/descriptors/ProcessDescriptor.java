package vu.os.vm.os.descriptors;

import vu.os.vm.os.descriptors.subtypes.CPUState;
import vu.os.vm.os.descriptors.subtypes.CurrentResourceElement;
import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;
import vu.os.vm.os.processes.ProcessBase;
import vu.os.vm.os.CoreAnswer;


import java.util.LinkedList;

public class ProcessDescriptor {

    public String               name = null;
    public CPUState             cpu = null;
    public LinkedList<Integer>  ramResources = null;
    public LinkedList<CurrentResourceElement> currentResources = null;
    public LinkedList<Integer>  createdResources = null;
    public Integer              state = null;
    public Integer              listIn = null;  // -1 - ReadyProcessList, 1, 2, 3 .. ResourceId kurio sarase laukia
    public Integer              parentProcess = null;
    public LinkedList<Integer>  childProcesses = null;
    public Integer              priority = null;
    
    public ProcessBase          systemProcess = null;
    
    public CoreAnswer           resource = null;
 
    public ProcessDescriptor() {
    }
}