//----------------------------------------------------------------------------//
//--------------------------- !! NOT FINISHED !! -----------------------------//
//----------------------------------------------------------------------------//

package vu.os.vm.os.processes;

import vu.os.vm.os.Constant;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

public class ProcessCommandLine extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessCommandLine( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private boolean printWorkProcess = false;
    private boolean printMessages = true;
    
    private String commandLineTask = "READTASK";
    private String commandLineTaskItitiate = "READTASKINITIATE";
    
    private String commandList = "list";
    private String commandRun = "run";
    private String commandTerminate = "kill";
    private String commandShutDown = "shutdown";
    private String commandLeaveProcess = "leave";
    private String commandHelp = "help";
    
    private String commandHeadlineInput =  "CommandLine input";
    private String commandHeadlineOutput = "CommandLine output";
    
    private String textWriteCommand = "Write command:";
    private String textToPrint = textWriteCommand;
    private String textInitiation = "�           Welcome to MOS 1.0 !� �write command:";
    
    private String userCommand = null;
    
    private String userProgramToRun = null; 
    private String[] userCommandArgs = null;
    
    private boolean writeLine = true;
    private boolean readLine = true;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                {
                    returnTask.REQUESTR(ResourceId.CommandLineTask, ProcessId.CurrentProcess);
                    break;
                }
                case 2:
                {
                    if (resource.resourceElement == null) { throw new MOSException("CommandLine: CommandLineTask.resourceElement == null"); }
                    if (!resource.resourceElement.equalsIgnoreCase(commandLineTask)
                        && !resource.resourceElement.equalsIgnoreCase(commandLineTaskItitiate)) { throw new MOSException("CommandLine: unknown commandLineTask: "+resource.resourceElement); }
                    
                    print("@ CommandLine: GOT CommandLineTask! : "+resource.resourceElement);
                    
                    if (resource.resourceElement.equalsIgnoreCase(commandLineTaskItitiate)) {
                        textToPrint = textInitiation;
                    } else {
                        textToPrint = textWriteCommand;
                    }
                    
                    writeLine = true;
                    readLine = true;
                    userCommand = null;
                    
                    break;
                }
                //------------------------------------------------------------//
                //-- INPUT/OUTPUT --------------------------------------------//
                case 3:
                {
                    print("@ CommandLine: case: "+position);
                    returnTask.REQUESTR(ResourceId.InputOutputStream, Constant.InputOutputStream);
                    break;
                }                    
                case 4:
                {
                    print("@ CommandLine: case: "+position);
                    // PRINT TEXT
                    if (writeLine) {
                        if (resource.resourceElement == null) { throw new MOSException("CommandLine: failed to get resource at case 3"); }
                        returnTask.FREER(ResourceId.InputOutputTask, commandHeadlineOutput+"|WRITELINE|"+textToPrint, ProcessId.InputOutputManager);
                    }
                    break;
                }
                case 5:
                {
                    print("@ CommandLine: case: "+position);
                    if (writeLine) {
                        returnTask.REQUESTR(ResourceId.InputOutputTaskFinished, ProcessId.CurrentProcess);
                    }
                    break; 
                }
                case 6:
                {
                    print("@ CommandLine: case: "+position);
                    // READ TEXT
                    if (readLine) {
                        if (resource.resourceElement == null) { throw new MOSException("CommandLine: failed to get InputOutputTaskFinished"); }
                        returnTask.FREER(ResourceId.InputOutputTask, commandHeadlineInput+"|READLINE", ProcessId.InputOutputManager);
                    }
                    break;
                }
                case 7:
                {
                    print("@ CommandLine: case: "+position);
                    if (readLine) {
                        returnTask.REQUESTR(ResourceId.InputOutputTaskFinished, ProcessId.CurrentProcess);
                    }
                    break; 
                }
                case 8:
                {
                    print("@ CommandLine: case: "+position);
                    if (readLine) {
                        if (resource.resourceElement == null) { throw new MOSException("CommandLine: failed to get InputOutputTaskFinished"); }
                        if (!resource.resourceElement.substring(0,1).equals("0")) { throw new MOSException("CommandLine: error InputOutputTaskFinished"); }
                        userCommand = resource.resourceElement.substring(2,resource.resourceElement.length());
                    }
                    returnTask.FREER(ResourceId.InputOutputStream, "", Constant.InputOutputStream);
                    break;
                }
                //-- INPUT/OUTPUT --------------------------------------------//
                //------------------------------------------------------------//
                case 9:
                {
                    print("@ CommandLine: analyze: ["+userCommand+"]");
                    textToPrint = textWriteCommand;
                    if (readLine) {
                        // ANALYZING USERCOMMAND
                        userCommandArgs = userCommand.split(" ");
                        userCommand = userCommandArgs[0];
                        
                        if (userCommand.equalsIgnoreCase(commandList)) {
                            returnTask.FREER(ResourceId.FileSystemTask, "LIST", ProcessId.FileSystemManager);
                            GOTO(10);
                            break;
                        } else if (userCommand.equalsIgnoreCase(commandRun)) {
                            if (userCommandArgs.length <= 1) {
                                textToPrint = "Bad \"run p\" syntax: p - program file name.";
                                writeLine = true;
                                readLine = true;
                                GOTO(3);
                            } else {
                                userProgramToRun = userCommandArgs[1];
                                returnTask.FREER(ResourceId.FileSystemTask, "LIST", ProcessId.FileSystemManager);
                                GOTO(12);
                            }
                        } else if (userCommand.equalsIgnoreCase(commandShutDown)) {
                            returnTask.FREER(ResourceId.WorkFinished, "User shutdown", ProcessId.StartStop);
                        } else if (userCommand.equals(commandLeaveProcess)) {
                            textToPrint = "Leaving command line..";
                            writeLine = true;
                            readLine = false;
                            GOTO(3);
                        } else if (userCommand.equalsIgnoreCase(commandHelp)) {
                            textToPrint = "Possible commands:�list,run,shutdown,leave,help.�To call OS (CMD) while running user �program press \"O\".";
                            writeLine = true;
                            readLine = true;
                            GOTO(3);
                        } else if (userCommand.equalsIgnoreCase(commandTerminate)) {
                            if (userCommandArgs.length <= 1) {
                                textToPrint = "Bad \"kill p\" syntax: p - JobGovernor process id.";
                                writeLine = true;
                                readLine = true;
                                GOTO(3);
                            } else {
                                returnTask.FREER( ResourceId.ExternalTask, "DESTROYJB|"+"PROGRAMA"+"|"+userCommandArgs[1], ProcessId.MainProcess );
                                writeLine = true;
                                readLine = true;
                                GOTO(3);
                            }
                        } else {
                            textToPrint = "Unknown command. Type help.";
                            writeLine = true;
                            readLine = true;
                            GOTO(3);
                        }
                    } else {
                        print("CommandLine: readLine == null, returning to idle");
                        GOTO(1);
                    }
                    break;
                }
                case 10:
                {
                    // LIST HDD FILES
                    print("@ CommandLine: case: "+position);
                    returnTask.REQUESTR(ResourceId.FileSystemTaskFinished, ProcessId.CurrentProcess);
                    break;
                }
                case 11:
                {
                    print("@ CommandLine: case: "+position);
                    // GET FILE LIST
                    print("CommandLine: getting for list of files");
                    if (resource.resourceElement == null) { throw new MOSException("CommandLine: list of files did not arrive"); }
                    
                    String[] fileList = resource.resourceElement.split("\\|");
                    
                    textToPrint = "List of files in HDD:�";
                    for (int i=0; i<fileList.length;i++) {
                        textToPrint += fileList[i]+"�";
                    }

                    GOTO(3);

                    break;
                }      
                case 12:
                {         
                    // RUN PROGRAM
                    print("@ CommandLine: case: "+position);
                    returnTask.REQUESTR(ResourceId.FileSystemTaskFinished, ProcessId.CurrentProcess);
                    break;
                }
                case 13:
                {         
                    print("@ CommandLine: case: "+position);
                    if (resource.resourceElement == null) { throw new MOSException("CommandLine: list of files did not arrive (run program)"); }
                    
                    String[] fileList = resource.resourceElement.split("\\|");
                    
                    boolean fileNameFound = false;
                    int fileIndex = 0;
                    for (int i=0; i<fileList.length && !fileNameFound;i++) {
                        if (fileList[i].equalsIgnoreCase(userProgramToRun)) {
                            fileIndex = i;
                            fileNameFound = true;
                        }
                    }
                    if (fileNameFound) {
                        if (userProgramToRun.substring(4,8).equalsIgnoreCase(".PRG")) {
                            returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|"+fileList[fileIndex]+"|2", ProcessId.MainProcess );
                            textToPrint = "Starting "+userProgramToRun+"..";
                            writeLine = true;
                            readLine = true;
                            GOTO(3);
                        } else {
                            textToPrint = "Non executable file: "+userProgramToRun;
                            writeLine = true;
                            readLine = true;
                            GOTO(3);
                        }
                    } else {
                        textToPrint = "Program file not found.";
                        writeLine = true;
                        readLine = true;
                        GOTO(3);
                    }
                    break;
                }
                default:
                    throw new MOSException("CommandLine: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    
    private void print(Object o) {
        if (printWorkProcess) {
            System.out.println(o.toString());
        }
    }
    
    private void printMessage(Object o) {
        if (printMessages) {
            System.out.println(o.toString());
        }
    }
}