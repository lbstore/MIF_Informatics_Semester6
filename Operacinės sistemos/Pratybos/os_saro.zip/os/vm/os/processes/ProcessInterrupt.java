//----------------------------------------------------------------------------//
//--------------------------- !! NOT FINISHED !! -----------------------------//
//----------------------------------------------------------------------------//

package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.core.Register;

import vu.os.vm.exceptions.MOSException;

import vu.os.vm.util.Convert;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.ui.GUI;

public class ProcessInterrupt extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessInterrupt( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    
    public static final int InputDeviceChannel = 0;
    public static final int OutputDeviceChannel = 1;
    public static final int HddDeviceChannel = 2;

        
    private String specialOsSymbol = "o"; 
    private String specialOsSymbolUpperCase = "O";
    
    private Integer interrupt = null;
    
    private Register interruptRegisterIOI = new Register(3);
    private Integer parentProcess = null;
    private String interruptName = null;
    
    private String listSeparatorSplit = "\\|";
    private String listSeparator = "|";
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                {
                    //System.out.println("@ Interrupt: waiting for InterruptTask");
                    returnTask.REQUESTR(ResourceId.InterruptTask, ProcessId.CurrentProcess);
                    break;
                }
                case 2:
                {
                    if (resource.resourceElement == null) { throw new MOSException("Interrupt: resource InterruptTask did not arrive"); }
                    
                    //System.out.println("@ Interrupt: got InterruptTask"+resource.resourceElement);
                    
                    String[] splitElement = resource.resourceElement.split(listSeparatorSplit);
                    if (splitElement.length != 3) { throw new MOSException("Interrupt: unknown interrupt: "+resource.resourceElement);  }
                    
                    interruptName = splitElement[0];
                    interruptRegisterIOI.set(splitElement[1]);
                    parentProcess = Convert.toInt(splitElement[2]);
                    
                    if ((interruptName.equals("PI") || interruptName.equals("SI")) && parentProcess != ProcessId.StartStop) {
                        returnTask.FREER(ResourceId.InterruptEvent, interruptName+listSeparator+splitElement[1], parentProcess);
                        GOTO(1);
                        break; 
                    } else if (interruptName.equals("IOI")) {
                        if (interruptRegisterIOI.getByte(InputDeviceChannel).equals("0") == false) {
                            if (interruptRegisterIOI.getByte(InputDeviceChannel).equals("3") == false) {
                                cpu.IOI.setByte(InputDeviceChannel, "0");
                                returnTask.FREER(ResourceId.InterruptEvent, interruptName+listSeparator+interruptRegisterIOI.getByte(InputDeviceChannel), ProcessId.InputDevice);
                                GOTO(1);
                                break; 
                            } else {
                                //System.out.println("@ Interrupt: got IRQ");
                                // IRQ
                                Boolean foundSpecialSymbol = null;
                                if (cpu.IOI.getByte(0).equals("3")) {
                                    String[] page;

                                    page = cpu.chn[0].getDevice().readPage(2);
                                    
                                    //for (int i=0; i<page.length; i++) System.out.println("@ Interrupt: input int 3, intPage: "+page[i]);
                                    
                                    for (int i=0; i<page.length && foundSpecialSymbol==null; i++) {
                                        if (page[i].contains(specialOsSymbol) || page[i].contains(specialOsSymbolUpperCase)) {
                                            foundSpecialSymbol = true;
                                        } else if (page[i].charAt(0) == '$') {
                                            foundSpecialSymbol = false;
                                        }
                                    }
                                    if (foundSpecialSymbol) {
                                        returnTask.FREER(ResourceId.CommandLineTask, "READTASK", ProcessId.CommandLine);
                                        GOTO(1);
                                        break; 
                                    }
                                } else {
                                    throw new MOSException("Interrupt: unknown IOI input device value: "+resource.resourceElement+" from process: "+resource.creatorId); 
                                }
                                cpu.IOI.setByte(InputDeviceChannel, "0");
                                GOTO(1);
                                break; 
                            }
                        } else if (interruptRegisterIOI.getByte(OutputDeviceChannel).equals("0") == false) {
                            cpu.IOI.setByte(OutputDeviceChannel, "0");
                            returnTask.FREER(ResourceId.InterruptEvent, interruptName+listSeparator+interruptRegisterIOI.getByte(OutputDeviceChannel), ProcessId.OutputDevice);
                            GOTO(1);
                            break; 
                        } else if (interruptRegisterIOI.getByte(HddDeviceChannel).equals("0") == false) {
                            cpu.IOI.setByte(HddDeviceChannel, "0");
                            returnTask.FREER(ResourceId.InterruptEvent, interruptName+listSeparator+interruptRegisterIOI.getByte(HddDeviceChannel), ProcessId.HddDevice);
                            GOTO(1);
                            break; 
                        } else {
                            throw new MOSException("Interrupt: unknown IOI value: "+resource.resourceElement+" from process: "+resource.creatorId); 
                        }
                    } else {
                        throw new MOSException("Interrupt: unknown interrupt: "+resource.resourceElement+" from process: "+resource.creatorId); 
                    }
                }
                default:
                    throw new MOSException("ProcessInterrupt: illeagal position :"+position);
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
}