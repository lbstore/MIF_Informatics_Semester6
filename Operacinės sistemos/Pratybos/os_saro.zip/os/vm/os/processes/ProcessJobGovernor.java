package vu.os.vm.os.processes;

import vu.os.vm.os.Constant;
import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.ui.GUI;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

import vu.os.vm.os.descriptors.subtypes.CPUState;
import vu.os.vm.os.descriptors.ProcessDescriptor;

import vu.os.vm.exceptions.EmptyMemoryException;
import vu.os.vm.exceptions.IlleagalNumberException;
import vu.os.vm.exceptions.IlleagalAddressException;

public class ProcessJobGovernor extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessJobGovernor( VirtualCPUCore cpu ) {
        super(cpu);
    }

    private static final int SYMBOLS_IN_PAGE = 40;
    private static final int WORD_LENGTH = 4;
    private static final int WORDS_IN_PAGE = 10;
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private String programName;
    private int priority;
    private int actualProgramSize;                                                                  //Kraunamas programos dydis (faile CS+esamas DS)
    private int realProgramSize;                                                                    //Realus programos dydis
    private int [] pageTableAddress;
    private int ssSize;
    private int dsSize;
    private int interruptNumber;
    private Integer aa;
    private int dsLocalAddress;
    private int ssLocalAddress;
    private String interruptInfo;
    private int vmId;
    private ProcessDescriptor processDescriptor;
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    {   
                        //--- Waiting for ProgramTask message ---//
                        returnTask.REQUESTR( ResourceId.ProgramTask, ProcessId.CurrentProcess );
                        //System.out.println("JobGovernor CASE1: RequestR ProgramTask");
                        break;
                    }
                case 2:
                    {
                        //--- Creating FileSystemTask message ---//
                        // resource ProgramTask, gaunamas resourceElement = vykdomojo failo vardas |prioritetas
                        // resource FileSystemTask, paduodamas resourceElement = "READFILEPAGE|vykdomojoFailoVardas|0" 0 - antrastes psl numeris
                        // (resurso FileSystemTask sukurimas)                        
                        String result = resource.resourceElement;
                        //System.out.println("JB CASE2: "+result);
                        String [] temp;
                        if (result != null) {
                            temp = result.split("\\|");
                            if (temp.length == 2) {
                                programName = temp[0];
                                priority = Convert.toSInt(temp[1]);
                                result = "READFILEPAGE|"+programName+"|0";
                                //System.out.println("AR MES CIA PATENKAM?");
                                returnTask.FREER( ResourceId.FileSystemTask, result, ProcessId.FileSystemManager );                                
                            } else {
                                throw new MOSException("JobGovernor: ProgramTask program name or priority isn't given! resourceElement: "+result);
                            }
                        } else {
                            throw new MOSException("JobGovernor: ProgramTask is null!");
                        }
                        
                        break;
                    }
                case 3:
                    {   
                        //--- Waiting for FileSystemTaskFinished message ---//
                        // (blokavimasis laukiant FileSystemManager darbo pabaigos pranesimo)
                        //System.out.println("JB CASE3: Requesting FileSystemTaskFinished");
                        returnTask.REQUESTR( ResourceId.FileSystemTaskFinished, ProcessId.CurrentProcess );
                        break;
                    }
                case 4:
                    {   
                        //--- Analyzing FileSystemTaskFinished resourceElement ---//
                        // gaunamas nuskaitytas psl "aaaabbbbcccc..." is viso 40 ilgio
                        // (Programos antrastes analizavimas)
                        
                        String result = resource.resourceElement;
                        
                        //System.out.println("JB CASE4: "+result);
                        
                       if (result != null) {
                            if (result.length() == SYMBOLS_IN_PAGE) {
                                int i, n;
                                for(i = 0, n = 0; i < SYMBOLS_IN_PAGE; i += WORD_LENGTH, n++) {
                                    if (n == 2) {
                                        actualProgramSize = Convert.toSInt(result.substring(i,i + WORD_LENGTH));
                                        //System.out.println("CS+DS actual size: "+result.substring(i,i + WORD_LENGTH));
                                    }
                                    if (n == 3) {
                                        realProgramSize = Convert.toSInt(result.substring(i,i+4));
                                        //System.out.println("Full program Size: "+result.substring(i,i + WORD_LENGTH));
                                    }    
                                    
                                    if (n == 4) {
                                        ssLocalAddress = Convert.toSInt(result.substring(i,i+4).substring(0,2));
                                        dsLocalAddress = Convert.toSInt(result.substring(i,i+4).substring(2,4));
                                        //System.out.println("ssLocalAddress: "+ssLocalAddress + " dsLocalAddress: "+dsLocalAddress);
                                    }  

                                    if (n == 7) {
                                        dsSize = Convert.toSInt(result.substring(i,i+4));
                                        //System.out.println("dsSize: "+dsSize );
                                    }
                                    
                                    if (n == 8) {
                                        ssSize = Convert.toSInt(result.substring(i,i + WORD_LENGTH));
                                        //System.out.println("SS Size: "+result.substring(i,i + WORD_LENGTH));
                                    }
                                }
                            } else {
                                throw new MOSException("JobGovernor: FileSystemTaskFinished resourceElement is" +result.length()+ " length should be" + SYMBOLS_IN_PAGE);
                            }
                        } else {
                            throw new MOSException("JobGovernor: FileSystemTaskFinished is null!");
                        }                        
                        //System.out.println("Visas programos dydis: "+realProgramSize+" CS + DS aktualus :"+actualProgramSize+" SS dydis: "+ssSize);
                        break;
                    }
                case 5:
                    {
                        //System.out.println("---------JB CASE5: requesting UserMemory---------");
                        int pageTableSize = (realProgramSize - 1)/10 + 1;
                        returnTask.REQUESTR( ResourceId.UserMemory, Convert.toSInt("10"+pageTableSize) );
                        break;
                    }
                case 6:
                    {   
                        //--- Requesting UserMemory resource ---//
                        // gautas resourceElement �n1|n2|n3|..|ni� n -�xyzw� : i-tojo puslapio adresas operatyviojoje atmintyje.
                        
                        String result = resource.resourceElement;
                        //System.out.println("---------JB CASE6: requesting UserMemory for page table :"+result+"---------");
                        if (result != null) {
                            String [] tempPageTableAddress = result.split("\\|");
                            int i;
                            pageTableAddress = new int[tempPageTableAddress.length];
                            for ( i = 0; i < tempPageTableAddress.length; i++ ) {
                                pageTableAddress[i] = Convert.toSInt(tempPageTableAddress[i]);
                            }
                            
                        } else {
                            throw new MOSException("JobGovernor: UserMemory is null! While loading VM");
                        }     
                        
                        String element;
                        
                        element = "2";
                        int programToLoadSize = actualProgramSize + ssSize;
                        if ( programToLoadSize < 10) {
                            element += "0" + programToLoadSize;
                        } else {
                            element += programToLoadSize;
                        }
                        
                        returnTask.REQUESTR( ResourceId.UserMemory, Convert.toSInt(element) );
                        break;                
                    }
                case 7:
                    {
                        //--- Creating LoadPackage resource ---//
                        
                        String result = resource.resourceElement;
                        //System.out.println("---------JB CASE7: requesting UserMemory for segments :"+result+"---------");
                        if (result != null) {
                            String [] tempProgramAddresses = result.split("\\|");
                            int i;
                            String element = programName+"|";
                            
                            for ( i = 0; i < pageTableAddress.length; i++ ) {
                                if (i == pageTableAddress.length-1) {
                                    element += Convert.toWord(pageTableAddress[i]);
                                } else {
                                    element += Convert.toWord(pageTableAddress[i]) + " ";
                                }
                            }
                            
                            element += "|";
                            
                            for ( i = 0; i < tempProgramAddresses.length; i++ ) {
                                if (i == tempProgramAddresses.length-1) {
                                    element += tempProgramAddresses[i];
                                } else {
                                    element += tempProgramAddresses[i] + " ";
                                }
                            }
                            
                            //System.out.println("---------JB CASE7: free resource LoadPacage :"+element+"---------");
                            returnTask.FREER( ResourceId.LoadPackage, element, ProcessId.Loader );
                            
                        } else {
                            throw new MOSException("JobGovernor: UserMemory is null. While asking for pages 100-9999!");
                        }
                        break;                    
                    }
                case 8:
                    {   //--- Waiting for LoadTaskFinished message ---//
                        //System.out.println("---------JB CASE8: waiting for LoadTaskFinished ---------");
                        returnTask.REQUESTR( ResourceId.LoadTaskFinished, ProcessId.CurrentProcess );

                        break;                    
                    }
                case 9:
                    {
                        //--- Creating VM process descriptor ---//
                        String result = resource.resourceElement;
                        //System.out.println("---------JB CASE9: LoadTaskFinished get result: "+result+" ---------");
                        if (result != null) {
                            if (Convert.toSInt(result) == 0) {
                            
                                CPUState cpuState = new CPUState(cpu); 
                                cpuState.R.set("0000");  cpuState.U.set("0000");
                                cpuState.IC.set("00");  cpuState.C.set("0");
                                cpuState.DS.set(Convert.toWord(dsLocalAddress)); 
                                cpuState.SS.set(Convert.toWord(ssLocalAddress));
                                cpuState.SP.set("00");
                                cpuState.TIMER.set(Constant.TimerResetValue);
                                cpuState.MODE.set("U");
                                String ptr = Convert.toWord(realProgramSize-1).substring(2,4);
                                ptr += Convert.toWord(pageTableAddress[0]).substring(2,4);
                                cpuState.PTR.set(ptr);
                                cpuState.PI.set("0");
                                cpuState.SI.set("00");
                                cpuState.TI.set("0");
                                
                                
                                returnTask.CREATEPD( programName, cpuState, null, null, priority, null );
                            } else {
                                throw new MOSException("JobGovernor: LoadTaskFinished error: "+result);
                            }
                               
                        } else {
                            throw new MOSException("JobGovernor: LoadTaskFinished is null!");
                        }
                        break;                    
                    }
                case 10:
                    {
                        //--- Waiting for interrupt task ---//
                        //System.out.println("---------JB CASE10: Activating Virtual Machine ---------");
                        
                        vmId = resource.createdProcessId;
                        returnTask.ACTIVATEP( vmId );
                        
                        
                        //System.out.println("jksdffffffffffffffffffffffffffffff");
                        GUI.userInterrupt = true;
                        break;                    
                    }                    
                case 11:
                    {
                        //--- Waiting for interrupt task ---//
                        //System.out.println("---------JB CASE11: requesting InterruptEvent ---------");
                        
                        interruptNumber = 0;
                        returnTask.REQUESTR( ResourceId.InterruptEvent, ProcessId.CurrentProcess );
                        break;                    
                    }
                case 12:
                    {
                        //--- Recognizing Interrupt ---//
                        //System.out.println("---------JB CASE12: Recognizing Interrupt STOPPING VM ---------");
                        String result = resource.resourceElement;
                        
                        String [] temp;
                        //System.out.println("GOT InterruptEvent resourceElement: "+result);
                        returnTask.STOPP( vmId );
                        
                        if (result != null) {
                            temp = result.split("\\|");
                            if (temp.length == 2) {
                                if (temp[0].equals("SI")) {
                                    interruptNumber = Convert.toSInt(temp[1]);
                                    switch (interruptNumber) {
                                        case 0:
                                            {       
                                                GOTO(18);
                                                break;
                                            }
                                        case 1:                                                                     //programos stabdymas
                                            {
                                                GOTO(25);
                                                //System.out.println("----------------------------------VM ID ="+vmId+"-----------------------------------------------------");
                                                break;
                                            }
                                        case 10:                                                                    //isvesti duomenis
                                            {                                                
                                                GOTO(13);
                                                break;
                                            }
                                        case 11:                                                                    //ivesti duomenis
                                            {                                                
                                                GOTO(13);
                                                break;
                                            }
                                        case 20:                                                                    //gauti psl
                                            {
                                                GOTO(19);
                                                break;
                                            }
                                        case 21:                                                                    //trinti psl
                                            {
                                                GOTO(19);
                                                break;
                                            }
                                        default:
                                            {
                                                interruptInfo = "1"+temp[1];
                                                GOTO(21);
                                            }
                                    }
                                } else if (temp[0].equals("PI")) {
                                    interruptInfo = "2"+temp[1];
                                    GOTO(21);
                                } else {
                                    throw new MOSException("JobGovernor: InterruptTask interupt which can't reach JobGovernor! text: "+result);
                                }
                            } else {
                                throw new MOSException("JobGovernor: InterruptTask interupt number isn't given! text: "+result);
                            }
                        } else {
                            throw new MOSException("JobGovernor: InterruptTask is null!");
                        }
                        break;                    
                    }
                case 13:
                    {   //--- REQUESTING InputOutputStream ---//
                        //System.out.println("---------JB CASE13: REQUESTING InputOutputStream ---------");
                        processDescriptor = resource.stoppedProcessDescriptor;
                        switch(interruptNumber) {
                            case 10:
                                {
                                    returnTask.REQUESTR( ResourceId.InputOutputStream, 1 );
                                    break;
                                } 
                            case 11:
                                {
                                    returnTask.REQUESTR( ResourceId.InputOutputStream, 2 );
                                    break;
                                }
                        }

                        break;                    
                    }                    
                case 14:
                    {
                        //--- Preparing elemnts for InputOutputTask ---//
                        //System.out.println("---------JB CASE14: Preparing elemnts for InputOutputTask ---------");
                        
                        String element = "";
                        int addressInSegment, ptr, maxAA;
                        String word;
                        
                        ptr = pageTableAddress[0]*10;
                        addressInSegment = Convert.toInt(processDescriptor.cpu.R.get());
                        aa = 0;                        
                        maxAA = ptr + dsLocalAddress + dsSize;
                        aa = ptr + dsLocalAddress + addressInSegment;
 //                       if (aa < maxAA) {                            
                            
                        
                            switch(interruptNumber) {
                                case 10:
                                    {
                                        element = "VM:"+ programName +" output: |WRITELINE|";
                                        int i;
                                        String [] page = cpu.ram.readPage(Convert.toInt(cpu.ram.readWord(aa)));
                                        for ( i=0; i < page.length; i++) {
                                            element += page[i];                        
                                        }
                                        break;
                                    } 
                                case 11:
                                    {
                                        element = "VM:"+ programName +" input: |READLINE";
                                    }
                            }
                            //System.out.println("---------JB CASE14: sending InputOutputTask ---------");
                            returnTask.FREER( ResourceId.InputOutputTask, element, ProcessId.InputOutputManager );
 //                       } else {
 //                           processDescriptor.cpu.U.set("0002");
//                            GOTO(18);
 //                       }
                        break;
                    }
                case 15:
                    {
                        //--- Waiting for InputOutputTaskFinished resource ---//   
                        //System.out.println("---------JB CASE15: Waiting for InputOutputTaskFinished resource ---------");
                        
                        returnTask.REQUESTR( ResourceId.InputOutputTaskFinished, ProcessId.CurrentProcess );
                        break;
                    }
                case 16:
                    {
                        //--- Analyzing information of InputOutputTaskFinished when was writing and reading opearions ---//
                        //System.out.println("---------JB CASE16: Analyzing information of InputOutputTaskFinished when was writing and reading opearions ---------");
                                                
                        String result = resource.resourceElement;                        
                        
                        if ( result != null ) {
                            switch(interruptNumber) {
                                case 10:
                                    {
                                        if ( Convert.toSInt(result) == 0 ) {
                                            processDescriptor.cpu.U.set("0000");
                                        } else {
                                            processDescriptor.cpu.U.set("0001");
                                        }
                                        break;
                                    }
                                case 11:
                                    {
                                        String [] temp, page;
                                        temp = result.split("\\|", 2);
                                        
                                        if ( Convert.toSInt(temp[0]) == 0 ) {
                                            page = new String[WORDS_IN_PAGE];
                                            int fullLines = temp[1].length()/WORD_LENGTH, n, i;
                                            
                                            for( i = 0, n = 0; i < fullLines*WORD_LENGTH; i += WORD_LENGTH, n++ ) {
                                                page[n] = temp[1].substring(i, i + WORD_LENGTH);
                                            }
                                            
                                            if ( (fullLines * WORD_LENGTH) < temp[1].length() ) {
                                                page[fullLines] = temp[1].substring(fullLines * WORD_LENGTH, temp[1].length());
                                                
                                                for ( i = 0; i < WORD_LENGTH - (temp[1].length() - (fullLines * WORD_LENGTH) ); i++) {
                                                    page[fullLines] += "&";
                                                }
                                                fullLines++;
                                            }
                                            
                                            for ( i = fullLines; i < WORDS_IN_PAGE; i++) {
                                                 page[i] = "&&&&";
                                            }
                                            //System.out.println("Puslapiu lenteles adresas: "+pageTableAddress[0]);
                                            cpu.ram.writePage( Convert.toInt(cpu.ram.readWord(aa)), page ); 
                                            processDescriptor.cpu.U.set("0000");                                    
                                        } else {
                                            processDescriptor.cpu.U.set("0001");                                                                          //klaida skaitant duomenis
                                        } 
                                        break;
                                    }
                            }
                        } else {
                            throw new MOSException("JobGovernor: InputOutputTaskFinished is null!");
                        }
                        
                        break;
                    }
                case 17:
                    {
                        //--- Making free InputOutputStream resourcePart  ---//
                        //--- Atlaisvinimas InputOutputStream resurso dalis ---//
                        //System.out.println("---------JB CASE17: Making free InputOutputStream resourcePart ---------");
                        

                        switch ( interruptNumber ) {
                            case 10:
                                {
                                    returnTask.FREER( ResourceId.InputOutputStream, "", 1 );
                                    break;
                                }
                            case 11:
                                {
                                    returnTask.FREER( ResourceId.InputOutputStream, "", 2 );
                                    break;
                                }                        
                        }
                        
                            
                        break;
                    }
                case 18:
                    {
                        //--- Activating VM Process ---//
                        //--- Aktyvuojamas VM procesas ---//
                        //System.out.println("---------JB CASE18: Activating VM Process ---------");
                        
                        returnTask.ACTIVATEP( vmId );
                        GOTO(11);
                        break;
                    }
                case 19:
                    {
                        //--- Geting AbsoluteAddress of word in pageTable, for new dinamic memory page adding or deleting ---//
                        //--- Gaunamas AbsoliutusAdresas zodzio puslapiu lenteje, i kuri irasomas arba is kurio istrinimas programos puslapis ---//
                        //System.out.println("---------JB CASE19: Geting AbsoluteAddress of word in pageTable, for new dinamic memory page adding or deleting ---------");
                        
                        processDescriptor = resource.stoppedProcessDescriptor;
                        
                        int addressInSegment, errorHandler = 0, ptr, maxAA;
                        String word;
                        
                        ptr = pageTableAddress[0]*10;
                        addressInSegment = Convert.toInt(processDescriptor.cpu.R.get());
                        aa = 0;                        
                        maxAA = ptr + dsLocalAddress + dsSize;
                        aa = ptr + dsLocalAddress + addressInSegment;
                        
                        if (aa >= maxAA) errorHandler = 2;
                        word = cpu.ram.readWord(aa);
                        //System.out.println("AbsoluteAddress: "+aa+" Max avalable AA:"+maxAA+" ptr"+ ptr);
                        if (errorHandler == 0) {
                            
                            switch ( interruptNumber ) {
                                case 20:
                                    {
                                        if (!word.equals("****")) errorHandler = 1;
                                        break;
                                    }
                                case 21:
                                    {
                                        if (word.equals("****")) errorHandler = 1; 
                                        break;
                                    }                        
                            }                            
                            
                        }
                        
                        if (errorHandler == 0) {
                            switch ( interruptNumber ) {
                                case 20:
                                    {
                                        returnTask.REQUESTR( ResourceId.UserMemory, 201 );
                                        break;
                                    }
                                case 21:
                                    {
                                        returnTask.FREER( ResourceId.UserMemory, "", Convert.toInt(word)); 
                                        cpu.ram.writeWord(aa, "****");
                                        processDescriptor.cpu.U.set("0000");
                                        GOTO(18);
                                        break;                                        
                                    }                        
                            }
                            
                        } else if (errorHandler == 1){
                            processDescriptor.cpu.U.set("0001");
                            GOTO(18);
                        } else {
                            processDescriptor.cpu.U.set("0002");
                            GOTO(18);
                        }
                        break;                    
                    }   
                case 20:
                    {
                        //--- Adding or deleating word from page table ---//
                        //--- Nustatomas arba isvalomas zodis is puslapiu lenteles ---//
                        //System.out.println("---------JB CASE20: Adding or deleating word from page table ---------");

                        String result = resource.resourceElement;
                        
                        if (result != null) {  
                            cpu.ram.writeWord(aa, result);
                            processDescriptor.cpu.U.set("0000");
                        } else {
                            throw new MOSException("JobGovernor: UserMemory is null! While allocating page for VM");
                        } 
                        
                        GOTO(18);
                        break;
                    }
                case 21:
                    {
                        //--- Requesting InputOutputStream for writing operation ---//
                        //--- Prasoma InputOutputStream rasymo operacijai ---//
                        //System.out.println("---------JB CASE21: Requesting InputOutputStream for writing operation ---------");
                        
                        returnTask.REQUESTR( ResourceId.InputOutputStream, 1 );
                        break;
                    }
                case 22:
                    {
                        //--- Free InputOutputTask, for writing operation with error interupt value ---//
                        //--- Siunciamas pranesimas InputOutputmanager, rasymo operacijai nusakanciai kodel killinama VM ---//
                        //System.out.println("---------JB CASE22: Free InputOutputTask, for writing operation with error interupt value ---------");
                        
                        String element = "VM:"+ programName +" output: |WRITELINE|"; 
                        
                        if (Convert.toSInt(interruptInfo.substring(0, 1)) == 1) {
                            element += "VM killed due bad SI interrupt value: "+interruptInfo.substring(1,interruptInfo.length());
                        
                        } else {
                            element += "VM killed due PI interrupt: "+interruptInfo.substring(1,interruptInfo.length());
                        }
                        returnTask.FREER( ResourceId.InputOutputTask, element, ProcessId.InputOutputManager );
                        break;
                    }
                case 23:
                    {
                        //--- Waiting for InputOutputTaskFinished finished ---//
                        //--- Laukiama InputOutputTaskFinished resurso ---//
                        //System.out.println("---------JB CASE23: Waiting for InputOutputTaskFinished finished ---------");
                        
                        returnTask.REQUESTR( ResourceId.InputOutputTaskFinished, ProcessId.CurrentProcess );
                        break;
                    }
                case 24:
                    {
                        //--- Free InputOutputStream resource ---//
                        //--- Atlaisvinamas InputOutputStream resursas ---//
                        //System.out.println("---------JB CASE24: Free InputOutputStream resource ---------");
                        String result = resource.resourceElement;                                                
                        
                        
                        if ( result != null ) {
                            returnTask.FREER( ResourceId.InputOutputStream, "", 1 );
                        } else {
                            throw new MOSException("JobGovernor: InputOutputTask is null!");
                        }
                        break;
                    }                    
                case 25:
                    {
                        //System.out.println("---------JB CASE25: Destroying VM ---------");
                        //--- Destroying Process descriptor ---//
                        //--- Nakinama virtuali masina ---//
                        
                        returnTask.DESTROYPD(vmId);
                        break;
                    }
                case 26:
                    {
                        //System.out.println("---------JB CASE26: message to ExternalTask ---------");
                        //--- Creating ExternalTask resource ---//
                        //--- Sukuriamas ExternalTask resursas ---//
                        
                        returnTask.FREER( ResourceId.ExternalTask, "DESTROYJB|"+programName+"|"+ProcessId.CurrentProcess, ProcessId.MainProcess );
                        break;
                    }
                case 27:
                    {
                        //System.out.println("---------JB CASE27: Waiting WorkFinished resource ---------");
                        //--- Waiting for WorkFinished resource ---//
                        //--- Blokavimasis laukiant WorkFinished resurso ---//
                        
                        returnTask.REQUESTR( ResourceId.WorkFinished, ProcessId.CurrentProcess );
                        break;
                    }                             
                default:
                    throw new MOSException("ProcessJobGovernor: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
}