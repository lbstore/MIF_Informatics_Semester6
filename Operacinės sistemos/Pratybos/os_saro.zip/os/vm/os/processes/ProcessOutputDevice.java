//----------------------------------------------------------------------------//
//--------------------------- !! NOT FINISHED !! -----------------------------//
//----------------------------------------------------------------------------//

package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

public class ProcessOutputDevice extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessOutputDevice( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private static final String WRITE_TASK = "WRITE";
    private static final String DEFAULT_TARGET_ADDRESS = "0001";
    private static final int OUTPUT_CHANNEL = 1;
    private static final String OPERATION_COMPLETED = "1";
    private static final String ERROR_CODE = "-1";
    private static final String IO_INTERRUPT = "IOI";
    private static final String SPLIT_REGEX = "\\|";
    private static final String FINISHED_SUCCESSFULLY = "0";
    private static final int PAGE_SIZE = 10;
    private static final int MAX_BUFFER_SIZE = 40;
    private static final int WORD_LENGTH = 4;
    
    private int userMemoryAddress = 0;
    private int askingProcess = 0;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                {
                    returnTask.REQUESTR(ResourceId.UserMemory, 201 );
                    break;
                }
                case 2:
                    {
                        String result = resource.resourceElement;
                        
                        if( result != null )
                        {
                            userMemoryAddress = Convert.toInt(result);
                        }
                        else
                        {
                            throw new MOSException("OutputDevice: UserMemory is null");
                        }
                        
                        break;
                    }
                case 3:
                    {
                        returnTask.REQUESTR( ResourceId.OutputDeviceTask , ProcessId.CurrentProcess );
                        break;
                    }
                case 4:
                    {
                        //System.out.print("\nOUTPUT DEVICE: "+resource.resourceElement+"\n");
                        String result = resource.resourceElement;
                        
                        if( result != null )
                        {
                            String[] outputParameters = result.split(SPLIT_REGEX);
                            
                            if( outputParameters[0].equals(WRITE_TASK) )
                            {
                                askingProcess = resource.creatorId;
                                
                                // =============== CLEAR CURRENT BUFFER =============== //
                                String[] tempBuffer = cpu.ram.readPage( userMemoryAddress );
                                tempBuffer = clearBuffer( tempBuffer );
                                tempBuffer = textToBuffer( outputParameters[1] , tempBuffer );
                                cpu.ram.writePage( userMemoryAddress , tempBuffer );
                                tempBuffer = null;
                                // ==================================================== //
                                
                                
                                //System.out.print("\n------OUTPUT DEVICE: R:"+cpu.R+"\" U:"+cpu.U+"\n");
                                cpu.R.set("0000");
                                cpu.R.set( Integer.toString(userMemoryAddress) );
                                cpu.U.set("0000");
                                cpu.U.set( DEFAULT_TARGET_ADDRESS );
                                
                                cpu.OUT( Integer.toString(OUTPUT_CHANNEL) );
                                
                                
                            }
                            else
                            {
                                throw new MOSException("OutputDevice: illegal task: "+result);
                            }
                        }
                        else
                        {
                            throw new MOSException("OutputDevice: OutputDeviceTask is null");
                        }
                        
                        break;
                    }
                case 5:
                    {
                        returnTask.REQUESTR( ResourceId.InterruptEvent , ProcessId.CurrentProcess );
                        break;                    
                    }
                case 6:
                    {
                        String result = resource.resourceElement;
                        
                        if( result != null )
                        {
                            String[] interruptParameters = result.split(SPLIT_REGEX);
                            
                            if( interruptParameters[0].equals(IO_INTERRUPT) &&
                                interruptParameters[1].equals(OPERATION_COMPLETED) )
                            {
                                //System.out.print("\nOUTPUTDEVICE: result"+resource.resourceElement+"\n");
                                returnTask.FREER( ResourceId.OutputDeviceTaskFinished , FINISHED_SUCCESSFULLY , askingProcess );
                            }
                            else
                            {
                                // CIA GRAZINA -1 JEI NEPAVYKO ISVEST !!!
                                returnTask.FREER( ResourceId.OutputDeviceTaskFinished , ERROR_CODE , askingProcess );
                            }
                        }
                        else
                        {
                            throw new MOSException("OutputDevice: InterruptEvent is null");
                        }
                        GOTO(3);
                        break;
                    }
                default:
                    throw new MOSException("OutputDevice: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    // ========== CLEAR BUFFER ========== //
    private String[] clearBuffer( String[] buffer )
    {
        String[] clearedBuffer = new String[PAGE_SIZE];
        
        for( int i = 0 ; i<clearedBuffer.length ; i++ )
        {
            clearedBuffer[i] = "$$$$";
        }
        
        return clearedBuffer;
    }
    // ================================== //
    
    // ===== WRITE TEXT TO BUFFER ======= //
    private String[] textToBuffer( String text , String[] buffer )
    {
        String[] targetBuffer = buffer;
        String textToWrite = text;
        
        if( textToWrite.length() > MAX_BUFFER_SIZE )
        {
            textToWrite = textToWrite.substring(0 , MAX_BUFFER_SIZE);
        }
        
        int charsCount = 0;
        for( int i = 0 ; i < textToWrite.length() ; i++ )
        {
            char[] currentLine = targetBuffer[(int)Math.floor((double)i/(double)WORD_LENGTH) ].toCharArray();
            int currentChar = i%WORD_LENGTH;

            currentLine[currentChar] = textToWrite.substring(i,i+1).charAt(0);
            targetBuffer[ (int)Math.floor((double)i/(double)WORD_LENGTH) ] = new String( currentLine );
        }
        
        return targetBuffer;
    }
    // ================================== //
}