package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

public class ProcessInputDevice extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessInputDevice( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private static final String SPLIT_REGEX = "\\|";
    private static final String READ_TASK = "READ";
    private static final String DEFAULT_TARGET_ADDRESS = "0001";
    private static final String IO_INTERRUPT = "IOI";
    private static final String OPERATION_COMPLETED = "1";
    private static final String ERROR_CODE = "-1";
    private static final int INPUT_CHANNEL = 0;
    
    private int userMemoryAddress = 0;
    private int askingProcess = 0;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    {
                        returnTask.REQUESTR(ResourceId.UserMemory, 201 );
                        break;
                    }
                case 2:
                    {
                        String result = resource.resourceElement;
                        
                        if( result != null )
                        {
                            userMemoryAddress = Convert.toInt(result);
                        }
                        else
                        {
                            throw new MOSException("InputDevice: UserMemory is null!");
                        }
                        break;
                    }
                case 3:
                    {
                        returnTask.REQUESTR( ResourceId.InputDeviceTask , ProcessId.CurrentProcess );
                        break;
                    }
                case 4:
                    {
                        //System.out.println("@ INPUT DEVICE: task got: "+resource.resourceElement);
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            if( result.equals(READ_TASK) )
                            {
                                askingProcess = resource.creatorId;

                                cpu.R.set("0000");
                                cpu.R.set( Integer.toString(userMemoryAddress) );
                                cpu.U.set("0000");
                                cpu.U.set( DEFAULT_TARGET_ADDRESS );
                                
                                cpu.INP( Integer.toString(INPUT_CHANNEL) );
                            }
                            else
                            {
                                throw new MOSException("InputDevice: illegal task: "+result);
                            }
                        }
                        else
                        {
                            throw new MOSException("InputDevice: InputDeviceTask is null!");
                        }
                        break;
                    }
                case 5:
                    {
                        returnTask.REQUESTR( ResourceId.InterruptEvent , ProcessId.CurrentProcess );
                        break;
                    }
                case 6:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            String[] interruptParameters = result.split(SPLIT_REGEX);
                            
                            if( interruptParameters[0].equals(IO_INTERRUPT) &&
                                interruptParameters[1].equals(OPERATION_COMPLETED) )
                            {
                                returnTask.FREER( ResourceId.InputDeviceTaskFinished , Convert.toWord(userMemoryAddress) , askingProcess );
                            }
                            else
                            {
                                returnTask.FREER( ResourceId.InputDeviceTaskFinished , ERROR_CODE , askingProcess );
                            }
                        }
                        else
                        {
                            throw new MOSException("InputDevice: InterruptEvent is null!");
                        }
                        GOTO(3);
                        break;
                    }
                default:
                    throw new MOSException("InputDevice: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
}