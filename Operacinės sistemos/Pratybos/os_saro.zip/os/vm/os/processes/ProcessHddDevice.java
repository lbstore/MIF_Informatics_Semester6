package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

public class ProcessHddDevice extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessHddDevice( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private static final String SPLIT_REGEX = "\\|";
    private static final int HDD_CHANNEL = 2;
    private static final String HDD_READ_TASK = "READ";
    private static final int OPERATION_COMPLETED = 1;
    private static final String IO_INTERRUPT = "IOI";
    private static final int ERROR_CODE = -1;
    private static final int MAX_HDD_ADDRESS = 9999;
    
    private int userMemoryAddress;
    private String[] parameters = null;
    private int askingProcess;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    {
                        returnTask.REQUESTR(ResourceId.UserMemory, 201 );
                        break;
                    }
                case 2:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            userMemoryAddress = Convert.toInt( result );
                        }
                        else
                        {
                            throw new MOSException("ProcessHddDevice: UserMemory resource is null!");
                        }

                        break;  
                    }
                case 3:
                    {
                        returnTask.REQUESTR( ResourceId.HddDeviceTask , ProcessId.CurrentProcess );
                        break;
                    }
                case 4:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            parameters = result.split(SPLIT_REGEX);
                            askingProcess = resource.creatorId;
                            if( parameters[0].equals(HDD_READ_TASK) )
                            {
                                int targetAddress = Convert.toInt( parameters[1] );
                                cpu.R.set("0000");
                                //System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~BEFORE:"+userMemoryAddress);
                                cpu.R.set( Integer.toString(userMemoryAddress) );
                                //System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~AFTER:"+cpu.R);
                                cpu.U.set("0000");
                                cpu.U.set( Convert.toWord(targetAddress) );
                                
                                cpu.INP( Integer.toString(HDD_CHANNEL) );
                            }
                            else
                            {
                                throw new MOSException("ProcessHddDevice: HddDeviceTask resource is null!");
                            }
                        }
                        else
                        {
                            throw new MOSException("ProcessHddDevice: HddDeviceTask resource is null!");
                        }
                        
                        break;
                    }
                case 5:
                    {
                        returnTask.REQUESTR( ResourceId.InterruptEvent , ProcessId.CurrentProcess );
                        break;
                    }
                case 6:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            String[] interruptParrameters = result.split(SPLIT_REGEX);
                            if( interruptParrameters[0].equals( IO_INTERRUPT ) &&
                                Convert.toInt(interruptParrameters[1]) == OPERATION_COMPLETED)
                            {
                                returnTask.FREER( ResourceId.HddDeviceTaskFinished , notNegativeIntToWord(userMemoryAddress)  , askingProcess );
                            }
                            else
                            {
                                returnTask.FREER( ResourceId.HddDeviceTaskFinished , Integer.toString(ERROR_CODE) , askingProcess );
                                throw new MOSException("HDDDEVICE: interrupt value: "+interruptParrameters[0]+" "+interruptParrameters[1]);
                            }
                        }
                        else
                        {
                            throw new MOSException("ProcessHddDevice: InterruptEvent resource is null!");
                        }
                        GOTO(3);
                        break;
                    }
                default:
                    throw new MOSException("ProcessHddDevice: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    // ====== CONVERT NON NEGATIVE INT TO WORD ===== //
    private String notNegativeIntToWord( int nonNegativeInteger )
    {
    /*
        String tempString = null;
        
        if( nonNegativeInteger >= 0 && nonNegativeInteger <= MAX_HDD_ADDRESS)
        {
            if( nonNegativeInteger < 10 )
            {
                tempString = "000"+Integer.toString(nonNegativeInteger);
            }
            else if( nonNegativeInteger >= 10 && nonNegativeInteger < 100 )
            {
                tempString = "00"+Integer.toString(nonNegativeInteger);
            }
            else if( nonNegativeInteger >= 100 && nonNegativeInteger < 1000 )
            {
                tempString = "0"+Integer.toString(nonNegativeInteger);
            }
            else
            {
                tempString = Integer.toString(nonNegativeInteger);
            }
        }
        
        return tempString;
        */
        return Convert.toWord(nonNegativeInteger);
    }
    // ============================================= //
}
