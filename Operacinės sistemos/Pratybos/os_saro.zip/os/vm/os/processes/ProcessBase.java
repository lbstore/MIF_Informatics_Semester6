package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

public class ProcessBase {
    
    protected VirtualCPUCore cpu = null;

    public ProcessBase( VirtualCPUCore cpu ) {
        this.cpu = cpu;
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    
    
    
    
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    // ... kodas ...
                    break;
                case 2:
                    // ... kodas ...
                    // uzpildom ko prasom

                    
                    //returnTask.FREER(ResourceId.FileSystemTask, ResourceId.CurrentProcess + "|LIST", 0);
                   
                    // baigiam uzpildima, darba procesas baigia
                    break;    
                case 3:
                    // procesas gauna atsakyma is planuotojo
                    String  e = resource.resourceElement;
                    if (e != null) {

                    }
                    // ... kodas ...
                    break;
                case 4:
                    // ... kodas ...
                    break;
                case 5:
                    // ... kodas ...
                    break;
                case 6:
                    // ... kodas ...
                    GOTO(1);
                    break;
                default:
                    throw new MOSException("SystemProcess: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    //--------------------------------------------------------------------------
    protected boolean gotoInitiated = false;
    protected int position = 0;
    
    protected final int GetNextPosition() {
        if (!gotoInitiated) {
            position ++;
        } else {
            gotoInitiated = false;
        }
        return position;
    }
    
    protected final void GOTO( int to ) {
        position = to;
        gotoInitiated = true;
    }
    //--------------------------------------------------------------------------
}