//----------------------------------------------------------------------------//
//--------------------------- !! NOT FINISHED !! -----------------------------//
//----------------------------------------------------------------------------//

package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

import vu.os.vm.os.descriptors.subtypes.CPUState;

import java.util.LinkedList;

public class ProcessMainProcess extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessMainProcess( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private LinkedList<Integer> createdJB = new LinkedList<Integer>();
    
    
    private String jobGovernorName;
    private int jobGovernorPriority;
    private int numberOfJobGovernors = 0;
    private int currentJB = 0;
    private int idOfJB;
    
    private int readJobGovernorPriority = 6;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                {
                    returnTask.REQUESTR( ResourceId.ExternalTask, ProcessId.CurrentProcess );
                    //System.out.println("MainProcess CASE1: REQUESTR ExternalTask");
                    break;
                }
                case 2:
                    {
                    //System.out.println("ProcessMainProcess: got ExternalTask");
                    
                        String result = resource.resourceElement;
                        //System.out.println("MainProcess CASE2: "+result);
                        String [] temp;
                        idOfJB = 0;
                        jobGovernorName = "";
                        jobGovernorPriority = -1;
                        
                        if (result != null) {
                            temp = result.split("\\|");
                            jobGovernorName = temp[1];
                            jobGovernorPriority = Convert.toSInt(temp[2]);  
                            if (temp.length == 3) {
                                if (temp[0].equals("CREATEJB")) {
                                    numberOfJobGovernors++;
                                    currentJB++;
                                } else {
                                   numberOfJobGovernors--; 
                                   idOfJB = resource.creatorId;
                                   GOTO(6);
                                }
                            } else {
                                throw new MOSException("MainProcess: ExternalTask wrong parameters number in element!");
                            }
                            
                        } else {
                            throw new MOSException("MainProcess: ExternalTask is null!");
                        }
                        
                        break;    
                    }
                case 3:
                    {
                        ProcessBase systemProcess = null;
                        //System.out.println("MainProcess CASE3: creating JB");
                        
                        systemProcess = new ProcessJobGovernor(cpu);
                        
                        returnTask.CREATEPD( "JobGovernor"+currentJB, new CPUState(cpu), null, null, readJobGovernorPriority, systemProcess );
                        break;
                    }
                case 4:
                    {
                        //System.out.println("MainProcess CASE4: activating JB");
                        idOfJB = resource.createdProcessId;
                        createdJB.add(idOfJB);
                        
                        returnTask.ACTIVATEP(idOfJB);
                        break;
                    }                    
                case 5:
                    {
                        // ... kodas ...
                        
                        //System.out.println("MainProcess CASE5: FREER to process id:"+idOfJB);
                        String element = jobGovernorName+"|"+jobGovernorPriority;
                        returnTask.FREER( ResourceId.ProgramTask, element, idOfJB );
                        GOTO(7);
                        break;
                    }                    
                case 6:
                    {
                        // ... kodas ...
                        //System.out.println("MainProcess CASE6: Destroying JB nr: "+jobGovernorPriority+ " ---------");
                        if (createdJB.contains(jobGovernorPriority)) {
                            createdJB.removeFirstOccurrence(jobGovernorPriority);
                            returnTask.DESTROYPD(jobGovernorPriority);
                            GOTO(9);
                        } else {
                            GOTO(8);
                            //throw new MOSException("MainProcess: ProcessId to kill not found");
                        }
                        break;
                    }
                case 7:
                    {
                        // ... kodas ...
                        if (numberOfJobGovernors <= 0) {
                            returnTask.FREER( ResourceId.CommandLineTask, "READTASK", ProcessId.CommandLine );
                        } 
                        GOTO(1);                        
                        break;
                    }   
                case 8:
                    {   
                        returnTask.FREER(ResourceId.InputOutputTask,"MainProcess |WRITELINE|ProcessId "+jobGovernorPriority+" to kill not found!",ProcessId.InputOutputManager);
                        GOTO(10);
                        break;
                    }
                case 9:
                    {   
                        returnTask.FREER(ResourceId.InputOutputTask,"MainProcess |WRITELINE|Process "+jobGovernorPriority+" killed.",ProcessId.InputOutputManager);
                        GOTO(10);
                        break;
                    }
                case 10:
                    {   
                        returnTask.REQUESTR(ResourceId.InputOutputTaskFinished,ProcessId.CurrentProcess);
                        GOTO(1);
                        break;
                    }
                default:
                    throw new MOSException("SystemProcess: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
}