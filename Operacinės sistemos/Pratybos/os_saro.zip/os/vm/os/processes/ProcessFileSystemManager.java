package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

import java.util.ArrayList;

public class ProcessFileSystemManager extends ProcessBase {

    private static final String SPLIT_REGEX = "\\|";
    
    private static final String LIST_TASK = "LIST";
    private static final String READFILEPAGE_TASK = "READFILEPAGE";
    
    private static final int FS_DESCRIPTION_ADDRESS = 1; 
    
    public ProcessFileSystemManager( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private String[] parameters = null;
    private int pageToRead = 0;
    private int pagesToRead = 0;
    private int totalFiles = 0;
    
    private String[] fileSystemDescriptionPage = null;
    private ArrayList<String[]> fileDescriptions = null;
    private String[] exactPage = null;
    
    private int askingProcess = 0;
    
    private int pageReadingState = 0; // 0 - file system description , 1 - files description , 2 - exact page
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    // --- WAITING FOR FileSystemTask RESOURCE --- //
                    {
                        returnTask.REQUESTR( ResourceId.FileSystemTask , ProcessId.CurrentProcess );
                        break;
                    }
                    // ------------------------------------------- //
                case 2:
                    // ---- ANALIZING FileSystemTask RESOURCE ---- //
                    {
                        //System.out.println("\n @ FILESYSTEMMANAGER: gottask: "+resource.resourceElement+" sender: "+resource.creatorId);
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            askingProcess =  resource.creatorId;
                            
                            parameters = result.split(SPLIT_REGEX);
                            
                            if( parameters[0].equals(LIST_TASK) || parameters[0].equals(READFILEPAGE_TASK))
                            {
                                pageReadingState = 0;
                                pageToRead = FS_DESCRIPTION_ADDRESS;
                                returnTask.FREER( ResourceId.HddDeviceTask, "READ|"+pageToRead , 0 );
                            }
                            else
                            {
                                throw new MOSException("FileSystemManager: illegal FileSystemTask!");
                            }
                        }
                        else
                        {
                            throw new MOSException("FileSystemManager: FileSystemTask is null!");
                        }
                        break;
                    }
                    // ------------------------------------------- //
                case 3:
                    // --- WAITING FOR HddDeviceTaskFinished RESOURCE --- //
                    {
                        returnTask.REQUESTR( ResourceId.HddDeviceTaskFinished , ProcessId.CurrentProcess );
                        break;
                    }
                    // -------------------------------------------------- //
                case 4:
                    // ---- ANALIZING HddDeviceTaskFinished RESOURCE ---- //
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            int resultInt = Convert.toSInt(result);
                            if( resultInt == -1 )
                            {
                                throw new MOSException("FileSystemManager: HddDeviceTaskFinished result is -1!");
                            }
                            else
                            {
                                // - CHECK WHICH STATE OF READING IS REACHED - //
                                if( pageReadingState == 0 )
                                {
                                    fileSystemDescriptionPage = cpu.ram.readPage( resultInt );
                                    // ---- ANALIZING FILE SYSTEM DESCRIPTION ---- //
                                    pageToRead = Convert.toInt(fileSystemDescriptionPage[3]);
                                    pagesToRead = Convert.toInt(fileSystemDescriptionPage[4])-pageToRead;
                                    totalFiles  = Convert.toInt(fileSystemDescriptionPage[5]);
                                    
                                    // ------------------------------------------- //
                                    
                                    pageReadingState = 1;
                                    fileDescriptions = new ArrayList<String[]>();
                                    
                                    returnTask.FREER( ResourceId.HddDeviceTask, "READ|"+pageToRead , 0 );
                                    GOTO(3);
                                }
                                else if( pageReadingState == 1 )
                                {
                                    pagesToRead--;
                                    fileDescriptions.add( cpu.ram.readPage( resultInt ) );
                                    // ---- CHECK IF LAST PAGE ---- //
                                    if( pagesToRead == 0 )
                                    {
                                        if( parameters[0].equals(LIST_TASK) )
                                        {
                                            String listOfFiles = null;
                                            listOfFiles = getFilesList( totalFiles , fileDescriptions);
                                            
                                            //System.out.println("FSMANAGER: list:"+listOfFiles);
                                            
                                            returnTask.FREER(ResourceId.FileSystemTaskFinished, listOfFiles , askingProcess );
                                            GOTO(1);
                                            // --------------------------------- //
                                        }
                                        else if( parameters[0].equals(READFILEPAGE_TASK) )
                                        {
                                            int requestedPage = Convert.toInt(parameters[2]);
                                            
                                            int[] fileInformation = getFileInformation(parameters[1],fileDescriptions );
                                            
                                            if( requestedPage < fileInformation[1] )
                                            {
                                                pageReadingState = 2;
                                                pageToRead = fileInformation[0]+requestedPage;
                                                returnTask.FREER(ResourceId.HddDeviceTask, "READ|"+pageToRead , 0 );
                                                GOTO(3);
                                            }
                                            else
                                            {
                                                throw new MOSException("FileSystemManager: requested file page does not exist of file does not exist!:"+requestedPage+"file"+parameters[1]);
                                            }    
                                        }
                                    }
                                    else if( pagesToRead > 0 )
                                    {
                                        pageToRead++;
                                        returnTask.FREER(ResourceId.HddDeviceTask, "READ|"+pageToRead , 0 );    
                                        GOTO(3);
                                    }
                                    // ---------------------------- //
                                }
                                else if( pageReadingState == 2 )
                                {
                                    exactPage = cpu.ram.readPage( resultInt );
                                    returnTask.FREER(ResourceId.FileSystemTaskFinished, getPageAsString( exactPage ) , askingProcess );
                                    GOTO(1);
                                }
                                // ------------------------------------------- //
                            }
                        }
                        else
                        {
                            throw new MOSException("FileSystemManager: HddDeviceTaskFinished is null !");
                        }
                        
                        break;
                    }
                    // -------------------------------------------------- //
                default:
                    throw new MOSException("FileSystemManager: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    // ========== FORMAT LIST OF FILES ========== //
    private static String getFilesList( int totalFiles , ArrayList<String[]> descriptions )
    {
        String listOfFiles = "";
        
        int filesToFind = totalFiles;
        ArrayList<String[]> descriptionsList = descriptions;
        
        int wordsToSkip = 0;
        int recheckBounds = 0;
        
        int skipStep = 2; 
        
        for( int i = 0 ; i < descriptionsList.size() ; i++ )
        {
            if( (i%2) == 0 )
            {
                wordsToSkip = 0;
                recheckBounds = skipStep;
            }
            else
            {
                wordsToSkip = 2;
                recheckBounds = skipStep*2;
            }
            
            String[] currentDescription = descriptionsList.get(i);
            for( int j = 0 ; j < currentDescription.length ; j++ )
            {
                if( wordsToSkip == 0 )
                {
                    if( (j%2) != 0 )
                    {
                        filesToFind--;
                        if( filesToFind == 0 )
                        {
                            listOfFiles += currentDescription[j];
                            break;
                        }
                        else
                        {
                            listOfFiles += currentDescription[j]+"|";
                        }
                    }
                    else
                    {
                        listOfFiles += currentDescription[j];    
                    }
                }
                else
                {
                    wordsToSkip--;
                }
                
                if( (j+1) == recheckBounds )
                {
                    wordsToSkip = skipStep;
                    recheckBounds += skipStep*2;
                }
            }
            
            if( filesToFind == 0 )
            {
                break;
            }
        }
        return listOfFiles;
    }
    // ========================================== //
    
    // ========= GET FILE INFORMATION =========== //
    private static int[] getFileInformation( String fileName , ArrayList<String[]> descriptions )
    {
        int[] fileAddressAndSize = new int[2];
        
        ArrayList<String[]> descriptionsList = descriptions;
        String fileToFind = fileName;
        
        boolean checkAnotherPage = false;
        
        for( int i = 0 ; i < descriptionsList.size() ; i++ )
        {
            String[] currentPage = descriptionsList.get(i);
            
            if( checkAnotherPage )
            {
                fileAddressAndSize[0] = Convert.toInt(currentPage[0]);
                fileAddressAndSize[1] = Convert.toInt(currentPage[1]);
                break;
            }
            
            for( int j = 0 ; j < currentPage.length/2 ; j++ )
            {
                if( (currentPage[j*2]+currentPage[j*2+1]).equals(fileToFind) )
                {
                    if( (j+1)*2 < currentPage.length )
                    {
                        fileAddressAndSize[0] = Convert.toInt(currentPage[(j+1)*2]);
                        fileAddressAndSize[1] = Convert.toInt(currentPage[(j+1)*2+1]);
                    }
                    else
                    {
                        checkAnotherPage = true;
                        break;
                    }
                }
            }
        }
        return fileAddressAndSize;
    }
    // ========================================== //
    
    // ============ PAGE TO STRING ============== //
    private String getPageAsString( String[] page )
    {
        String pageString = "";
        String[] tempPage = page;
        
        for( int i = 0 ; i < tempPage.length ; i++ )
        {
            pageString += tempPage[i];
        }
        
        return pageString;
    }
    // ========================================== //
}
