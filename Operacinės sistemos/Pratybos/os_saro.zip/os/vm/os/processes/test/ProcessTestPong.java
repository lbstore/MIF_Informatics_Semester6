package vu.os.vm.os.processes.test;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.os.processes.ProcessBase;
import vu.os.vm.os.descriptors.subtypes.CPUState;

public class ProcessTestPong extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessTestPong( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE1");
                    //returnTask.SHEDULER();
                    //returnTask.REQUESTR( ResourceId.FileSystemTaskFinished, 3 );   
                    break;
                case 2:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE2");
                    //returnTask.FREER( ResourceId.FileSystemTask, "READFILEPAGE|PR01.PRG|2", ProcessId.FileSystemManager );   
                    //returnTask.FREER( ResourceId.CommandLineTask, "READTASK", ProcessId.CommandLine );
                    //returnTask.REQUESTR( ResourceId.PlainMessage, 3 );       
                    break;    
                case 3:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE3");
                    //returnTask.REQUESTR( ResourceId.FileSystemTaskFinished, ProcessId.CurrentProcess );
                    //returnTask.REQUESTR( ResourceId.PlainMessage, 3 );   
                    break;
                case 4:
                    //String result = resource.resourceElement;
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE4 resourceElement: "+ result);
                    /*
                    System.out.println(" ANSWER: creatorId:"+resource.creatorId);
                    System.out.println(" ANSWER: resourcePart:"+resource.resourcePart);
                    System.out.println(" ANSWER: resourceElement:"+resource.resourceElement);
                    System.out.println(" ANSWER: createdProcessId:"+resource.createdProcessId);
                    System.out.println(" ANSWER: createdResourceId:"+resource.createdResourceId);
                    */
                   
                    break;
                case 5:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE5 wait for workFinished");
                    returnTask.REQUESTR(ResourceId.WorkFinished, ProcessId.CurrentProcess);         
                    GOTO(5);
                    break;                    
                case 6:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE5 FREER WorkFinished");
                    returnTask.FREER(ResourceId.WorkFinished, "Pong! .. oh shut down now.",0);
                    break;
                case 7:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Pong: CASE6");
                    returnTask.SHEDULER();
                    GOTO(1);
                    break;
                default:
                    throw new MOSException("pId:"+ProcessId.CurrentProcess+" SystemProcess: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
}