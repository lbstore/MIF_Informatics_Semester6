package vu.os.vm.os.processes.test;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;
import vu.os.vm.os.Constant;
import vu.os.vm.os.processes.ProcessBase;

import vu.os.vm.ui.GUI;

public class ProcessTestPing extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessTestPing( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Ping: CASE1");
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|SUMU.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.InputOutputTask, "Ping wants input 123456|READLINE", ProcessId.InputOutputManager );
                    //returnTask.FREER( ResourceId.PlainMessage, "Ping plain message0", 3 );
                    break;
                case 2:
                    //returnTask.FREER( ResourceId.InputOutputTask, "Ping wants output 123456|WRITELINE|cia tekstas isvedimui", ProcessId.InputOutputManager );
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|SUMU.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|PR01.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.PlainMessage, "Ping plain message1", 3 );
                    break;    
                case 3:
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|SUMU.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|SUMU.PRG|2", ProcessId.MainProcess );
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Ping: CASE2 aaa:"+resource.resourceElement);
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|PR01.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.PlainMessage, "Ping plain message2", 3 );
                    //GOTO(1);
                    break;
                case 4:
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|SUMU.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|SUMU.PRG|2", ProcessId.MainProcess );
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Ping: CASE4 wait for workFinished");
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|PR01.PRG|2", ProcessId.MainProcess );
                    //returnTask.FREER( ResourceId.FileSystemTaskFinished, "start pong", 3 );
                    break;
                case 5:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Ping: CASE5");
                    //returnTask.FREER( ResourceId.ExternalTask, "CREATEJB|PR01.PRG|2", ProcessId.MainProcess );
                    break;
                case 6:
                    //System.out.println("pId:"+ProcessId.CurrentProcess+" Ping: CASE6");
                    //returnTask.REQUESTR(ResourceId.WorkFinished, ProcessId.CurrentProcess);   
                    returnTask.REQUESTR(ResourceId.WorkFinished, ProcessId.CurrentProcess);         
                    GOTO(6);
                    break;
                default:
                    throw new MOSException("pId:"+ProcessId.CurrentProcess+" SystemProcess: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
}