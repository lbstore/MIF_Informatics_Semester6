package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

import vu.os.vm.util.Convert;

import java.util.ArrayList;

public class ProcessLoader extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessLoader( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private static final String SPLIT_REGEX = "\\|";
    private static final String SPLIT_SPACE = " " ;
    private static final int LOADING_HEADER = 0;
    private static final int LOADING_FILE_DATA = 1;
    private static final int PAGE_SIZE = 10;
    private static final int CURRENT_PROGRAM_SIZE_WORD = 2;
    private static final int REAL_PROGRAM_SIZE_WORD = 3;
    private static final int REAL_DATA_SEGMENT_SIZE_WORD = 7;
    private static final int REAL_STACK_SEGMENT_SIZE_WORD = 8;
    private static final String FINISHED_SUCCESSFULLY = "0";
    
    private String[] parameters = null;
    private String[] pageTablePages = null;
    private String[] userMemoryPages = null;
    
    private String[] fileHeader = null;
    
    private int pageLoadingState = 0; // 0 - reading file header; 1 - reading file data
    private int pageToLoad = 0;
    private int pagesToLoad = 0;
    private int realDSSize = 0;
    private int realSSSize = 0;
    private int realProgramSize = 0;
    private int pageTableSize = 0;
    private int wordsToSkipAfterDS = 0;
    private int askingProcess = 0;
    
    private ArrayList<String[]> pageTable = null;
    private ArrayList<String[]> programPages = null;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    {
                        returnTask.REQUESTR( ResourceId.LoadPackage , ProcessId.CurrentProcess );
                        break;
                    }
                case 2:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            askingProcess = resource.creatorId;
                            
                            parameters = result.split(SPLIT_REGEX);
                            pageTablePages = parameters[1].split(SPLIT_SPACE);
                            userMemoryPages = parameters[2].split(SPLIT_SPACE);
                            pageTableSize = pageTablePages.length;
                            
                            pageLoadingState = LOADING_HEADER;
                            pageToLoad = 0;
                        }
                        else
                        {
                            throw new MOSException("ProcessLoader: LoadPackage is null!");
                        }
                        break;
                    }
                case 3:
                    {
                        returnTask.FREER( ResourceId.FileSystemTask , 
                                          "READFILEPAGE|"+parameters[0]+"|"+pageToLoad , 
                                          ProcessId.FileSystemManager );
                        break;
                    }
                case 4:
                    {
                        returnTask.REQUESTR( ResourceId.FileSystemTaskFinished , ProcessId.CurrentProcess );
                        break;
                    }
                case 5:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            if( pageLoadingState == LOADING_HEADER )
                            {
                                fileHeader = stringToPage( result );
                                if( fileHeader != null )
                                {
                                    pagesToLoad = Convert.toInt( fileHeader[CURRENT_PROGRAM_SIZE_WORD] );
                                    realDSSize = Convert.toInt( fileHeader[REAL_DATA_SEGMENT_SIZE_WORD] );
                                    realProgramSize = Convert.toInt( fileHeader[REAL_PROGRAM_SIZE_WORD] );
                                    realSSSize = Convert.toInt( fileHeader[REAL_STACK_SEGMENT_SIZE_WORD] );
                                    
                                    pageToLoad = 1;
                                    
                                    programPages = new ArrayList<String[]>();
                                    pageLoadingState = LOADING_FILE_DATA;
                                    
                                    GOTO(3);
                                }
                                else
                                {
                                    throw new MOSException("ProcessLoader: file header is null!");
                                }
                            }
                            else if( pageLoadingState == LOADING_FILE_DATA )
                            {
                                pagesToLoad--;
                                String[] tempPage = stringToPage( result );
                                if( tempPage != null )
                                {
                                    programPages.add(tempPage);
                                    tempPage = null;
                                }
                                else
                                {
                                    throw new MOSException("ProcessLoader: program page is null!");
                                }
                                
                                if( pagesToLoad == 0 )
                                {
                                    // ========= PREPARE PAGE TABLE PAGES ========= //
                                    pageTable = new ArrayList<String[]>();
                                    
                                    for( int i = 0 ; i <  pageTableSize ; i++ )
                                    {
                                        String[] emptyPage = new String[PAGE_SIZE];
                                        emptyPage = fillPageWithStars(emptyPage);
                                        pageTable.add(emptyPage);
                                        emptyPage = null;
                                    }
                                    // ============================================ //
                                    
                                    if( (programPages.size()+realSSSize) == userMemoryPages.length )
                                    {
                                        // ============= SAVE PROGRAM DATA TO RAM ============ //
                                        // =============== AND BUILD PAGE TABLE ============== //
                                        wordsToSkipAfterDS = realProgramSize-programPages.size()-realSSSize;
                                        
                                        int addressInOA = 0;
                                        int currentPTPage = 0;
                                        int currentWordInPT = 0;
                                        boolean skipWords = false;
                                        for( int i = 0 ; i < realProgramSize ; i++ )
                                        {
                                            currentPTPage = (int)Math.floor((float)i/(float)PAGE_SIZE);
                                            currentWordInPT = i%PAGE_SIZE;
                                            
                                            if( i < programPages.size() )
                                            {
                                                addressInOA = Convert.toInt( userMemoryPages[i] );
                                                cpu.ram.writePage( addressInOA , programPages.get(i) );
                                                
                                                pageTable.get(currentPTPage)[currentWordInPT] = userMemoryPages[i];
                                            }
                                            else if( i >= (programPages.size()+wordsToSkipAfterDS) )
                                            {
                                                pageTable.get(currentPTPage)[currentWordInPT] = userMemoryPages[i-wordsToSkipAfterDS];
                                            }
                                        }
                                        // =================================================== //
                                        
                                        if( pageTable.size() == pageTableSize )
                                        {
                                            // =============== SAVE PAGE TABLE TO RAM ============ //
                                            int pageTablePageAddress = 0;
                                            
                                            for( int i = 0 ; i < pageTable.size() ; i++ )
                                            {
                                                pageTablePageAddress = Convert.toInt(pageTablePages[i]);
                                                cpu.ram.writePage( pageTablePageAddress , pageTable.get(i) );
                                            }
                                            // =================================================== //
                                        }
                                        else
                                        {
                                            throw new MOSException("ProcessLoader: page table size: "
                                                                   +pageTable.size()+" | given memory: "+pageTableSize);
                                        }
                                        
                                        // ========== FORMAT FINAL ANSWER ============ //
                                        returnTask.FREER(ResourceId.LoadTaskFinished, FINISHED_SUCCESSFULLY , askingProcess );
                                        // =========================================== //
                                        
                                        GOTO(1);  
                                        
                                    }
                                    else
                                    {
                                        throw new MOSException("ProcessLoader: needed user momory: "+
                                                               (programPages.size()+realSSSize)+
                                                               " | given user memory: "+userMemoryPages.length);
                                    }
                                    
                                }
                                else if( pagesToLoad > 0 )
                                {
                                    pageToLoad++;
                                    GOTO(3);
                                }
                            }
                        }
                        else
                        {
                            throw new MOSException("ProcessLoader: FileSystemTaskFinished is null!");
                        }
                        break;
                    }
                default:
                    throw new MOSException("ProcessLoader: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    // ============= STRING TO PAGE ============= //
    private String[] stringToPage( String pageString )
    {
        String[] page = null;
        String tempString = pageString;
        int wordLength = 4;
        
        if( (pageString.length()%4) == 0 && (pageString.length()/4) == PAGE_SIZE )
        {
            page = new String[10];
            for( int i = 0 ; i < PAGE_SIZE ; i++ )
            {
                page[i] = tempString.substring(i*4,4*(i+1));
            }
        }
        
        return page;
    }
    // ========================================== //
    
    // ======== FILL PAGE WITH **** ============= //
    private String[] fillPageWithStars( String[] page )
    {
        String[] returnPage = page;
        for( int i = 0 ; i < returnPage.length ; i++ )
        {
            returnPage[i] = "****";
        }
        
        return returnPage;
    }
    // ========================================== //
}