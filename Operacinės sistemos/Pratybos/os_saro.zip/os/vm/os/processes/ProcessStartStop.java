package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;
import vu.os.vm.os.Constant;

import vu.os.vm.os.processes.ProcessFileSystemManager;
import vu.os.vm.os.processes.ProcessHddDevice;
import vu.os.vm.os.processes.ProcessCommandLine;
import vu.os.vm.os.processes.ProcessInputDevice;
import vu.os.vm.os.processes.ProcessInputOutputManager;
import vu.os.vm.os.processes.ProcessInterrupt;
import vu.os.vm.os.processes.ProcessJobGovernor;
import vu.os.vm.os.processes.ProcessLoader;
import vu.os.vm.os.processes.ProcessMainProcess;
import vu.os.vm.os.processes.ProcessOutputDevice;

import vu.os.vm.os.descriptors.ResourceDescriptorIOStream;
import vu.os.vm.os.descriptors.ResourceDescriptorMemory;
import vu.os.vm.os.descriptors.ResourceDescriptorMessage;

import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.CPUState;

import vu.os.vm.util.Convert;

import java.util.LinkedList;

public class ProcessStartStop extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessStartStop( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private int manageableMemoryStartPage = 10;
    private int manageableMemoryEndPage = 999;
    
    private boolean activateProcesses = true;
    private boolean printWorkProcess = false;
    private boolean printMessages = true;
    
    //------------------------------------------------------------------------//
    //----------------------------- NEREDAGUOTI !!! --------------------------//
    private LinkedList<Integer> createdResourcesIds = new LinkedList<Integer>();
    private LinkedList<Integer> createdProcessesIds = new LinkedList<Integer>();
    
    private int currentProcessToDestory = 0;
    private int currentResourceToDestory = 0;
    
    private String[] messageResourceNames = {
                "LoadPackage",
                "FileSystemTask",
                "ExternalTask",
                "CommandLineTask",
                "InputOutputTask",
                "ProgramTask",
                "HddDeviceTask",
                "InputDeviceTask",
                "OutputDeviceTask",
                "InterruptTask",
                "InterruptEvent",
                "WorkFinished",
                "FileSystemTaskFinished",
                "LoadTaskFinished",
                "InputOutputTaskFinished",
                "OutputDeviceTaskFinished",
                "HddDeviceTaskFinished",
                "InputDeviceTaskFinished",
                "PlainMessage"};
    private int currentMessageCreating = 0;
    
    private String[] processNames = {
                "HddDevice",
                "FileSystemManager",
                "InputDevice",
                "OutputDevice",
                "InputOutputManager",
                "CommandLine",
                "Loader",
                "Interrupt",
                "MainProcess",
                "Idle"};
    private int currentProcessCreating = 0;
    private int processToActivate = 0;
    //----------------------------- NEREDAGUOTI !!! --------------------------//
    //------------------------------------------------------------------------//
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                {
                    ProcessId.StartStop = ProcessId.CurrentProcess;
                    //-- CREATE RESOURCE: ------------------------------------//
                    print("StartStop: creating resource "+"UserMemory");
                    
                    LinkedList<ResourceElement> ramList  = new LinkedList<ResourceElement>();
                    
                    for (int i=manageableMemoryStartPage; i<=manageableMemoryEndPage; i++) {
                        ResourceElement ramPage = new ResourceElement();
                        ramPage.creatorId = ProcessId.CurrentProcess;
                        ramPage.resourcePart = i;
                        ramPage.resourceElement = Convert.toWord(i);
                        
                        ramList.add(ramPage);
                    }
                    
                    returnTask.CREATERD("UserMemory",true,ramList,null,Constant.ResourceMemory);
                    break;
                }
                case 2:
                {
                    if (resource.createdResourceId==null) { throw new MOSException("StartStop: failed to create resource. createdResourceId==null");}
                    ResourceId.UserMemory = resource.createdResourceId;
                    createdResourcesIds.add(resource.createdResourceId);
                    //-- CREATE RESOURCE: ------------------------------------//
                    print("StartStop: creating resource "+"InputOutputStream");
                    
                    LinkedList<ResourceElement> IOStreamElements  = new LinkedList<ResourceElement>();
                    

                    for (int i=1; i<=3; i++) {
                        ResourceElement element = new ResourceElement();
                        element.creatorId = ProcessId.CurrentProcess;
                        element.resourcePart = i;
                        element.resourceElement = "";
                        
                        IOStreamElements.add(element);
                    }

                    returnTask.CREATERD("InputOutputStream",true,IOStreamElements,null,Constant.ResourceIOStream);
                    break;    
                }
                case 3:
                {
                    if (resource.createdResourceId==null) { throw new MOSException("StartStop: failed to create resource. createdResourceId==null");}
                    ResourceId.InputOutputStream = resource.createdResourceId;
                    createdResourcesIds.add(resource.createdResourceId);
                    break;
                }
                case 4:
                {
                    //-- CREATE MESSAGE RESOURCES: ---------------------------//
                    print("StartStop: creating resource "+messageResourceNames[currentMessageCreating]+" currentMessageCreating:"+currentMessageCreating);
                    
                    returnTask.CREATERD(messageResourceNames[currentMessageCreating],false,null,null,Constant.ResourceMessage);
                    break;
                }
                case 5:
                {
                    if (resource.createdResourceId==null) { throw new MOSException("StartStop: failed to create message resource: "+ messageResourceNames[currentMessageCreating]);}
                    
                    //--------------------------------------------------------//
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    createdResourcesIds.add(resource.createdResourceId);
                    
                    switch (currentMessageCreating) {
                        case 0: ResourceId.LoadPackage = resource.createdResourceId; break;
                        case 1: ResourceId.FileSystemTask = resource.createdResourceId; break;
                        case 2: ResourceId.ExternalTask = resource.createdResourceId; break;
                        case 3: ResourceId.CommandLineTask = resource.createdResourceId; break;
                        case 4: ResourceId.InputOutputTask = resource.createdResourceId; break;
                        case 5: ResourceId.ProgramTask = resource.createdResourceId; break;
                        case 6: ResourceId.HddDeviceTask = resource.createdResourceId; break;
                        case 7: ResourceId.InputDeviceTask = resource.createdResourceId; break;
                        case 8: ResourceId.OutputDeviceTask = resource.createdResourceId; break;
                        case 9: ResourceId.InterruptTask = resource.createdResourceId; break;
                        case 10: ResourceId.InterruptEvent = resource.createdResourceId; break;
                        case 11: ResourceId.WorkFinished = resource.createdResourceId; break;
                        case 12: ResourceId.FileSystemTaskFinished = resource.createdResourceId; break;
                        case 13: ResourceId.LoadTaskFinished = resource.createdResourceId; break;
                        case 14: ResourceId.InputOutputTaskFinished = resource.createdResourceId; break;
                        case 15: ResourceId.OutputDeviceTaskFinished = resource.createdResourceId; break;
                        case 16: ResourceId.HddDeviceTaskFinished = resource.createdResourceId; break;
                        case 17: ResourceId.InputDeviceTaskFinished = resource.createdResourceId; break;
                        case 18: ResourceId.PlainMessage = resource.createdResourceId; break;
                        default: throw new MOSException("StartStop: unknown int currentMessageCreating value: "+currentMessageCreating);
                    }
                    
                    if (currentMessageCreating < 18) {
                        currentMessageCreating++;
                        GOTO(4);
                    }
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    //--------------------------------------------------------//
                    break; 
                }
                case 6:
                {
                    printMessage("StartStop: creating resources finished");
                    break;
                }
                case 7:
                {
                    //-- CREATE PROCESSES: -----------------------------------//
                    print("StartStop: creating process "+processNames[currentProcessCreating]+" currentProcessCreating:"+currentProcessCreating);
                    
                    //--------------------------------------------------------//
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    ProcessBase systemProcess = null;
                    int priority = 7;
                    switch (currentProcessCreating) {
                        case 0: systemProcess = new ProcessHddDevice(cpu);          priority = 5; break;
                        case 1: systemProcess = new ProcessFileSystemManager(cpu);  priority = 5; break;
                        case 2: systemProcess = new ProcessInputDevice(cpu);        priority = 7; break;
                        case 3: systemProcess = new ProcessOutputDevice(cpu);       priority = 8; break;
                        case 4: systemProcess = new ProcessInputOutputManager(cpu); priority = 7; break;
                        case 5: systemProcess = new ProcessCommandLine(cpu);        priority = 7; break;
                        case 6: systemProcess = new ProcessLoader(cpu);             priority = 7; break;
                        case 7: systemProcess = new ProcessInterrupt(cpu);          priority = 8; break;
                        case 8: systemProcess = new ProcessMainProcess(cpu);        priority = 7; break;
                        default: throw new MOSException("StartStop: unknown int currentProcessCreating value: "+currentProcessCreating);
                    }
                    returnTask.CREATEPD(processNames[currentProcessCreating],new CPUState(cpu),null,null,priority,systemProcess);
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    //--------------------------------------------------------//
                    break;
                }
                case 8:
                {
                    if (resource.createdProcessId==null) { throw new MOSException("StartStop: failed to create process: "+ processNames[currentProcessCreating]);}
                    
                    createdProcessesIds.add(resource.createdProcessId);
                    //--------------------------------------------------------//
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    switch (currentProcessCreating) {
                        case 0: ProcessId.HddDevice = resource.createdProcessId; break;
                        case 1: ProcessId.FileSystemManager = resource.createdProcessId; break;
                        case 2: ProcessId.InputDevice = resource.createdProcessId; break;
                        case 3: ProcessId.OutputDevice = resource.createdProcessId; break;
                        case 4: ProcessId.InputOutputManager = resource.createdProcessId; break;
                        case 5: ProcessId.CommandLine = resource.createdProcessId; break;
                        case 6: ProcessId.Loader = resource.createdProcessId; break;
                        case 7: ProcessId.Interrupt = resource.createdProcessId; break;
                        case 8: ProcessId.MainProcess = resource.createdProcessId; break;
                        default: throw new MOSException("StartStop: unknown int currentProcessCreating value: "+currentProcessCreating);
                    }
                    
                    if (currentProcessCreating < 8) {
                        currentProcessCreating++;
                        GOTO(7);
                    }
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    //--------------------------------------------------------//
                    break;
                }
                case 9:
                {
                    print("StartStop: creating process Idle");
                    CPUState idleProcessCpuState = new CPUState(cpu);
                    returnTask.CREATEPD("Idle",idleProcessCpuState,null,null,0,null);
                    break;
                }
                case 10:
                {
                    if (resource.createdProcessId==null) { throw new MOSException("StartStop: failed to create Idle process");}
                    
                    ProcessId.Idle = resource.createdProcessId;
                    createdProcessesIds.add(resource.createdProcessId);
                    break;
                }
                
                case 11:
                {
                    printMessage("StartStop: creating processes finished");
                    if (!activateProcesses) {
                        GOTO(14);
                    }
                    break;
                }
                case 12:
                {
                    print("StartStop: activating process "+processNames[processToActivate]);

                    //--------------------------------------------------------//
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    switch (processToActivate) {
                        case 0: returnTask.ACTIVATEP(ProcessId.HddDevice); break;
                        case 1: returnTask.ACTIVATEP(ProcessId.FileSystemManager); break;
                        case 2: returnTask.ACTIVATEP(ProcessId.InputDevice); break;
                        case 3: returnTask.ACTIVATEP(ProcessId.OutputDevice); break;
                        case 4: returnTask.ACTIVATEP(ProcessId.InputOutputManager); break;
                        case 5: returnTask.ACTIVATEP(ProcessId.CommandLine); break;
                        case 6: returnTask.ACTIVATEP(ProcessId.Loader); break;
                        case 7: returnTask.ACTIVATEP(ProcessId.Interrupt); break;
                        case 8: returnTask.ACTIVATEP(ProcessId.MainProcess); break;
                        case 9: returnTask.ACTIVATEP(ProcessId.Idle); break;
                        default: throw new MOSException("StartStop: unknown int processToActivate value: "+processToActivate);
                    }
                    break;
                }
                case 13:
                {
                    if (processToActivate < 9) {
                        processToActivate++;
                        GOTO(12);
                    }
                    // -------------------- NEREDAGUOTI !!! ------------------//
                    //--------------------------------------------------------//
                    break;
                }
                case 14:
                {
                    printMessage("StartStop: sending CommandLineTask");
                    returnTask.FREER(ResourceId.CommandLineTask, "READTASKINITIATE", ProcessId.CommandLine);
                    break;
                }
                case 15:
                {
                    printMessage("StartStop: os initiated");
                    returnTask.REQUESTR(ResourceId.WorkFinished, ProcessId.CurrentProcess);
                    break;
                }
                case 16:
                {
                    if (resource.resourceElement==null) { throw new MOSException("StartStop: failed to get WorkFinished resource");}
                    printMessage("StartStop: WorkFinished: "+resource.resourceElement);
                    break;
                }
                case 17:
                {
                    print("StartStop: destroying process: "+createdProcessesIds.get(currentProcessToDestory));
                    returnTask.DESTROYPD(createdProcessesIds.get(currentProcessToDestory));
                    break;
                }
                case 18:
                {
                    if (currentProcessToDestory < createdProcessesIds.size()-1) {
                        currentProcessToDestory++;
                        GOTO(17);
                    }
                    break;
                }
                case 19:
                {
                    print("StartStop: destroying resource: "+createdResourcesIds.get(currentResourceToDestory));
                    returnTask.DESTROYRD(createdResourcesIds.get(currentResourceToDestory));
                    break;
                }
                case 20:
                {
                    if (currentResourceToDestory < createdResourcesIds.size()-1) {
                        currentResourceToDestory++;
                        GOTO(19);
                    }
                    break;
                }
                case 21:
                {
                    printMessage("StartStop: MOS should now turn off the mashine");
                    cpu.HALT();
                }
                default:
                    throw new MOSException("StartStop: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    
    private void print(Object o) {
        if (printWorkProcess) {
            System.out.println(o.toString());
        }
    }
    
    private void printMessage(Object o) {
        if (printMessages) {
            System.out.println(o.toString());
        }
    }
}