package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;
import vu.os.vm.util.Convert;

import vu.os.vm.ui.GUI;

import java.util.ArrayList;

public class ProcessInputOutputManager extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessInputOutputManager( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    private static final String SPLIT_REGEX = "\\|";
    private static final String READ_LINE_TASK = "READLINE";
    private static final String WRITE_LINE_TASK = "WRITELINE";
    private static final String ERROR_CODE = "-1";
    private static final String COMPLETED_SUCCESSFULLY = "0" ;
    private static final int PAGE_SIZE = 10;
    
    private String[] parameters = null;
    private String[] linesToWrite = null;
    private String headline = null;
    private String currentTask = null;
    
    private int askingProcess = 0;
    private int linesLeft = 0;
    private int currentLine = 0;
    
    private boolean writingHeadline = true;
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    {
                        returnTask.REQUESTR( ResourceId.InputOutputTask , ProcessId.CurrentProcess );
                        break;
                    }
                case 2:
                    {
                        String result = resource.resourceElement;
                        
                        if( result != null )
                        {
                            askingProcess = resource.creatorId;
                            
                            parameters = result.split(SPLIT_REGEX);
                            headline = parameters[0];
                            
                            if( parameters[1].equals(READ_LINE_TASK) )
                            {
                                currentTask = READ_LINE_TASK;
                            }
                            else if( parameters[1].equals(WRITE_LINE_TASK) )
                            {
                                linesToWrite = breakString( parameters[2] );
                                linesLeft = linesToWrite.length;
                                currentLine = 0;
                                
                                currentTask = WRITE_LINE_TASK;
                            }
                            else
                            {
                                throw new MOSException("InputOutputManager: illegal InputOutputTask: "+parameters[1]);
                            }
                        }
                        else
                        {
                            throw new MOSException("InputOutputManager: InputOutputTask is null!");
                        }
                        
                        writingHeadline = true;
                        
                        break;
                    }
                case 3:
                    {
                        if (headline.length() > 20) { 
                            headline = headline.substring(0,20);
                        }
                        String headLineText = String.format(">[ProcesId:%-2d]   [%-20s]:",askingProcess,headline);
                        returnTask.FREER( ResourceId.OutputDeviceTask, "WRITE|"+headLineText , ProcessId.OutputDevice );
                        break;
                    }
                case 4:
                    {
                        returnTask.REQUESTR( ResourceId.OutputDeviceTaskFinished, ProcessId.CurrentProcess );
                        break;
                    }
                case 5:
                    {
                        String result = resource.resourceElement;
                        if( result != null )
                        {
                            if( result.equals(COMPLETED_SUCCESSFULLY) )
                            {
                                if( writingHeadline )
                                {
                                    writingHeadline = false;
                                }
                                else
                                {
                                    writingHeadline = true;
                                }
                                
                                if( currentTask.equals(READ_LINE_TASK) && !writingHeadline)
                                {
                                    returnTask.FREER( ResourceId.InputDeviceTask, "READ" , ProcessId.InputDevice );
                                }
                                else if( currentTask.equals(WRITE_LINE_TASK) && !writingHeadline )
                                {
                                    String lineToPrint = linesToWrite[currentLine];
                                    
                                    if (lineToPrint.length() < 40) {
                                        //GUI.log(lineToPrint);
                                        lineToPrint += "�";
                                        lineToPrint = lineToPrint.replaceFirst("\\$|�|\n","�");
                                        String[] strarray = lineToPrint.split("�",2);
                                        lineToPrint = strarray[0]+"�$"+strarray[1];
                                    } 
                                    
                                    returnTask.FREER( ResourceId.OutputDeviceTask, 
                                                      "WRITE|"+ lineToPrint, ProcessId.OutputDevice );
                                    currentLine++;
                                    linesLeft--;
                                    GOTO(4);
                                }
                                else if( writingHeadline )
                                {
                                    if( linesLeft > 0 )
                                    {
                                        GOTO(3);
                                    }
                                    else
                                    {
                                        returnTask.FREER( ResourceId.InputOutputTaskFinished, 
                                                          COMPLETED_SUCCESSFULLY , askingProcess );
                                        GOTO(1);
                                    }
                                }
                                else
                                {
                                    throw new MOSException("InputOutputManager: illegal task position!");
                                }
                            }
                            else
                            {
                                returnTask.FREER( ResourceId.InputOutputTaskFinished, ERROR_CODE , askingProcess);
                                GOTO(1);
                            }
                        }
                        else
                        {
                            throw new MOSException("InputOutputManager: InputOutputTask is null!");
                        }
                        
                        break;
                    }
                case 6:
                    {
                        returnTask.REQUESTR( ResourceId.InputDeviceTaskFinished, ProcessId.CurrentProcess );
                        break;
                    }
                case 7:
                    {
                        String result = resource.resourceElement;
                        
                        if( result != null )
                        {
                            String[] deviceParameters = result.split(SPLIT_REGEX);
                            
                            if( deviceParameters[0].equals(ERROR_CODE) )
                            {
                                returnTask.FREER( ResourceId.InputOutputTaskFinished, ERROR_CODE , askingProcess);
                            }
                            else
                            {
                                int bufferAddress = Convert.toInt(deviceParameters[0]);
                                String lineToReturn = getLineFromBuffer(cpu.ram.readPage(bufferAddress) );
                                
                                returnTask.FREER( ResourceId.InputOutputTaskFinished, 
                                                  COMPLETED_SUCCESSFULLY+"|"+lineToReturn , askingProcess);
                            }
                            GOTO(1);
                        }
                        else
                        {
                            throw new MOSException("InputOutputManager: InputDeviceTaskFinished is null!");
                        }
                        break;
                    }
                default:
                    throw new MOSException("InputOutputManager: illeagal position!");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
    
    // ====== GET LINE FROM INPUT BUFFER ======== //
    private String getLineFromBuffer( String[] buffer )
    {
        String endOfLine = "$";
        String bufferString = "";
        String resultString = null;
        
        for( int i = 0 ; i < buffer.length ; i++ )
        {
            bufferString += buffer[i];
        }
        
        for( int i = 0 ; i < bufferString.length() ; i++ )
        {
            if( bufferString.substring(i,i+1).equals(endOfLine) )
            {
                resultString = bufferString.substring(0,i);
                break;
            }
        }
        
        if( resultString == null )
        {
            resultString = bufferString.substring(0,bufferString.length());
        }
        
        return resultString;
    }
    // ========================================== //
    
    // ========= BREAK STRING INTO PARTS ======== //
    private String[] breakString( String text )
    {
        ArrayList<String> linesArrayList = new ArrayList<String>();
        String[] lines = null; 
        
        String currentText = text;
        
        String newLine1 = "�";
        String newLine2 = "\n";
        
        int startIndex = 0;
        
        for( int i = 0 ; i < currentText.length() ; i++ )
        {
            if( (i+1) != currentText.length() && currentText.substring(i,i+2).equals(newLine2) )
            {
                
                linesArrayList.add( currentText.substring( startIndex , i ) );
                i += newLine2.length();
                startIndex = i;
            }
            else if( currentText.substring(i,i+1).equals(newLine1) )
            {
                
                linesArrayList.add( currentText.substring( startIndex , i ) );
                i += newLine1.length();
                startIndex = i;
            }
        }
        
        if( (currentText.length() - startIndex) > 0 )
        {
            linesArrayList.add( currentText.substring( startIndex , currentText.length() ) );
        }
        
        lines =  new String[linesArrayList.size()];
        
        for( int i = 0 ; i < linesArrayList.size() ; i++ )
        {
            lines[i] = linesArrayList.get(i);
        }
        
        return lines;
    }
    // ========================================== //
}