package vu.os.vm.os.processes;

import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.ProcessId;
import vu.os.vm.os.ResourceId;

public class ProcessExample extends ProcessBase {
    
    // konstruktorius turi iskviesti ProcessBase konstrukturiu !
    public ProcessExample( VirtualCPUCore cpu ) {
        super(cpu);
    }
    
    //-- "DATA SEGMENT" --------------------------------------------------------
    
    
    
    
    
    //--------------------------------------------------------------------------

    //-- "CODE SEGMENT" --------------------------------------------------------    
    public CoreTask run( CoreAnswer resource ) {
        CoreTask returnTask = new CoreTask();
        while (!returnTask.finished) {
            switch (GetNextPosition()) {
            //------------------------------------------------------------------
                case 1: 
                    returnTask.REQUESTR(ResourceId.FileSystemTask, ProcessId.CurrentProcess);
                    break;
                case 2:
                    // CoreAnswer esancios dalys apie gauta resursa: jei resourceElement == null - resurso gauti neimanoma
                    //public Integer  creatorId = null;
                    //public Integer  resourcePart = null;
                    //public String   resourceElement = null;
                    // CoreAnswer esancios dalys sukurta resursa/procesa: jei createdProcessId/createdResourceId == null - nepavyko sukurti
                    //public Integer  createdProcessId = null;
                    //public Integer  createdResourceId = null;
                    
                    break;    
                case 3:
                    // ... kodas ...
                    break;
                case 4:
                    // ... kodas ...
                    break;
                case 5:
                    // ... kodas ...
                    break;
                case 6:
                    // ... kodas ...
                    GOTO(1);
                    break;
                default:
                    throw new MOSException("SystemProcess: illeagal position");
            //------------------------------------------------------------------
            }
        }
        return returnTask;
    }
}