package vu.os.vm.os;


public class Constant {
    // OS PRIMITIVES
    public static final int PRIMITIVENONE = 0;

    public static final int CREATEPD = 1;
    public static final int DESTROYPD = 2;
    public static final int STOPP = 3;
    public static final int ACTIVATEP = 4;
    public static final int CHANGEPP = 5;
    
    public static final int CREATERD = 6;
    public static final int DESTROYRD = 7;
    public static final int REQUESTR = 8;
    public static final int FREER = 9;
    
    public static final int SHEDULER = 10;
    
    public static final int DISTRIBUTOR = 11;
    
    // PROCESS STATES
    public static final int RUNNING = 1;
    public static final int READY = 2;
    public static final int READYS = 3;
    public static final int BLOCKED = 4;
    public static final int BLOCKEDS = 5;
    
    // LISTS IN
    public static final int ReadyProcessList = -1;
    // WaitingProcessList - atitinkamo resurso id

    // RESOURCE CLASSES
    public static final int ResourceIOStream = 1;
    public static final int ResourceMemory = 2;
    public static final int ResourceMessage = 3;
    
    // other
    public static final int ProcessNone = 0;
    public static final int maxPriority = 9;
    
    // IOStream
    
    public static final int InputStream = 1;
    public static final int OutputStream = 2;
    public static final int InputOutputStream = 3;

    public static final String TimerResetValue = "0010";
}