package vu.os.vm.os;

import vu.os.vm.os.Constant;

import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;
import vu.os.vm.os.descriptors.subtypes.CurrentResourceElement;
import vu.os.vm.os.descriptors.subtypes.CPUState;

import vu.os.vm.util.PriorityQuene;

import vu.os.vm.os.processes.ProcessBase;

import java.util.LinkedList;

public class CoreTask {

    // CoreTask taikymas:
    //  1. Primityvu kvietimas i� proceso
    //  2. Kaip ir nera daugiau.
    
    public Integer primitive = Constant.PRIMITIVENONE; 
    public String[] param = new String[10];

    // for process primitives
    public Integer processId    = null;
    public String processName   = null;
    public CPUState cpuState    = null;
    public LinkedList<Integer> ramResources  = null;
    public LinkedList<CurrentResourceElement> otherResources = null;
    public Integer priority     = null;
    public ProcessBase systemProcess = null;
    // for resource primitives
    public Integer resourceId   = null;
    public String resourceName  = null;
    public Boolean reusable     = null;
    public LinkedList<ResourceElement> elements      = null;
    public PriorityQuene <WaitingProcessElement> waitingProcessList =  null;
    public Integer resourcePart = null;
    public String resourceElement = null;
    public Integer resourceClass = null;
    public boolean finished = false;
    
    public CoreTask() {
    }
    
    public void CREATEPD( String name, CPUState cpuState, LinkedList<Integer> ramResources, LinkedList<CurrentResourceElement> otherResources, int priority, ProcessBase systemProcess ) {
        this.primitive = Constant.CREATEPD;
        this.processName = name;
        this.cpuState = cpuState;
        this.ramResources = ramResources;
        this.otherResources = otherResources;
        this.priority = priority;
        this.systemProcess = systemProcess;
        
        this.finished = true;
    }
    
    public void DESTROYPD( int processId ) {
        this.primitive = Constant.DESTROYPD;
        this.processId = processId;
        
        this.finished = true;
    }
    
    public void STOPP( int processId) {
        this.primitive = Constant.STOPP;
        this.processId = processId;
        
        this.finished = true;
    }
    
    public void ACTIVATEP( int processId) {
        this.primitive = Constant.ACTIVATEP;
        this.processId = processId;
        
        this.finished = true;        
    }
    
    public void CHANGEPP (int processId, int newPriority) {
        this.primitive = Constant.CHANGEPP;
        this.processId = processId;
        this.priority = newPriority;
        
        this.finished = true;
    }
    
    public void CREATERD( String name, boolean reusable, LinkedList <ResourceElement> elements, PriorityQuene <WaitingProcessElement> waitingProcessList, int resourceClass ) {
        this.primitive = Constant.CREATERD;
        this.resourceName = name;
        this.reusable = reusable;
        this.elements = elements;
        this.waitingProcessList = waitingProcessList;
        this.resourceClass = resourceClass;
        
        this.finished = true;
    }
    
    public void DESTROYRD( int resourceId ){
        this.primitive = Constant.DESTROYRD;
        this.resourceId = resourceId;
        
        this.finished = true;
    }
    
    public void REQUESTR( int resourceId, int resourcePart ) {
        this.primitive = Constant.REQUESTR;
        this.resourceId = resourceId;
        this.resourcePart = resourcePart;
    
        this.finished = true;
    }
    
    public void FREER( int resourceId, String resourceElement, int resourcePart ) {
        this.primitive = Constant.FREER;
        this.resourceId = resourceId;
        this.resourceElement = resourceElement;
        this.resourcePart = resourcePart;
        
        this.finished = true;
    } 
    
    public void SHEDULER() {
        this.primitive = Constant.SHEDULER;
        
        this.finished = true;
    } 
}