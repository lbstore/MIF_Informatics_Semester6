package vu.os.vm.os;

public class ResourceId {

    static public Integer UserMemory = null;
    static public Integer InputOutputStream = null;
    static public Integer LoadPackage = null;
    static public Integer FileSystemTask = null;
    static public Integer ExternalTask = null;
    static public Integer CommandLineTask = null;
    static public Integer InputOutputTask = null;
    static public Integer ProgramTask = null;
    static public Integer HddDeviceTask = null;
    static public Integer InputDeviceTask = null;
    static public Integer OutputDeviceTask = null;
    static public Integer InterruptEvent = null;
    static public Integer InterruptTask = null;
    static public Integer WorkFinished = null;
    static public Integer FileSystemTaskFinished = null;
    static public Integer LoadTaskFinished = null;
    static public Integer InputOutputTaskFinished = null;
    static public Integer OutputDeviceTaskFinished = null;
    static public Integer HddDeviceTaskFinished = null;
    static public Integer InputDeviceTaskFinished = null;
    
    static public Integer PlainMessage = null;
}