package vu.os.vm.os;

public class ProcessId {

    static public Integer CurrentProcess = null;

    static public Integer StartStop = null;
    static public Integer HddDevice = null;
    static public Integer FileSystemManager = null;
    static public Integer InputDevice = null;
    static public Integer OutputDevice = null;
    static public Integer InputOutputManager = null;
    static public Integer CommandLine = null;
    static public Integer Loader = null;
    static public Integer Interrupt = null;
    static public Integer MainProcess = null;
    
    static public Integer Idle = null;
}

