package vu.os.vm.os;

import vu.os.vm.core.VirtualCPUCore;
import vu.os.vm.exceptions.MOSException;

import vu.os.vm.os.Constant;
import vu.os.vm.os.CoreTask;
import vu.os.vm.os.CoreAnswer;
import vu.os.vm.os.descriptors.ProcessDescriptor;

import vu.os.vm.os.descriptors.ResourceDescriptor;
import vu.os.vm.os.descriptors.ResourceDescriptorIOStream;
import vu.os.vm.os.descriptors.ResourceDescriptorMessage;
import vu.os.vm.os.descriptors.ResourceDescriptorMemory;

import vu.os.vm.util.PriorityQuene;

import vu.os.vm.ui.GUI;
import vu.os.vm.util.Convert;
import java.util.HashMap;

import vu.os.vm.os.processes.ProcessBase;
import vu.os.vm.os.processes.test.ProcessTestPing;
import vu.os.vm.os.processes.test.ProcessTestPong;

import vu.os.vm.os.processes.ProcessStartStop;

import vu.os.vm.os.descriptors.subtypes.CPUState;

import vu.os.vm.os.descriptors.subtypes.ResourceElement;
import vu.os.vm.os.descriptors.subtypes.WaitingProcessElement;
import vu.os.vm.os.descriptors.subtypes.CurrentResourceElement;
import vu.os.vm.os.descriptors.subtypes.CPUState;

import java.util.Formatter;

import vu.os.vm.util.PriorityQuene;

import java.util.LinkedList;

public class MOSCore {

    private int ioiIRQ = 3;
    
    private VirtualCPUCore cpu = null;
    
    private Integer inputChannelNr = null;
    private Integer outputChannelNr = null;
    private Integer hddChannelNr = null;
 
    private PriorityQuene <Integer>                 readyProcessList =  new PriorityQuene <Integer> (Constant.maxPriority);
    private HashMap <Integer, ProcessDescriptor>    processes =         new HashMap <Integer, ProcessDescriptor>(99);
    private HashMap <Integer, ResourceDescriptor>   resources =         new HashMap <Integer, ResourceDescriptor>(99);

    public MOSCore(VirtualCPUCore virtualCpu) {
        this.cpu = virtualCpu;
        ProcessId.CurrentProcess = 0;
       
        
        CoreTask task = new CoreTask();

        task.CREATEPD("StartStop", new CPUState(cpu), null, null, 9, new ProcessStartStop(cpu));
        CORE(task);
        
        // TEST PROCESSES
        //task.CREATEPD("Ping", new CPUState(cpu), null, null, 6, new ProcessTestPing(cpu));
        //CORE(task);
        //task.CREATEPD("Pong", new CPUState(cpu), null, null, 6, new ProcessTestPong(cpu));
        //CORE(task);
    
        cpu.PTR.set("0201");
        cpu.MODE.set("U");
        //--------------------------------------------------------------------//
        GUI.log("MOSCore initiated");
    }
   
    //------------------------------------------------------------------------//
    // vieninteles os funkcijos kvieciama is cpu
    //-- IOI -----------------------------------------------------------------//
    //------------------------------------------------------------------------//
    public void IOInt() {
        if (ProcessId.Idle != null) {
            GUI.log("OS - IOI interrupt");
            
            //System.out.print("\n------IOI INT\n");
            
            //System.out.println("IOI value: "+"IOI|"+cpu.IOI.toString()+ "process: "+ProcessId.CurrentProcess);
            CoreTask task = new CoreTask();
            task.FREER(ResourceId.InterruptTask, "IOI|"+cpu.IOI.toString()+"|"+processes.get(ProcessId.CurrentProcess).parentProcess, ProcessId.Interrupt);
            CORE(task);
            
            GUI.log("OS - IOI return");    
        }
    }
    //------------------------------------------------------------------------//
    //-- PI ------------------------------------------------------------------//
    //------------------------------------------------------------------------//
    public void PInt() {
        GUI.log("OS - PI interrupt");

        //System.out.print("\nIOI INT\n");
        //STOPP(ProcessId.CurrentProcess);

        CoreTask task = new CoreTask();
        task.FREER(ResourceId.InterruptTask, "PI|"+cpu.PI.toString()+"|"+processes.get(ProcessId.CurrentProcess).parentProcess, 0);
        cpu.PI.set("0000");
        
        CORE(task); 
    }
    //------------------------------------------------------------------------//
    //-- SI ------------------------------------------------------------------//
    //------------------------------------------------------------------------//
    public void SInt() {
        GUI.log("OS - SI interrupt");

        //STOPP(ProcessId.CurrentProcess);

        CoreTask task = new CoreTask();
        task.FREER(ResourceId.InterruptTask, "SI|"+cpu.SI.toString()+"|"+processes.get(ProcessId.CurrentProcess).parentProcess, 0);
        cpu.SI.set("0000");
        
        CORE(task);
    }
    //------------------------------------------------------------------------//
    //-- TI ------------------------------------------------------------------//
    //------------------------------------------------------------------------//
    public void TInt() {
        //GUI.log("OS - TI interrupt");
   
        cpu.TIMER.set(Constant.TimerResetValue);

        cpu.TI.set("0000");

        CoreTask task = new CoreTask();
        task.SHEDULER();
        CORE(task);

        //GUI.log("OS - TI return");
    }
    //------------------------------------------------------------------------//
    //-- CORE -/- BRANDUOLYS -------------------------------------------------//
    //------------------------------------------------------------------------//
    private void CORE( CoreTask coreTask) {
        try {
            boolean runSheduler = false;
            boolean systemProcessRunning = false;
            
            CoreAnswer  answer = null;
            CoreTask    task = coreTask;
            do {
                //if (task.primitive == Constant.FREER) { GUI.waitForResponse(0); }
                switch (task.primitive) {
                    case Constant.CREATEPD:
                        runSheduler = CREATEPD(task.processName, task.cpuState, task.ramResources, task.otherResources, task.priority, task.systemProcess);
                        break;
                    case Constant.DESTROYPD:
                        runSheduler = DESTROYPD(task.processId);
                        break;
                    case Constant.STOPP:
                        runSheduler = STOPP(task.processId);
                        break;
                    case Constant.ACTIVATEP:
                        runSheduler = ACTIVATEP(task.processId);
                        break;
                    case Constant.CHANGEPP:
                        System.out.println("CHANGEPP: not initiated");
                        break;
                    case Constant.CREATERD:
                        runSheduler = CREATERD(task.resourceName, task.reusable, task.elements, task.waitingProcessList, task.resourceClass);
                        break;
                    case Constant.DESTROYRD:
                        runSheduler = DESTROYRD(task.resourceId);
                        break;
                    case Constant.REQUESTR:
                        runSheduler = REQUESTR(task.resourceId, task.resourcePart);
                        break;
                    case Constant.FREER:
                        runSheduler = FREER(task.resourceId, task.resourceElement, task.resourcePart);
                        break;
                    case Constant.SHEDULER:
                        //System.out.println("PRIMITIVE SHEDULER");
                        ProcessId.CurrentProcess = SHEDULER();
                        runSheduler = false;
                        break;
                    default:
                        throw new MOSException("CORE: unknown primitive: "+task.primitive);
                }
                
                if (runSheduler) {
                    //System.out.println("runSheduler");
                    ProcessId.CurrentProcess = SHEDULER();
                    runSheduler = false;
                }
                
                // RUN SYSTEM PROCESS
                if (ProcessId.CurrentProcess != Constant.ProcessNone) {
                    if (processes.get(ProcessId.CurrentProcess).systemProcess != null) {
                        //System.out.println("running systemProcess : pid "+ProcessId.CurrentProcess);
                        systemProcessRunning = true;
                        answer = processes.get(ProcessId.CurrentProcess).resource;
                        task = processes.get(ProcessId.CurrentProcess).systemProcess.run(answer);
                    } else {
                        systemProcessRunning = false;
                        task.SHEDULER();
                    }
                }
                
                //------------------------------------------------------------//
                String text = new String();
                text = "------------------------------ PROCESSES ---------------------------------\n";
                for (int i=1; i<=99; i++) {
                    if (processes.containsKey(i)) {
                        //  %[argument_index$][flags][width][.precision]conversion
                        String state = null;
                        switch (processes.get(i).state) {
                            case Constant.RUNNING: state = "RUNNING"; break;
                            case Constant.READY: state = "READY"; break;
                            case Constant.READYS: state = "READYS"; break;
                            case Constant.BLOCKED: state = "BLOCKED"; break;
                            case Constant.BLOCKEDS: state = "BLOCKEDS"; break;
                        }
                        String listIn = null;
                        if (processes.get(i).listIn == Constant.ReadyProcessList) {
                            listIn = "ReadyProcessList";
                        } else {
                            listIn = "Waiting for: "+ resources.get(processes.get(i).listIn).name;
                        }
                        text += String.format("#id:%-2d Process %-20s p: %1d state: %-8s ram:%-2d res:%-2d listIn: %s\n",i,processes.get(i).name,processes.get(i).priority,state,processes.get(i).ramResources.size(),processes.get(i).currentResources.size(),listIn);;
                    }
                }
                text += "------------------------------ RESOURCES ---------------------------------\n";
                for (int i=1; i<=99; i++) {
                    if (resources.containsKey(i)) {
                        text += String.format("#id: %-2d Resource %-25s waiting: %-2d | %-3d elements",i,resources.get(i).name,resources.get(i).waitingProcessList.size(),resources.get(i).elements.size());
                        if (i != ResourceId.UserMemory) {
                            text += ": ";
                            for (int j=0; j<resources.get(i).elements.size(); j++) {
                                text += String.format("|prt: %-2d elm: \"%s\"",resources.get(i).elements.get(j).resourcePart, resources.get(i).elements.get(j).resourceElement);
                            }
                        }
                        text += "\n";
                    }
                }
                text += "------------------------- READY PROCESS LIST -----------------------------\n";
                for (int i=0; i<=Constant.maxPriority; i++) {
                    for (int j=0; j<readyProcessList.size(i); j++) {
                        text += processes.get(readyProcessList.peekElement(i,j)).name + " ";      
                    }
                }
                text += "\n";
                text += "-------------------------- CURRENT PROCESS -------------------------------\n";
                if (ProcessId.CurrentProcess != Constant.ProcessNone) text += processes.get(ProcessId.CurrentProcess).name;
                GUI.writeText(text);
                //------------------------------------------------------------//
                if (GUI.userInterrupt) { GUI.waitForResponse(0); }
            } while (systemProcessRunning);
        } catch (MOSException e) {
            GUI.log("MOS CORE ERROR: " + e);
            e.printStackTrace();
        }
    }
    
    //------------------------------------------------------------------------//
    //-- SHEDULER ------------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    private Integer SHEDULER() {
        /*
            da fun is here too
        */
        Integer chosenProcess = null;
        
        int priority = Constant.maxPriority;
        boolean found = false;
        
        //if (ProcessId.CurrentProcess == ProcessId.Idle) System.out.println("SHEDULER: currentProcess: Idle rpl contains it?"+readyProcessList.contains(13));
        
        if (ProcessId.CurrentProcess != Constant.ProcessNone) {
            if (readyProcessList.contains(ProcessId.CurrentProcess)) {
                readyProcessList.remove(ProcessId.CurrentProcess);
                readyProcessList.include(processes.get(ProcessId.CurrentProcess).priority, ProcessId.CurrentProcess);

                //if (ProcessId.CurrentProcess == ProcessId.Idle) System.out.println("SHEDULER: currentProcess: Idle ???????????");
                
                if (processes.get(ProcessId.CurrentProcess).state == Constant.RUNNING) {
                    processes.get(ProcessId.CurrentProcess).state = Constant.READY;
                }
            }
        }
        
        while (!found && priority >= 0) {
            //System.out.println("SHEDULER: priority "+priority+" process count: "+readyProcessList.size(priority));
            for(int i=readyProcessList.size(priority)-1; i >=0 ; i--) {
                if (processes.get( readyProcessList.peekElement(priority, i) ).state == Constant.READY) {
                    chosenProcess = readyProcessList.peekElement(priority, i);
                    found = true;
                }
            }
            priority --;
        }
        
        if (chosenProcess == null) {
            throw new MOSException("SHEDULER: READY process not found");
        }
       
        if (ProcessId.CurrentProcess != Constant.ProcessNone) {
            if (readyProcessList.contains(ProcessId.CurrentProcess)) {
                processes.get(ProcessId.CurrentProcess).state = Constant.READY;
            }
        }
        
        processes.get(chosenProcess).state = Constant.RUNNING;
        
        
        // SWITCH
        if (ProcessId.CurrentProcess != Constant.ProcessNone) {
            if (processes.get(ProcessId.CurrentProcess).systemProcess == null) {    // IF NOT SYSTEM PROCESS (IF VM) reikia sito?
                processes.get(ProcessId.CurrentProcess).cpu.saveCPUState(cpu);
            }
        }
        if (processes.get(chosenProcess).systemProcess == null) {               // IF NOT SYSTEM PROCESS (IF VM) reikia sito?
            //System.out.println("@ SHEDULER: loading cpu staate for process: "+processes.get(chosenProcess).name);
            processes.get(chosenProcess).cpu.loadCPUState(cpu);
        }

        
        return chosenProcess;
    }
    
    //------------------------------------------------------------------------//
    //-- CREATEPD ------------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    private int GetNewProcessId() {
        boolean found = false;
        int newProcessId = 1;
        while(!found && newProcessId <= 99) {
            if (processes.containsKey(newProcessId) == false) {
                found = true;
            } else {
                newProcessId ++;
            }
        }
        
        if (!found) {
            throw new MOSException("GetNewProcessId: no process id available");
        }
        
        return newProcessId;
    }
    //------------------------------------------------------------------------//
    private boolean CREATEPD( String name, CPUState cpuState, LinkedList<Integer> ramResources, LinkedList<CurrentResourceElement> otherResources, int priority, ProcessBase systemProcess) {
        int processId = GetNewProcessId();
        
        ProcessDescriptor process = new ProcessDescriptor();
        
        //--------------------------------------------------------------------//
        if (name == null) { throw new MOSException("CREATEPD: illeagal null parameter"); } 
        process.name = name;
        
        if (cpuState == null) { throw new MOSException("CREATEPD: illeagal null parameter"); } 
        process.cpu = cpuState;
        
        if (ramResources == null) { ramResources = new LinkedList<Integer>(); } 
        process.ramResources = ramResources;
        
        if (otherResources == null) { otherResources = new LinkedList<CurrentResourceElement>(); } 
        process.currentResources = otherResources;
        
        process.createdResources = new LinkedList<Integer>();
        process.priority = priority;
        
        if (ProcessId.CurrentProcess == Constant.ProcessNone) {
            process.state = Constant.READY;
        } else {
            process.state = Constant.READYS;
        }

        process.listIn = Constant.ReadyProcessList;
        process.parentProcess = ProcessId.CurrentProcess;
        process.childProcesses = new LinkedList<Integer>();
        process.systemProcess = systemProcess;
        process.resource = new CoreAnswer();
        //--------------------------------------------------------------------//
        processes.put(processId, process);
        
        if (ProcessId.CurrentProcess != Constant.ProcessNone) {
            processes.get(ProcessId.CurrentProcess).childProcesses.add(processId);
            
            CoreAnswer answer = new CoreAnswer();
            answer.createdProcessId = processId;
            processes.get(ProcessId.CurrentProcess).resource = answer;
        }
        
        readyProcessList.include(priority, processId);
        
        return false;
    }
    //------------------------------------------------------------------------//
    //-- DESTROYPD -----------------------------------------------------------//
    //------------------------------------------------------------------------//
    // not tested
    private boolean DESTROYPD( int processId ) {
        if (processId == ProcessId.CurrentProcess) { throw new MOSException("DESTROYPD: process can not destroy itself"); }
        if (processes.get(processId).parentProcess != ProcessId.CurrentProcess) { throw new MOSException("DESTROYPD: process can only be destroyed by his creator. Destoryer:"+ProcessId.CurrentProcess+" process: "+processId); }

        // DO NOT WAIT FOR RESOURCES
        
        ProcessDescriptor process = processes.get(processId);
        if (process.listIn == Constant.ReadyProcessList) {
            readyProcessList.remove(processId);
        } else {
            boolean found = false;
            int priority = Constant.maxPriority;
            
            while (!found && priority >=0) {
                for (int i=0; i<resources.get(process.listIn).waitingProcessList.size(priority) && !found;i++) {
                    if (resources.get(process.listIn).waitingProcessList.peekElement(priority,i).processId == processId) {
                        resources.get(process.listIn).waitingProcessList.removeElement(priority,i);
                        found = true;
                    }
                }
                priority --;
            }
        }
        
        int realCurrentProcess = ProcessId.CurrentProcess;
        // DESTROY CHILDREN
        for (int i=process.childProcesses.size()-1; i>=0;i--) {
            ProcessId.CurrentProcess = processId;
            DESTROYPD(process.childProcesses.get(i));
        }
        ProcessId.CurrentProcess = realCurrentProcess;
        
        // FREE USER MEMORY
        for (int i=process.ramResources.size()-1; i>=0;i--) {
            ResourceElement element = new ResourceElement();
            
            element.creatorId = ProcessId.CurrentProcess;
            element.resourcePart = process.ramResources.remove(i);
            element.resourceElement = "";
    
            resources.get(ResourceId.UserMemory).elements.add(element);
        }
        // FREE OTHER RESOURCES
        for (int i=process.currentResources.size()-1; i>=0;i--) {
            int resourceId = process.currentResources.get(i).resourceId;
            
            if (resources.get(resourceId).reusable) {
                ResourceElement element = new ResourceElement();
                
                element.creatorId = process.currentResources.get(i).creatorId;
                element.resourcePart = process.currentResources.get(i).resourcePart;
                element.resourceElement = process.currentResources.get(i).resourceElement;
        
                resources.get(resourceId).elements.add(element);
                
                process.currentResources.remove(i);
            }
        }
        
        // DESTROY CREATED RESOURCES
        for (int i=process.createdResources.size()-1; i>=0;i--) {
            DESTROYRD(process.createdResources.get(i));
        }
        
        processes.remove(processId);
        
        processes.get(ProcessId.CurrentProcess).childProcesses.removeFirstOccurrence(processId);
        
        return false;
    }
    //------------------------------------------------------------------------//
    //-- ACTIVATEP -----------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    private boolean ACTIVATEP( int processId ) {
        //System.out.println("@ ACTIVATEP: activating process id: "+processId+" name: "+processes.get(processId).name); 
        boolean runSheduler = false;
        if (processes.get(processId).state == Constant.READYS) {
            processes.get(processId).state = Constant.READY;
            runSheduler = true;
        } else {
            processes.get(processId).state = Constant.BLOCKED;
        }
        return runSheduler;
    }
    //------------------------------------------------------------------------//
    //-- STOPP ---------------------------------------------------------------//
    //------------------------------------------------------------------------//
    // not tested
    private boolean STOPP( int processId ) {
        //System.out.println("STOPP: stopping process id: "+processId+" name: "+processes.get(processId).name); 
        //if (processId == ProcessId.CurrentProcess) { throw new MOSException("STOPP: process "+processId+" can not stop itself"); }
        
        int processOldState = processes.get(processId).state;
        
        if (processOldState == Constant.BLOCKED || processOldState == Constant.BLOCKEDS) {
            processes.get(processId).state = Constant.BLOCKEDS;
        } else {
            processes.get(processId).state = Constant.READYS;
        }
        
        CoreAnswer answer = new CoreAnswer();
        answer.stoppedProcessDescriptor = processes.get(processId);
        processes.get(ProcessId.CurrentProcess).resource = answer;
        
        return false;
    }
    //------------------------------------------------------------------------//
    //-- CREATERD ------------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    private int GetNewResourceId() {
        boolean found = false;
        int newResourceId = 1;
        while(!found && newResourceId <= 99) {
            if (resources.containsKey(newResourceId) == false) {
                found = true;
            } else {
                newResourceId ++;
            }
        }
        
        if (!found) {
            throw new MOSException("GetNewProcessId: no resource id available");
        }
        
        return newResourceId;
    }
    //------------------------------------------------------------------------//
    private boolean  CREATERD( String name, boolean reusable, LinkedList <ResourceElement> elements, PriorityQuene <WaitingProcessElement> waitingProcessList, int resourceClass ) {
        int newResourceId = GetNewResourceId();
        
        ResourceDescriptor resource = null;
        
        switch (resourceClass) {
            case Constant.ResourceIOStream:
                resource = new ResourceDescriptorIOStream();
                break;
            case Constant.ResourceMemory:
                resource = new ResourceDescriptorMemory();
                break;
            case Constant.ResourceMessage:
                resource = new ResourceDescriptorMessage();
                break;
            default:
                throw new MOSException("CREATERD: illeagal resourceClass");
        } 
        //--------------------------------------------------------------------//
        if (name == null) { throw new MOSException("CREATERD: illeagal null parameter"); } 
        resource.name = name;
        
        resource.reusable = reusable;
        resource.creator = ProcessId.CurrentProcess;
        
        if (elements == null) { elements = new LinkedList <ResourceElement>(); } 
        resource.elements = elements;
        
        if (waitingProcessList == null) { waitingProcessList = new PriorityQuene <WaitingProcessElement>(Constant.maxPriority); }
        resource.waitingProcessList = waitingProcessList;
        //--------------------------------------------------------------------//
        resources.put(newResourceId, resource);
        
        if (ProcessId.CurrentProcess != Constant.ProcessNone) {
            CoreAnswer answer = new CoreAnswer();
            answer.createdResourceId = newResourceId;
            processes.get(ProcessId.CurrentProcess).resource = answer;
        }
        processes.get(ProcessId.CurrentProcess).createdResources.add(newResourceId);
        
        //System.out.println("CREATERD finished resource " + resources.get(newResourceId).name+ "rid: "+newResourceId+ " FileSystemTask: id "+ResourceId.FileSystemTask);
        return false;
    }
    //------------------------------------------------------------------------//
    //-- REQUESTR ------------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    public boolean REQUESTR( int resourceId, int resourcePart ) {
    /*
    
        if (resourceId == ResourceId.FileSystemTask) {
            System.out.println("~~~~~~~~~~~~REQUESTR: FileSystemTask requested by "+processes.get(ProcessId.CurrentProcess).name);
        }
    
    */
        WaitingProcessElement element = new WaitingProcessElement();
        
        element.processId = ProcessId.CurrentProcess;
        element.resourcePart = resourcePart;
        
        int processPriority = processes.get(ProcessId.CurrentProcess).priority;
        
        try {
            resources.get(resourceId).waitingProcessList.include(processPriority, element);
        } catch (NullPointerException e) {
            throw new MOSException("REQUESTR: request for non-existent resource");
        }
        
        int[] servedProcesses = resources.get(resourceId).DISTRIBUTOR(resourceId, processes);
        boolean currentProcessIsInServedProcesses = false;
        
        ProcessDescriptor process = null;
        for(int i=0; i<servedProcesses.length; i++) {
            if (servedProcesses[i] != ProcessId.CurrentProcess) {
                process = processes.get(servedProcesses[i]);
                
                readyProcessList.include(process.priority, servedProcesses[i]);
                process.listIn = Constant.ReadyProcessList;
                
                if (process.state == Constant.BLOCKED) {
                    process.state = Constant.READY;
                } else {
                    process.state = Constant.READYS;
                }
            } else {
                currentProcessIsInServedProcesses = true;
            }
        }
    
        //if (ProcessId.CurrentProcess == 13) System.out.println("@@@ REQUESTR: idle wants: part "+resourcePart);
        
        if (!currentProcessIsInServedProcesses) {
            processes.get(ProcessId.CurrentProcess).state = Constant.BLOCKED;
            processes.get(ProcessId.CurrentProcess).listIn = resourceId;
            readyProcessList.remove(ProcessId.CurrentProcess);
            
            
            /*
            System.out.println("REQUESTR: pid "+ProcessId.CurrentProcess+" state:" +processes.get(ProcessId.CurrentProcess).state);
            System.out.println("REQUESTR: readyProcessList: "+readyProcessList.size(7));
            //*/
        }
        return true;
    }
    //------------------------------------------------------------------------//
    //-- FREER ---------------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    public boolean FREER( int resourceId, String resourceElement, int resourcePart ) {
        //if (resourceId == ResourceId.FileSystemTask) System.out.println("\n@ ~~~~~~ ~~~~ FREER: resource FileSystemTask is requested: "+processes.get(ProcessId.CurrentProcess).name);
        // reikia kaskur tikrinti ar neatlaisvina jau esancio elemento
        
        //--------------------------------------------------------------------//
        if (resources.get(resourceId).reusable) {
            // CIA biski blogai, nes kodas priklauso nuo MOS konfiguracijos. reiktu tikrint ar resursas yra Memory klases
            if (resourceId == ResourceId.UserMemory) {
                // ATLAISVINAMO PUSLAPIO NETURI BUTI LAISVO
                for (int i=0; i<resources.get(resourceId).elements.size(); i++) {
                    if (resources.get(resourceId).elements.get(i).resourcePart == resourcePart) {
                        throw new MOSException("FREER: resource part (page) allready exists in UserMemory resource. Page: "+resourcePart);
                    }
                }
                // JEI NE RESURSO KUREJAS TAI TURI TURETI ATLAISVINAMA PUSLAPI
                if (resources.get(resourceId).creator != ProcessId.CurrentProcess) {
                    if (!processes.get(ProcessId.CurrentProcess).ramResources.contains(resourcePart)) { 
                        throw new MOSException("FREER: not-creator process of ram resource must have resourcePart whitch is being freed. Process: "+ processes.get(ProcessId.CurrentProcess).name); 
                    }
                    // PASALINAMAS TURIMAS PUSLAPIS
                    while (processes.get(ProcessId.CurrentProcess).ramResources.contains(resourcePart)) {
                        processes.get(ProcessId.CurrentProcess).ramResources.removeFirstOccurrence(resourcePart);
                    }
                } 
            // JEI KITI RESURSAI
            } else {
                // JEI NE RESURSO KUREJAS TAI TURI TURETI ATLAISVINAMA DALI (resourcePart)
                if (resources.get(resourceId).creator != ProcessId.CurrentProcess) {
                    // pasalinamas turimas elementas
                    boolean found = false;
                    
                    for (int i=0; i<processes.get(ProcessId.CurrentProcess).currentResources.size() && !found; i++) {
                        
                        if (processes.get(ProcessId.CurrentProcess).currentResources.get(i).resourceId == resourceId) {
                            //System.out.println("\n@FREER: resourcePart = "+resourcePart);
                            if (processes.get(ProcessId.CurrentProcess).currentResources.get(i).resourcePart == resourcePart) {
                                
                                
                                
                                processes.get(ProcessId.CurrentProcess).currentResources.remove(i);
                                found  = true;
                            }
                        }
                    }
                    if (!found) { throw new MOSException("FREER: non-creator process of resource ("+resources.get(resourceId).name+") must have resource part being freed. Process: "+ processes.get(ProcessId.CurrentProcess).name); }
                }  
            }
        }
        //--------------------------------------------------------------------//
        ResourceElement element = new ResourceElement();
        
        element.creatorId = ProcessId.CurrentProcess;
        element.resourcePart = resourcePart;
        if (resourceElement == null) { throw new MOSException("FREER: resourceElement can not be null. Resource: "+resources.get(resourceId).name); }
        element.resourceElement = resourceElement;
        
        
        
        if (!resources.get(resourceId).elements.add(element)) throw new MOSException("FREER: failed to insert element");
        //System.out.println("\n@ FREER: resource: " +resources.get(resourceId).name+": element cound:"+resources.get(resourceId).elements.size());
        
        /*
        if (resourceId == ResourceId.FileSystemTask) {
            System.out.println("~~~~~~~~~~~~FREER: resource "+resources.get(resourceId).name+" SENDER: "+ProcessId.CurrentProcess+" elements");
            for (int i=0;i<resources.get(resourceId).elements.size();i++) {
                System.out.print(" "+resources.get(resourceId).elements.get(i).resourcePart+" "+resources.get(resourceId).elements.get(i).resourceElement);
            }
            System.out.println("");
        }
        */
        int[] servedProcesses = resources.get(resourceId).DISTRIBUTOR(resourceId, processes);
        
        //System.out.println("FREER: servedProcesses: "+servedProcesses.length);
    
        ProcessDescriptor process = null;
        for(int i=0; i<servedProcesses.length; i++) {
            process = processes.get(servedProcesses[i]);
            
            readyProcessList.include(process.priority, servedProcesses[i]);
            process.listIn = Constant.ReadyProcessList;
            
            if (process.state == Constant.BLOCKEDS) {
                process.state = Constant.READYS;
            } else {
                process.state = Constant.READY;
            }
        }
        
        if (servedProcesses.length > 0) {
            return true;
        } else {
            return false;
        }
    } 
    //------------------------------------------------------------------------//
    //-- DESTROYRD -----------------------------------------------------------//
    //------------------------------------------------------------------------//
    // tested
    public boolean DESTROYRD( int resourceId ) {
        //System.out.println("DESTROYRD: start");
        if (!resources.containsKey(resourceId)) { throw new MOSException("DESTROYRD: non-existent resource " + resourceId); }
        if (resources.get(resourceId).creator != ProcessId.CurrentProcess) { throw new MOSException("DESTROYRD: only creator process can destroy resource descriptor"); }
        
        int priority = Constant.maxPriority;
        WaitingProcessElement waitingProcess;
        ProcessDescriptor process;
        
        while (priority >= 0) {
            //System.out.println("DESTROYRD: priority:"+priority+" elements Size:"+resources.get(resourceId).elements.size());
            while (resources.get(resourceId).waitingProcessList.size(priority) > 0) {
            
                waitingProcess = resources.get(resourceId).waitingProcessList.pollFirst(priority);
                process = processes.get(waitingProcess.processId);
                
                //System.out.println("DESTROYRD: waitingProcess:"+waitingProcess.processId);
                
                if (process.state == Constant.BLOCKED) {
                    process.state = Constant.READY;
                } else {
                    process.state = Constant.READYS;
                }
                
                process.listIn = Constant.ReadyProcessList;
                process.resource = new CoreAnswer();
                
                readyProcessList.include(process.priority, waitingProcess.processId);
            }
            priority--;
        }
        processes.get(resources.get(resourceId).creator).createdResources.removeFirstOccurrence(resourceId);
        
        resources.remove(resourceId);
        
        return true;
    }   
}