package vu.os.vm;

import vu.os.vm.util.HDDFormatter;
import vu.os.vm.util.Compiler;

import java.util.Scanner;

public class FormatVirtualHDD {  
    
    public static void main(String[] args) {
        try {
            String destination = "data/HDD.txt";
            String str = null;
            System.out.println("Press ENTER to format \""+destination+"\" with file system.\nWrite \"B\" to format it to the BOOT device.");
            
            Scanner scan = new Scanner(System.in);
            
            str = scan.nextLine();
            
            if (str.equalsIgnoreCase("b")) {
                String runProgram = "data/Programa.pasm";
                
                System.out.println("To format \""+destination+"\" to the BOOT device using \""+runProgram+"\" press ENTER.\nOr write other source *.pasm file.");
                str = scan.nextLine();
                if (!str.isEmpty()) {
                   runProgram = str;
                }
                
                Compiler comp = new Compiler();
                System.out.println("Compiling BOOT device..");
                comp.compileBootFile(runProgram, destination);
            } else {
                HDDFormatter formatter = new HDDFormatter();
                
                System.out.println("Adding files..");
                
                formatter.addHDDFile("data/Programa.pasm" , "PR01" , "PRG");
                formatter.addHDDFile("data/Sudetis_Su_Perpildymu_SUPER_MODE_2010-03-21.pasm" , "SUMS" , "PRG");
                formatter.addHDDFile("data/Sudetis_Su_Perpildymu_USER_MODE_2010-03-22.pasm" , "SUMU" , "PRG");
                formatter.addHDDFile("data/MindesPong.pasm" , "MINP" , "PRG");
                formatter.addHDDFile("data/TautvioPing.pasm" , "PING" , "PRG");
                formatter.addHDDFile("data/TautvioPong.pasm" , "PONG" , "PRG");
                formatter.addHDDFile("data/FoninePrograma.pasm" , "FONP" , "PRG");
                
                formatter.addHDDBootFile("data/HDDBootIMG.txt" , "BOOT" , "IMG");

                System.out.println("Formatting..");
                
                formatter.formatHDD(destination, 1000);
            }
            
            System.out.println("Finished!.. \"" + destination+"\"");
            
            (new Scanner(System.in)).nextLine();
        } catch (Throwable t) {
            System.out.println("HDD FORMAT ERROR:");
            t.printStackTrace();
            while(true);
        }
    }
}