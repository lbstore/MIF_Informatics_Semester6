//2010-03-19 2194 eilutes.
//2010-05-25 7516 eilutes.
//OS: 3535 eilutes. 
// versijavimas : 407 versija (build 407)
package vu.os.vm;

/*
    Parametrai virtualiai masinai:
    
    * (programos failas) (mode)
    
    Pvz:
    
    * -"data/Programa.asm" -"S"
    (nustatoma programa ir paleidimo rezimas)
    * -"data/Programa.asm"
    (nustatoma programa, paleidimo rezimas - S)
    * parametru nera
    (programa - data/Programa.asm, rezimas - S) (kaip visada)a
*/

// testavimui 

/*
import vu.os.vm.*;
import vu.os.vm.core.*;
import vu.os.vm.core.io.*;
import vu.os.vm.util.*;
import vu.os.vm.exceptions.*;
*/

// testavimui ^

import vu.os.vm.core.VirtualMachine;

import java.util.Scanner;

public class VMmain {      
    public static void main(String[] args) {
        try {
            VirtualMachine vm = new VirtualMachine();
            
            
            if (args.length == 2) {
                vm.setSource(args[0], args[1]);
            } else if (args.length == 1) {
                vm.setSource(args[0], "S");
            } else {
                vm.setSource("data/Programa.pasm", "S");
            }
            
            vm.build();

            System.out.println("VM: End of VM. Please exit.");
            while(true);
            //(new Scanner(System.in)).nextLine();
        } catch (Throwable t) {
            System.out.println("ERROR:");
            t.printStackTrace();
            while(true);
        }
    }
}