package vu.os.vm.ui;

import vu.os.vm.core.VirtualRAM;
import vu.os.vm.util.Convert;
import vu.os.vm.core.Register;
import vu.os.vm.ui.RegistersPanel;
import vu.os.vm.ui.RAMPanel;
import vu.os.vm.ui.ControlPanel;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import javax.swing.JPanel;
import javax.swing.JTextArea;


import java.awt.GridBagLayout;

import java.awt.Font;

import java.awt.GridBagConstraints;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.HashMap;


public class TextGUI extends JFrame {
    
    private JPanel mainPanel = null;
    JTextArea textArea = new JTextArea();
    
    public TextGUI() {
        
        setTitle("TEXT GUI");
        //setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800 , 600);

        // text area
        
        textArea.setRows(30);
        textArea.setFont(new Font("Courier New", Font.PLAIN, 12));
        textArea.setText("TEST\n TEST");
        
        add(textArea);

        //lockBestSize();
        this.setVisible(true);
    }

    
    public void writeText( String text ) {
        textArea.setText(text);
        //textArea.updateUI();
    }
/*
    public void waitForResponse(int oldIc) {
        this.updateUI(oldIc);
        while( paused && stepMode ){ 
            try {
                Thread.currentThread().sleep(10);
            } catch (Exception e) {
            }
            //    System.out.print("");
        }
        setPaused( true );
    }
    */
}