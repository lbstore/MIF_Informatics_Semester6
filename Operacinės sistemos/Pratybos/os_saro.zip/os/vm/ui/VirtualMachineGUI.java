package vu.os.vm.ui;

import vu.os.vm.core.VirtualRAM;
import vu.os.vm.util.Convert;
import vu.os.vm.core.Register;
import vu.os.vm.ui.RegistersPanel;
import vu.os.vm.ui.RAMPanel;
import vu.os.vm.ui.ControlPanel;

import vu.os.vm.core.VirtualCPUCore;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.HashMap;


public class VirtualMachineGUI extends JFrame implements ActionListener {
    
    private HashMap <Integer, Register> regs = null;
    private VirtualRAM ram = null;

    private VirtualCPUCore cpu = null;

    private GridBagConstraints constraints = new GridBagConstraints();

    private RegistersPanel registersPanel = null;
    private RAMPanel ramPanel = null;
    private ControlPanel controlPanel = null;

    boolean paused   = true;
    boolean stepMode = true;
 
    public VirtualMachineGUI(VirtualCPUCore cpu) {
        
        setTitle("VM");
        setLayout(new GridBagLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //setSize(800 , 600);

        this.regs = regs;
        this.ram = ram;

        this.cpu = cpu;

        registersPanel = new RegistersPanel(cpu);
        ramPanel = new RAMPanel(cpu);
        
        controlPanel = new ControlPanel();
        controlPanel.assignListener(this);

        constraints.fill = GridBagConstraints.VERTICAL;
        constraints.gridwidth = GridBagConstraints.REMAINDER;
        
        add(ramPanel, constraints);
        add(registersPanel, constraints);
        add(controlPanel, constraints);

        lockBestSize();
        this.setVisible(true);
    }

    
    public void writeLog( Object line ) {
        if( registersPanel != null ){
            registersPanel.addRowToLogTable(line.toString());
        }
    }
    
    public void actionPerformed(ActionEvent event) {
        if (stepMode) {
            if ((event.getActionCommand().equals("pushed")) && (controlPanel.isEMChecked())) {
                controlPanel.stepButtonName("Testi");
                this.paused = false;
            }
            
            if ((event.getActionCommand().equals("pushed")) && !(controlPanel.isEMChecked())) {
                controlPanel.stepButtonName("STOP");
                this.stepMode = false;
            }
        } else {
            if (event.getActionCommand().equals("pushed")) {
                controlPanel.stepButtonName("Testi");
                this.stepMode = true;
            }
        }
    }

    public boolean isPaused() {
        return this.paused;
    }
    
    public void setPaused( boolean paused ) {
        this.paused = paused;
    }
    
    public void lockBestSize() {
        if (registersPanel != null) {
            pack();
            setResizable(false);
        }
    }

    public void waitForResponse(int oldIc) {
        this.updateUI(oldIc);
        while( paused && stepMode ){ 
            try {
                Thread.currentThread().sleep(10);
            } catch (Exception e) {
            }
            //    System.out.print("");
        }
        setPaused( true );
    }
    
    public void updateUI(int oldIc) {
        //updateLogTable();
        repaint();
        ramPanel.renew(oldIc);
    }
    
    public void updateLogTable() {
        try {
            registersPanel.scrollPane3.getVerticalScrollBar().setValue(registersPanel.scrollPane3.getVerticalScrollBar().getMaximum());
        } catch (NullPointerException e) {
            System.out.println("VirtualMachineGUI: updateLogTable ERROR: "+e);
        }
    }
}