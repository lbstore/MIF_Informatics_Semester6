package vu.os.vm.ui;

import vu.os.vm.core.Register;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.TableColumnModel;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JTable;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.util.HashMap;
import java.util.Vector;

import vu.os.vm.core.VirtualCPUCore;

public class RegistersPanel extends JPanel
{
    private VirtualCPUCore cpu = null;
    
    String[] columnNames = {"Register","Value"};
    Object[][] data = null;
    
    String[] logTableColumnNames = {"LOG"};
    Object[][] logTableData = null;
    
    JTable table1 = null;
    JTable table2 = null;
    JTable logTable = null; 
    
    JScrollPane scrollPane1 = null;
    JScrollPane scrollPane2 = null;
    public JScrollPane scrollPane3 = null;
    
    JTextArea textArea = null;

    FormatRenderer formatRenderer1 = null;
    FormatRenderer formatRenderer2 = null;
    
    TableModel tableModel1 = null;
    TableModel tableModel2 = null;
    TableModel tableModel3 = null;
    
    TableColumnModel tableColumnModel1 = null;
    TableColumnModel tableColumnModel2 = null;
    
    public RegistersPanel( VirtualCPUCore cpu )
    {
        setLayout( new BorderLayout() );
        
        Object[][] data1 = { {"R",cpu.R},
                            {"U",cpu.U},
                            {"C",cpu.C},
                            {"IC",cpu.IC},
                            {"DS",cpu.DS},
                            {"SS",cpu.SS},
                            {"SP",cpu.SP}};
                            
       Object[][] data2 = {{"TIMER",cpu.TIMER},
                            {"MODE",cpu.MODE},
                            {"PTR",cpu.PTR},
                            {"PI",cpu.PI},
                            {"SI",cpu.SI},
                            {"TI",cpu.TI},
                            {"CAST",cpu.CAST},
                            {"IOI",cpu.IOI}};
           
        formatRenderer1 = new FormatRenderer();
        formatRenderer2 = new FormatRenderer();
        
        tableModel1 = new TableModel(data1,columnNames);
        tableModel2 = new TableModel(data2,columnNames);
        
        table1 = new JTable();
        table1.setGridColor( Color.green );
        table1.setModel( tableModel1 );
        
        table2 = new JTable();
        table2.setGridColor( Color.red );
        table2.setModel( tableModel2 );
        
        tableColumnModel1 = table1.getColumnModel();
        tableColumnModel2 = table2.getColumnModel();
        
        tableColumnModel1.getColumn(0).setCellRenderer(formatRenderer1);
        formatRenderer1.setHorizontalAlignment(SwingConstants.RIGHT);
        tableColumnModel1.getColumn(1).setCellRenderer(formatRenderer2);
        formatRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
        
        tableColumnModel2.getColumn(0).setCellRenderer(formatRenderer1);
        formatRenderer1.setHorizontalAlignment(SwingConstants.RIGHT);
        tableColumnModel2.getColumn(1).setCellRenderer(formatRenderer2);
        formatRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
        
        scrollPane1 = new JScrollPane(table1);
        scrollPane1.setPreferredSize(new Dimension(150, 150) );
        table1.setFillsViewportHeight(true);
        
        scrollPane2 = new JScrollPane(table2);
        scrollPane2.setPreferredSize(new Dimension(150, 150) );
        table2.setFillsViewportHeight(true);
        
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(new java.awt.Color(240, 240, 240));
        textArea.setFont( new Font("Courier New", Font.PLAIN, 12) );
        textArea.setText("* VM registrai - zalia lentele\n"+
                         "* RM registrai - zalia ir raudona lenteles");
        
        // ---- LOG TABLE ---- //
        logTable = new JTable();
        tableModel3 = new TableModel( logTableData, logTableColumnNames );
        logTable.setModel(tableModel3);
        
        scrollPane3 = new JScrollPane(logTable);
        scrollPane3.setPreferredSize( new Dimension(300,150) );
        // ------------------- //
        
        add( scrollPane1 , BorderLayout.WEST   );
        add( scrollPane2 , BorderLayout.CENTER );
        add( scrollPane3 , BorderLayout.EAST );
        add( textArea    , BorderLayout.SOUTH );
    }
    
    public void addRowToLogTable( String string )
    {
        Vector<String> logRows = new Vector<String>();
        logRows.addElement(string);
        
        tableModel3.addRow(logRows);
        
        //scrollPane3.getVerticalScrollBar().setValue(scrollPane3.getVerticalScrollBar().getMaximum());
    }

}

class TableModel extends DefaultTableModel {  
    public TableModel() {  
        super();  
    }  
    
    public TableModel(Object[][] data, Object[] columnNames)
    {
        super(data,columnNames);
    }
    
    public boolean isCellEditable(int row, int col) {  
        return false;  
    }  
}  

class FormatRenderer extends DefaultTableCellRenderer {
}
