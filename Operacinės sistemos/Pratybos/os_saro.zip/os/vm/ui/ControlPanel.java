package vu.os.vm.ui;

import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.GroupLayout;

public class ControlPanel extends JPanel {   
    
    JButton stepButton = new JButton("START");
    JCheckBox executeModeCB = new JCheckBox();
    
    public ControlPanel() {
        
        
        GroupLayout layout;
        
        executeModeCB.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        executeModeCB.setSelected(true);
        executeModeCB.setText("Pazingsninis rezimas");
        executeModeCB.setBorder(null);
        
        stepButton.setFont(new java.awt.Font("Courier New", 0, 12)); 
        stepButton.setActionCommand("pushed");
        
        layout = new GroupLayout(this);
        this.setLayout(layout);
        
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(executeModeCB, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addComponent(stepButton, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(99, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(stepButton, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
                    .addComponent(executeModeCB))
                .addContainerGap())
        );
        
    }
    
    

    public void assignListener( ActionListener actionListener )
    {
        stepButton.addActionListener(actionListener);
    }
    
    public boolean isEMChecked() {
        return executeModeCB.isSelected();
    }
    
    public void stepButtonName(String name) {
        stepButton.setText(name);
    }
}
