package vu.os.vm.ui;

import vu.os.vm.core.Register;
import vu.os.vm.core.VirtualRAM;
import vu.os.vm.core.VirtualCPUCore;

import vu.os.vm.ui.VirtualMachineGUI;
import vu.os.vm.ui.TextGUI;
import vu.os.vm.ui.RamGUI;

import java.util.HashMap;

public class GUI {
    
    static private VirtualMachineGUI vmGui;
    static private RamGUI ramGui;
    static private TextGUI textGui;
    
    static private boolean guiReady = false;
    
    static public boolean userInterrupt = false;

    static private int lasOldIc = 0;
    
    static public void initiateGUI(VirtualCPUCore cpu) {
        textGui = new TextGUI(); 
        vmGui = new VirtualMachineGUI(cpu);
        //ramGui = new RamGUI(cpu);
        
        vmGui.setLocation(850,50);
        //ramGui.setLocation(850,50);
        textGui.setLocation(20,400);
        guiReady = true;
    }
    
    static public void log( Object line ) {
        if (guiReady) {
            try {
                vmGui.writeLog(line);
                vmGui.updateUI(lasOldIc);
            } catch (Throwable e) {
                System.out.println("GUI ERROR: "+e);
            }
        }
    }

    static public void waitForResponse(int oldIc) {
        if (guiReady) {
            try {
                vmGui.waitForResponse(oldIc);
                lasOldIc = oldIc;
            } catch (Throwable e) {
                System.out.println("GUI ERROR: "+e);
            }
        }
    }

    static public void waitForResponse() {
        if (guiReady) {
            try {
                vmGui.waitForResponse(lasOldIc);
            } catch (Throwable e) {
                System.out.println("GUI ERROR: "+e);
            }
        }
    }
    
    static public void updateGUI(int oldIc) {
        if (guiReady) {
            try {
                vmGui.updateUI(oldIc);
            } catch (Throwable e) {
                System.out.println("GUI ERROR: "+e);
            }
        }
    }
    
    static public void writeText(String text) {
        if (guiReady) {
            try {
                textGui.writeText(text);
            } catch (Throwable e) {
                System.out.println("GUI ERROR: "+e);
            }
        }
    }
}