package descriptoriai;

import planuojuSkirstau.Planuotojas;
import planuojuSkirstau.ResursuPaskirstytojas;
import primityvai.ResursuPrimityvai;
import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;

public class ProcesuDeskriptorius{
	public Planuotojas Planuoja;
	public ResursuSarasas Resursai;
	public ProcesuSarasas Procesai;
	public VisuLaukianciuSarasas LaukiantysResurso;
	public ResursuPrimityvai Rveiksmai;
	
	public int PFinish;
	public String PId; // vardas
	public String PState; // nusako jo busena
	public String PGod; // tevas
	public int PPriority; // prioritetas
	public ResursuSarasas ManoSukurtiResursai = new ResursuSarasas(); // sukurti resursai
	public ResursuSarasas GautiResursai = new ResursuSarasas(); // gauti resursai
	public ProcesuSarasas SukurtiProcesai =  new ProcesuSarasas(); //sukurti procesai
	 

	public ProcesuDeskriptorius(String vardas, int prioritetas, String tevas, ProcesuSarasas procesai, Planuotojas planuoja, ResursuSarasas resursai, VisuLaukianciuSarasas laukiantys, ResursuPrimityvai rveiksmai ){
		Planuoja=planuoja;
		Resursai=resursai;
		Procesai=procesai;
		Rveiksmai=rveiksmai;
		LaukiantysResurso=laukiantys;
		
		this.PFinish=0;
		this.PState="Pasiruoses"; // ustatoma pradine busena
		setName(vardas); // nustatomas vardas
		setPriority(prioritetas);	 // nustatomas prioritetas
		setFather(tevas); // nustatomas tevas
		setTevoSunuSarasa(); // pridedamas prie tevo sukurtu procesu saraso
		procesai.setElementas(this); // prodedamas prie bendro saraso
	}
			
	public ProcesuDeskriptorius() {
	}

	public void setTevoSunuSarasa(){
		for(int i=0;i<=Procesai.getDydis()-1;i++){
			if(PGod.equals(Procesai.getNumeris(i).PId)){
				Procesai.getNumeris(i).SukurtiProcesai.setElementas1(this);
			}
		}
	}
		
	public void setPasiruoses(){ // ateme is jo procesoriu
 		this.PState="Pasiruoses";
	}
	public void setVykdomas(){ // kai gauna procesoriu
		this.PState="Vykdomas";
	}
	
	public void setBlokuotas(){ // kai prase resurso  bet negavo
		this.PState="Blokuotas";
	
	}
	
	public void ImkResursa(){ // kai jam suteikiamas prasytas resursas
		if( PState=="Blokuotas Sustabdytas"){
			this.PState="Pasiruoses Sustabdytas";	
		} else{
			this.PState="Pasiruoses";
		}		
	}
	
	public void stabdyti(){ //  kai einamasis procesas sustabdo
		if (PState=="Pasiruoses"){
			this.PState="Pasiruoses Sustabdytas";
		}else {
			this.PState="Blokuotas Sustabdytas";
		}
	}
	
	public void aktyvuoti(){ // kai einamasis procesas aktyvuoja 
		if (PState=="Pasiruoses Sustabdytas"){
			this.PState="Pasiruoses";
		}else {
			this.PState="Blokuotas";
		}
	}
	
	public void setName(String vardas){
		this.PId=vardas;	
	}
	
	public void setFather(String fatherId){
		this.PGod=fatherId;
	}
	
	public void setPriority(int num){
		this.PPriority=num;
	}
	
		
}
