package descriptoriai;

import sarasiukai.*;


public class ResursuDeskriptorius {

	public ResursuSarasas Resursai;
	public ProcesuSarasas Procesai;
	public VisuLaukianciuSarasas LaukiantysResurso;
	
	
	public String RId; // resurso vardas
	public String RGod;// resurso tevas
	public String RRusis; // resurso rusis( statisis/diniminis)
	public String RUzimtumas; // resurso uzimtumas (laisvas/uzimtas)
	
	public ResursuDeskriptorius(String vardas,int rusis,String tevoVardas, int uzimtumas,VisuLaukianciuSarasas laukiantys, ResursuSarasas resursai,ProcesuSarasas procesai){
		Resursai=resursai;
		Procesai=procesai;
		LaukiantysResurso=laukiantys;
		
		setName(vardas);
		setRusis(rusis);
		setUzimtumas(uzimtumas);
		setFather(tevoVardas);
		
		laukianciuSarasas();
		Resursai.setElementas(this);			
		prieTevoSukurtuResursu();
		    
	}
	
	
	public void prieTevoSukurtuResursu(){
		for(int i=0; i<=Procesai.getDydis()-1;i++){
			if(RGod.equals(Procesai.getNumeris(i).PId)){
				
				Procesai.getNumeris(i).ManoSukurtiResursai.setElementas(this);
			}
		}
				
	}

	public void laukianciuSarasas(){
		
		if (tikrintiArYra()){
			System.out.println("jau toks yra:"+ RId);
		} else{
			 LaukianciujuSarasas tavesLaukia= new LaukianciujuSarasas(RId);
			 LaukiantysResurso.setElementas(tavesLaukia);
			
			}
		
	}
	
	public boolean tikrintiArYra(){
		if (RRusis.equals("Dinaminis")){
			for (int i=0;i<=LaukiantysResurso.getDydis()-1;i++){
				if (LaukiantysResurso.getNumeris(i).getName().equals(RId)){
					return true;
				}
			}
		
		}	
		return false;
	}
	
		
	public void setName(String vardas){
		this.RId=vardas;	
	}
		
	public void setFather(String fatherId){
		this.RGod=fatherId;
	}
		
	public void setRusis(int rusis){
		if (rusis==1) {	
		this.RRusis="Statinis";
		}
		else {	
		this.RRusis="Dinaminis";
		}
	}
	
	public void setUzimtumas(int uzimtumas){
		if (uzimtumas==1){
			this.RUzimtumas="Laisvas";
		} else {
			this.RUzimtumas="Uzimtas";
		}
		
	}
	
}
