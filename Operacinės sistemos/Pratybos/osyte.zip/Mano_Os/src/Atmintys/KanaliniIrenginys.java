package Atmintys;

import ivedimoIsvedimoImitavimas.IsvedimoIvedimoIrenginiai;
import ivedimoIsvedimoImitavimas.IvedimasIsvedimas;

public class KanaliniIrenginys {
	public RealiosMasinosAtmintis  rmatmintis;
	public SupervizorineAtmintis spatmintis;
	public IsorineAtmintis isatmintis;
	public  IsvedimoIvedimoIrenginiai  isvedimasIvedimas;
	
	int SO; // is kur kopijuosime
	int DR; // su kuria atmintimi dirbame

	public KanaliniIrenginys(RealiosMasinosAtmintis rmatmintis,
			SupervizorineAtmintis spatmintis, IsorineAtmintis isatmintis,
			 IsvedimoIvedimoIrenginiai isvedimasIvedimas) {
		
		this.rmatmintis=rmatmintis;
		this.spatmintis=spatmintis;
		this.isatmintis=isatmintis;
		this.isvedimasIvedimas=isvedimasIvedimas;
	}

	public void xchg(int so,int nuo, int iki) {
		DR=0;
		switch (so) {
		case (1): { // vartotojo supervizorine

		}
		case (2): {// vartotojo isorine

		}
		case (3): { //vartotojo isvedimo srautas

		}
		case (4): {// supervizorine vartotojo

		}
		case (5): {//supervizorine isvedimo srautas
			this.SO=5;
			String eilute = "";
			String laikina="";
			for(int i=nuo;i<iki;i++){
				for(int j=0;j<10;j++){
					laikina=spatmintis.gautiAtminti().grazintiZodiRM(i, j);
					if (laikina.equals("0000")){
						laikina="";
					}
					eilute=eilute.concat(laikina);
				}
				
			}
			isvedimasIvedimas.rasyti(eilute);
			baigeDirbti();

		}
		case (6): { // isorine vartotojo

		}
		case (7): { // isorine vartotojo
			this.SO=7;
			nuo=nuo+1;
			iki=0;
			int nuoo=rmatmintis.gautiAtminti().prasoAtminties();
			int ikii=nuoo+10;
			for(int i=nuoo;i<ikii;i++){
				for(int j=0;j<10;j++){
					if(i==9){
						rmatmintis.gautiAtminti().idetiZodiRM("0000", i, j) ;
					}else{
						rmatmintis.gautiAtminti().idetiZodiRM(isatmintis.gautiAtminti().grazintiZodiRM(nuo, iki), i, j) ;
						isatmintis.gautiAtminti().idetiZodiRM("0000",nuo, iki);
					}
				iki++;
				}
				iki=0;
				nuo++;
			}
			baigeDirbti();
		}
		case (8): { // isorine supervizorine

		}
		case (9): { // isorine isvedimo srautas

		}
		case (10): { //ivedimo srautas supervizorine

		}
		case (11): { // ivedimo srautas vartotojo

		}
		case (12): { // ivedimo srautas isorine

		}
		case (13): { // ivedimo srautas isvedimo srautas

		}
		}
	}

	public void dirbs(int i) {
		this.DR = i;
		this.SO = 0;

	}

	public void baigeDirbti() {
		this.DR = 0;
		this.SO = 0;
	}

}
