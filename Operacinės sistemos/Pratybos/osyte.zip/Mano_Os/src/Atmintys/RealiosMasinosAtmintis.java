package Atmintys;

public class RealiosMasinosAtmintis        
{ 
    private String[][] atmintisRM;             
    
    public RealiosMasinosAtmintis()
    {
        atmintisRM = new String[100][10];  
        for(int i=0; i<100; i++)
        {
            for(int j=0; j<10; j++)
            { 
            	atmintisRM[i][j] ="0000";
            }
        }
    }
  
    private static RealiosMasinosAtmintis vienetinisEgzempliorius;
    
    public static RealiosMasinosAtmintis gautiAtminti()
    {
        if (null == vienetinisEgzempliorius)
        {
            vienetinisEgzempliorius = new RealiosMasinosAtmintis();
        }
        return vienetinisEgzempliorius;
    }

    public void idetiZodiRM(String zodis, int x1, int x2)
    {
        atmintisRM[x1][x2] = zodis;
    }
    
    public String grazintiZodiRM(int x1, int x2)
    {
        return atmintisRM[x1][x2];
    }

    public int prasoAtminties(){    
    	boolean jau=false;
    	int k=0;
    	while(jau!=true){
    		if(atmintisRM[k][0].equals("0000")){
    			jau=true;
    		} else{ k=k+10;}
    	}
    	
		return k;
    	
    }
}