package Atmintys;

public class IsorineAtmintis     
{ 
    public String[][] atmintisIS;             
    
    public IsorineAtmintis  ()
    {
    	atmintisIS = new String[100][10];  
        for(int i=0; i<100; i++)
        {
            for(int j=0; j<10; j++)
            { 
            	atmintisIS[i][j] = "0000";
            }
        }
    }
  
    private static IsorineAtmintis   vienetinisEgzempliorius;
    
    public static IsorineAtmintis gautiAtminti()
    {
        if (null == vienetinisEgzempliorius)
        {
            vienetinisEgzempliorius = new IsorineAtmintis();
        }
        return vienetinisEgzempliorius;
    }

    public void idetiZodiRM(String zodis, int x1, int x2)
    {
    	atmintisIS[x1][x2] = zodis;
    }
    
    public String grazintiZodiRM(int x1, int x2)
    {
        return atmintisIS[x1][x2];
    }

    public int prasoAtminties(){    
    	boolean jau=false;
    	int k=0;
    	while(jau!=true){
    		if(atmintisIS[k][0].equals("0000")){
    			jau=true;
    		} else{ k=k+10;}
    	}
    	
		return k;
    	
    }
}