package Atmintys;

public class VirtualiosMasinosAtmintis 
{
   public RealiosMasinosAtmintis rmatmintis;
    protected int plr;
    
    public VirtualiosMasinosAtmintis(RealiosMasinosAtmintis rmatmintis, int plr)
    {
    	this.rmatmintis = rmatmintis;
    	this.plr = plr;
    }
    
    public void idetiZodi(String zodis, int x1, int x2)
    {
    	int radr = gautiRealuAdresa(plr, x1, x2);
        int rx1 = radr / 10;
        int rx2 = radr % 10;
    	rmatmintis.gautiAtminti().idetiZodiRM(zodis, rx1, rx2);
    }

    public String grazintiZodi(int x1, int x2)
    {
    	int radr = gautiRealuAdresa(plr, x1, x2);
    	int rx1 = radr / 10;
        int rx2 = radr % 10;
      
        System.out.println(rx1);
        System.out.println(rx2);
    	return rmatmintis.gautiAtminti().grazintiZodiRM(rx1, rx2);
    	
    	    }
    
    public int gautiRealuAdresa(int plr, int x1, int x2)
    {
    	int a1 = plr % 100 / 10;
    	int a2 = plr % 10;
    	int radr = 10* Integer.valueOf(rmatmintis.gautiAtminti().grazintiZodiRM(a1*10+a2, x1))+x2; 
    	return radr;
    }
}