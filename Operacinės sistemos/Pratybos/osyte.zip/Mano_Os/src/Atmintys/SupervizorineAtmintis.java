package Atmintys;

public class SupervizorineAtmintis    
{ 
    private String[][] atmintisS;             
    
    public SupervizorineAtmintis()
    {
    	atmintisS = new String[10][10];  
        for(int i=0; i<10; i++)
        {
            for(int j=0; j<10; j++)
            { 
            	atmintisS[i][j] = "0000";
            }
        }
    }
  
    private static SupervizorineAtmintis    vienetinisEgzempliorius;
    
    public static SupervizorineAtmintis  gautiAtminti()
    {
        if (null == vienetinisEgzempliorius)
        {
            vienetinisEgzempliorius = new SupervizorineAtmintis ();
        }
        return vienetinisEgzempliorius;
    }

    public void idetiZodiRM(String zodis, int x1, int x2)
    {
    	atmintisS[x1][x2] = zodis;
    }
    
    public String grazintiZodiRM(int x1, int x2)
    {
        return atmintisS[x1][x2];
    }

   
    public int prasoAtminties(){    
    	boolean jau=false;
    	int k=0;
    	while(jau!=true){
    		if(atmintisS[k][0].equals("0000")){
    			jau=true;
    		} else{ k=k+10;}
    	}
    	
		return k;
    	
    }
}