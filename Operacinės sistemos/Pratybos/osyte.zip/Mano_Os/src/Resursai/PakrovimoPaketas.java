package Resursai;

import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import descriptoriai.ResursuDeskriptorius;

public class PakrovimoPaketas extends ResursuDeskriptorius{
	public int nuoKur; // parametras kuri jis saugo savyje ;}

	public PakrovimoPaketas(String vardas, int rusis, String tevoVardas,
			int uzimtumas, VisuLaukianciuSarasas laukiantys,
			ResursuSarasas resursai, ProcesuSarasas procesai,int nuo) {
		super(vardas, rusis, tevoVardas, uzimtumas, laukiantys, resursai, procesai);
	 this.nuoKur=nuo;
	}


	
}
