package Resursai;

import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import descriptoriai.ResursuDeskriptorius;

public class IsVartotojo extends ResursuDeskriptorius{
	public String failoVardas; // parametras kuri jis saugo savyje ;}

	public IsVartotojo(String vardas, int rusis, String tevoVardas,
			int uzimtumas, VisuLaukianciuSarasas laukiantys,
			ResursuSarasas resursai, ProcesuSarasas procesai,String v) {
		super(vardas, rusis, tevoVardas, uzimtumas, laukiantys, resursai, procesai);
		this.failoVardas= v;
	}


	
}
