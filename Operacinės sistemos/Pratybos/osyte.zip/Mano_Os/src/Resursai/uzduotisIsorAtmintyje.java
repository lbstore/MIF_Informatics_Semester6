package Resursai;

import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import descriptoriai.ResursuDeskriptorius;

public class uzduotisIsorAtmintyje extends ResursuDeskriptorius{

		public int nuoKur; // parametras kuri jis saugo savyje ;}

		public uzduotisIsorAtmintyje(String vardas, int rusis, String tevoVardas,
				int uzimtumas, VisuLaukianciuSarasas laukiantys,
				ResursuSarasas resursai, ProcesuSarasas procesai,int v) {
			super(vardas, rusis, tevoVardas, uzimtumas, laukiantys, resursai, procesai);
			this.nuoKur= v;
		
		}


		
	}
