package Resursai;

import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import descriptoriai.ResursuDeskriptorius;

public class EiluteAtmintyje extends ResursuDeskriptorius{
	public int kas; // so reiksme
	public int nuoKur; // parametras kuri jis saugo savyje ;}
	public int kiek; //kiek puslapiu imti

	public EiluteAtmintyje(String vardas, int rusis, String tevoVardas,
			int uzimtumas, VisuLaukianciuSarasas laukiantys,
			ResursuSarasas resursai, ProcesuSarasas procesai,int nuo,int kas,int kiek) {
		super(vardas, rusis, tevoVardas, uzimtumas, laukiantys, resursai, procesai);
	 this.nuoKur=nuo;
	 this.kas=kas;
	 this.kiek=kiek;
	}


	
}
