package Resursai;

import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import descriptoriai.ResursuDeskriptorius;

public class ProgramaIsorinejeAtmintyje extends ResursuDeskriptorius{
	
		public boolean fiktyvus;
		public int nuoKur; // parametras kuri jis saugo savyje ;}
		public String TPid;

		public ProgramaIsorinejeAtmintyje(String vardas, int rusis, String tevoVardas,
				int uzimtumas, VisuLaukianciuSarasas laukiantys,
				ResursuSarasas resursai, ProcesuSarasas procesai,int v,boolean ar,String vard) {
			super(vardas, rusis, tevoVardas, uzimtumas, laukiantys, resursai, procesai);
			this.nuoKur= v;
			this.fiktyvus=ar;
			this.TPid=vard;
		}


		
	}
