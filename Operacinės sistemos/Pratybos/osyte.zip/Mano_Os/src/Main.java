

import ivedimoIsvedimoImitavimas.IsvedimoIvedimoIrenginiai;
import Atmintys.*;
import Procesai.StartStop;
import planuojuSkirstau.*;
import primityvai.ResursuPrimityvai;
import sarasiukai.*;
import vmrm.RealiMasina;

public class Main {
	
	public static VisuLaukianciuSarasas Laukiantys = new VisuLaukianciuSarasas(); // visu laukianciuju sarasas
	public static ResursuSarasas Resursai= new ResursuSarasas(); //cia visu resursu sarasas
	public static ProcesuSarasas Procesai= new ProcesuSarasas();// visu procesu sarasas
	public static Planuotojas planuoja= new Planuotojas(Procesai); // cia planuotojas
	public static ResursuPaskirstytojas rpaskirstytojas = new ResursuPaskirstytojas(Procesai,Resursai,planuoja,Laukiantys); // cia resursu paskirstytojas
	public static ResursuPrimityvai Rveiksmai = new  ResursuPrimityvai(Procesai,Resursai,planuoja,Laukiantys,rpaskirstytojas); // resursu primityvai  kurti realizuoja konstruktorius
	
	public static void main(String[] args) {
   
    
    RealiMasina reali= new RealiMasina();
	StartStop startStop=new StartStop("startStop",10,"I dont Have Father because I AM GOD",Procesai,planuoja,Resursai,Laukiantys,Rveiksmai,reali);
	//System.out.println(Laukiantys.getDydis());
	//isvestiResursus();
	//isvestiProcesus();
	}

	public static void isvestiResursus(){
		for(int i=0 ; i<=Resursai.getDydis()-1;i++){
			System.out.println("Vardas: "+Resursai.getNumeris(i).RId);
			System.out.println("Rusis: "+Resursai.getNumeris(i).RRusis);
			System.out.println("Uzimtumas: "+Resursai.getNumeris(i).RUzimtumas);
			System.out.println("Tevas: "+Resursai.getNumeris(i).RGod);
			System.out.println();
			System.out.println("---------------------------");
		}
	}
	
	public static void isvestiProcesus(){
		for(int i=0 ; i<=Procesai.getDydis()-1;i++){
			System.out.println(Procesai.getNumeris(i).PId);
			System.out.println(Procesai.getNumeris(i).PPriority);
			System.out.println(Procesai.getNumeris(i).PGod);
			System.out.println(Procesai.getNumeris(i).PState);
			
			System.out.println("Gauti resursai:");
			for (int j=0; j<=Procesai.getNumeris(i).GautiResursai.getDydis()-1;j++){	
				System.out.println("Vardas: "+Procesai.getNumeris(i).GautiResursai.getNumeris(j).RId);
				System.out.println("Rusis: "+Resursai.getNumeris(j).RRusis);
				System.out.println("Uzimtumas: "+Resursai.getNumeris(j).RUzimtumas);
				System.out.println("Tevas: "+Resursai.getNumeris(j).RGod);
				
			}
			System.out.println("Sukurti resursai:");
			for (int o=0; o<=Procesai.getNumeris(i).ManoSukurtiResursai.getDydis()-1;o++){	
				System.out.println("Vardas: "+Procesai.getNumeris(i).ManoSukurtiResursai.getNumeris(o).RId);
				System.out.println("Rusis: "+Procesai.getNumeris(i).ManoSukurtiResursai.getNumeris(o).RRusis);
				System.out.println("Uzimtumas: "+Procesai.getNumeris(i).ManoSukurtiResursai.getNumeris(o).RUzimtumas);
				System.out.println("Tevas: "+Procesai.getNumeris(i).ManoSukurtiResursai.getNumeris(o).RGod);
				System.out.println("---------------------------");
			}
			System.out.println("Sukurti procesai:");
			for (int t=0; t<=Procesai.getNumeris(i).SukurtiProcesai.getDydis()-1;t++){	
				
				
			}
			System.out.println("---------------------------");
		}
		
		
	}
	
	
}
