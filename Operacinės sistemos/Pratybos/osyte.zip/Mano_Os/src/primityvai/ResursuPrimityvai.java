package primityvai;

import planuojuSkirstau.Planuotojas;
import planuojuSkirstau.ResursuPaskirstytojas;
import sarasiukai.LaukianciujuSarasas;
import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;

public class ResursuPrimityvai {
	public Planuotojas Planuoja;
	public ResursuSarasas Resursai;
	public ProcesuSarasas Procesai;
	public VisuLaukianciuSarasas LaukiantysResurso;
	public ResursuPaskirstytojas Rpaskirstytojas;

	public ResursuPrimityvai(ProcesuSarasas procesai, ResursuSarasas resursai, Planuotojas planuoja, VisuLaukianciuSarasas laukiantys, ResursuPaskirstytojas rpaskirstytojas){
		Planuoja=planuoja;
		Resursai=resursai;
		Procesai=procesai;
		LaukiantysResurso=laukiantys;
		Rpaskirstytojas=rpaskirstytojas;
	}
	
	public void naikinti(String kanaikinti,String kasNaikina){	
	int resursoNr=ResursoNr(kanaikinti);
	for (int g=0;g<=Procesai.getDydis()-1;g++){
		for (int k=0;k<=Procesai.getNumeris(g).GautiResursai.getDydis()-1;k++){
			if(Procesai.getNumeris(g).GautiResursai.getNumeris(k).RId.equals(kanaikinti)){
				Procesai.getNumeris(g).GautiResursai.trink(k);
				break;
			}
		}
		
	}
		for(int i=0; i<=Procesai.getDydis()-1;i++){
			if(Resursai.getNumeris(resursoNr).RGod.equals(Procesai.getNumeris(i).PId)){
				for(int j=0;j<=Procesai.getNumeris(i).ManoSukurtiResursai.getDydis()-1;j++){
					if (Procesai.getNumeris(i).ManoSukurtiResursai.getNumeris(j).RId.equals(Resursai.getNumeris(resursoNr).RId)){
						Procesai.getNumeris(i).ManoSukurtiResursai.trink(j);
						break;
					}
				}
			}
		}
		Resursai.trink(resursoNr);
			
	}
	
	public void prasyti(String kasPraso,String kaPraso){ // praso resurso kazkoks procesas 
		System.out.println("Manes  :"+kaPraso+" Praso procesas :"+ kasPraso);
		int kur=0;
		int ka=0;
			
	 if(arToksYra(kaPraso)){ // jeigu toks yra sukurtas
		 for (int i=0;i<=LaukiantysResurso.getDydis()-1;i++){
				if (LaukiantysResurso.getNumeris(i).getName().equals(kaPraso)){
					for (int j=0;j<=Procesai.getDydis()-1;j++){
						if(Procesai.getNumeris(j).PId.equals(kasPraso)){
							kur=i;
							ka=j;
							break;
						}
					}
				}		
			}
		    int Rnr=ResursoNr(kaPraso);
			LaukiantysResurso.getNumeris(kur).setElementas(Procesai.getNumeris(ka));
			Procesai.getNumeris(ka).setBlokuotas();
			Rpaskirstytojas.Skirstau(Rnr,kur);
		 
	 } else {
		 if(arToksYraSarasas(kaPraso)){
		 for (int i=0;i<=LaukiantysResurso.getDydis()-1;i++){
				if (LaukiantysResurso.getNumeris(i).getName().equals(kaPraso)){
					for (int j=0;j<=Procesai.getDydis()-1;j++){
						if(Procesai.getNumeris(j).PId.equals(kasPraso)){
							kur=i;
							ka=j;
							break;
						}
					}
				}		
			}
		 LaukiantysResurso.getNumeris(kur).setElementas(Procesai.getNumeris(ka));
		 Procesai.getNumeris(ka).setBlokuotas();
		 Planuoja.planuok();
	 } else {
		 LaukianciujuSarasas tavesLaukia= new LaukianciujuSarasas(kaPraso);
		 LaukiantysResurso.setElementas(tavesLaukia);
		 for (int i=0;i<=LaukiantysResurso.getDydis()-1;i++){
				if (LaukiantysResurso.getNumeris(i).getName().equals(kaPraso)){
					for (int j=0;j<=Procesai.getDydis()-1;j++){
						if(Procesai.getNumeris(j).PId.equals(kasPraso)){
							kur=i;
							ka=j;
							break;
						}
					}
				}		
			}
		 LaukiantysResurso.getNumeris(kur).setElementas(Procesai.getNumeris(ka));
		 Procesai.getNumeris(ka).setBlokuotas();
		 Planuoja.planuok();
	 }}
		
		
	}
	
	public void atlaisvinti(String kaAtlaisvinti,String kasAtlaisvina){
		
		int laukia = 0;
		for (int i=0;i<=LaukiantysResurso.getDydis()-1;i++){
			if (LaukiantysResurso.getNumeris(i).getName().equals(kaAtlaisvinti)){
				laukia=i;
					break;
								}
						}
		
		for(int k=0;k<=Procesai.getDydis()-1;k++){
			
			if(Procesai.getNumeris(k).PId.equals(kasAtlaisvina)){
				for(int j=0;j<=Procesai.getNumeris(k).GautiResursai.getDydis()-1;j++){
					
					if(Procesai.getNumeris(k).GautiResursai.getNumeris(j).RId.equals(kaAtlaisvinti)){ // cia tuo atveju jeigu turejo ir nori atsikratyti
						Procesai.getNumeris(k).GautiResursai.trink(j);
						break;
						
					}
					
					
				}
				
					int kuris=ResursoNr(kaAtlaisvinti);
					Resursai.getNumeris(kuris).setUzimtumas(1); // nustatomas kad jis laisvas
					Rpaskirstytojas.Skirstau(kuris,laukia);	
					break;
				
				
					}
				}
					
	}
	public int ResursoNr(String ieskoti){
		int radau=0;
		for(int o=0;o<=Resursai.getDydis()-1;o++){ // jeigu toks jau yra tik atlaisvina
			if(Resursai.getNumeris(o).RId.equals(ieskoti)){
				radau=o;
				break;
			}
			
		}
		return radau;
	}
	
	public boolean arToksYra(String ieskoti){
		boolean yra=false;
		for(int j=0;j<=Resursai.getDydis()-1;j++){ // jeigu toks jau yra tik atlaisvina
			if(Resursai.getNumeris(j).RId.equals(ieskoti)){
				yra=true;
				break;
			}
		}
		return yra;
		
	}
	public boolean arToksYraSarasas(String ieskoti){
		boolean yra=false;
		 for (int i=0;i<=LaukiantysResurso.getDydis()-1;i++){
				if (LaukiantysResurso.getNumeris(i).getName().equals(ieskoti)){
				yra=true;
				break;
			}
		}
		return yra;
		
	}
	
}
