package sarasiukai;
import java.util.ArrayList;

public class VisuLaukianciuSarasas {

	public ArrayList<LaukianciujuSarasas> Listas = new ArrayList<LaukianciujuSarasas>();
	
	
	public VisuLaukianciuSarasas(){
		}

		public void setElementas (LaukianciujuSarasas elementas)// ideda
		{
			Listas.add(elementas);
		}

		public int getDydis()// gauna dydi
		{
			return Listas.size();
		}
		

		public void trink (int numeris)// trina kurio nereik
		{
			Listas.remove(numeris);
		}

		public boolean arTuscias()// tikrina ar tuscias
		{
			return Listas.isEmpty();
		}

		public LaukianciujuSarasas getNumeris (int numeris)// gauna kuri reikia elementa
		{
			if (Listas.isEmpty()){
				return null;
			} else {
			return Listas.get(numeris);}
		}
		
}