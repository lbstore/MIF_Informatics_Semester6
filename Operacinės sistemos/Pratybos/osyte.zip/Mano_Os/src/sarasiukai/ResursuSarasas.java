package sarasiukai;
import descriptoriai.ResursuDeskriptorius;
import java.util.ArrayList;

public class ResursuSarasas{
	ArrayList<ResursuDeskriptorius> Listas = new ArrayList<ResursuDeskriptorius>();
	public ResursuSarasas(){
		
		}

		public void setElementas (ResursuDeskriptorius elementas)// ideda
		{
			Listas.add(elementas);
		}

		public int getDydis()// gauna dydi
		{
			return Listas.size();
		}
		

		public void trink (int numeris)// trina kurio nereik
		{
			Listas.remove(numeris);
		}

		public boolean arTuscias()// tikrina ar tuscias
		{
			return Listas.isEmpty();
		}

		public ResursuDeskriptorius getNumeris (int numeris)// gauna kuri reikia elementa
		{
			if (Listas.isEmpty()){
				return null;
			} else {
			return Listas.get(numeris);}
		}
		
}

