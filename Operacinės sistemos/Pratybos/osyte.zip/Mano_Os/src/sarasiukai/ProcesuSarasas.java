package sarasiukai;
import descriptoriai.ProcesuDeskriptorius;
import java.util.ArrayList;

public class ProcesuSarasas {
	public ArrayList<ProcesuDeskriptorius> Listas = new ArrayList<ProcesuDeskriptorius>();
	public ProcesuSarasas(){
		
		}

		public void setElementas (ProcesuDeskriptorius elementas)// ideda
		{ int size=Listas.size()-1;
			boolean idejo=false;
			int i=0;
			if (Listas.size()==0){
				Listas.add(elementas);
			}
			else{
			while(i<=size && idejo==false){
				if (elementas.PPriority>=Listas.get(i).PPriority){
					Listas.add(i,elementas);
					idejo=true;
				} i++;
			}
			if (idejo==false){
				Listas.add(elementas);
			}
			}
		}
		
		public void setElementas1 (ProcesuDeskriptorius elementas)// ideda
		{
			Listas.add(elementas);
		}
		public int getDydis()// gauna dydi
		{
			return Listas.size();
		}
		

		public void trink (int numeris)// trina kurio nereik
		{
			Listas.remove(numeris);
		}

		public boolean arTuscias()// tikrina ar tuscias
		{
			return Listas.isEmpty();
		}

		public ProcesuDeskriptorius getNumeris (int numeris)// gauna kuri reikia elementa
		{
			if (Listas.isEmpty()){
				return null;
			} else {
			return Listas.get(numeris);}
		}
		
}

