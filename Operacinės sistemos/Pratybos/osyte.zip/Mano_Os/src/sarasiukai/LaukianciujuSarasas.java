package sarasiukai;
import descriptoriai.ProcesuDeskriptorius;
import java.util.ArrayList;

public class LaukianciujuSarasas {
	public String name;
	public ArrayList<ProcesuDeskriptorius> Laukiantys = new ArrayList<ProcesuDeskriptorius>();
	public LaukianciujuSarasas(String vardas){
		setName(vardas);
		
		}

	
		public void setName(String name){
			this.name=name;
		}
		
		public String getName(){
			return name;
		}
		
		public void setElementas (ProcesuDeskriptorius elementas)// ideda
		{
				Laukiantys.add(elementas);

		}

		public int getDydis()// gauna dydi
		{
			return Laukiantys.size();
		}
		

		public void trink (int numeris)// trina kurio nereik
		{
			Laukiantys.remove(numeris);
		}

		public boolean arTuscias()// tikrina ar tuscias
		{
			return Laukiantys.isEmpty();
		}

		public ProcesuDeskriptorius getNumeris (int numeris)// gauna kuri reikia elementa
		{
			if (Laukiantys.isEmpty()){
				return null;
			} else {
			return Laukiantys.get(numeris);}
		}
		
}
