package ivedimoIsvedimoImitavimas;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class IvedimasIsvedimas 
{
	public String[] skaitytiFaila(String bylosVardas)
    {
		File byla = new File(bylosVardas);
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		String[] eilutes = new String[102];
		try 
        {
			int i1 = 0;
			fis = new FileInputStream(byla);
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);
			while (dis.available() != 0) 
            {
				eilutes[i1] = dis.readLine();
				i1++;
			}
		fis.close();
        bis.close();
        dis.close();
		} 
        catch (FileNotFoundException e) 
        {
			e.printStackTrace();
		} 
        catch (IOException e) 
        {
			e.printStackTrace();
		}
        
        return eilutes;
	}
    
	public String[][] skaitytiVisusZodziusIsFailo(String bylosVardas)
    {
		String[] eilutes = skaitytiFaila(bylosVardas);
        String[][] zodziai = new String[101][10];
        
        String skirtukai = " ";
        for (int i = 0; i < 101; i++)
        {
            if (eilutes[i] != null) 
            {
            	zodziai[i] = eilutes[i].split(skirtukai);
            }
        }
        
		return zodziai;
	}
}

