package ivedimoIsvedimoImitavimas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class IsvedimoIvedimoIrenginiai {
	
	
	public void rasyti(String eilute) // sitas imituos isvedimo
    {	
		System.out.println(eilute);
	}
	
	public String skaityti() // sitas ivedimo
	{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String nuskaitytaEilute = null;	
		System.out.println("Laukiu kol ives:");
        try {
			nuskaitytaEilute = br.readLine();
		} 
        catch (IOException ioe) 
        {
			ioe.printStackTrace();
		}   
        
        if (nuskaitytaEilute.length() > 41)
        {
            char[] eil = new char[40];
            for(int i=0; i<40; i++)
            {
                eil[i] = nuskaitytaEilute.charAt(i);
            }
            String eilute = new String(eil);
            nuskaitytaEilute = eilute;
        }
		return nuskaitytaEilute;
	}
	

}
