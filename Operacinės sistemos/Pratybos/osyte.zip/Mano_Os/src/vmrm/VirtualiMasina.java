package vmrm;

import Atmintys.VirtualiosMasinosAtmintis;

public class VirtualiMasina {
	public enum opKodai {
		AD, SU, RA, AR, LG, DG, MZ, BP, SP, DI, DN, PP, PT, NV
	}

	protected VirtualiosMasinosAtmintis atmintis;
	protected PazingsninisRezimas pazingsninisRezimas;
	public RealiMasina Reali;
	public VirtualiMasina(VirtualiosMasinosAtmintis atmintis,RealiMasina r) {
	   this.atmintis = atmintis;
       this.pazingsninisRezimas= new PazingsninisRezimas();
       this.Reali=r;
	}

	public int vykdyti() {
		String[] opKodas = new String[2]; // cia bus op kodas
		int baitas; // cia i kuri baita rasys
		int baigti = 0;
		int adr; // cia bus laikomas x1x2 adresas

		while (tikrinti(0) == 0 && baigti == 0) 
		{
			for (baitas = 0; baitas < 2; baitas++) { // isima is atminties opkoda
				char laik;
				laik = atmintis.grazintiZodi(RealiMasina.IC / 10,RealiMasina.IC % 10).charAt(baitas);
				System.out.println("opkkodas"+laik);
				opKodas[baitas] = Character.toString(laik);
				
			}
			System.out.println(opKodas[1]);
			adr = Integer.parseInt(atmintis.grazintiZodi(RealiMasina.IC / 10, RealiMasina.IC % 10).substring(2)); // gauna x1x2 reiksmes
			apdorotiKomanda(opKodas, adr / 10, adr % 10);  // cia apdoros komanas
			baigti = pazingsninisRezimas.poZingsnio(atmintis);
			if ((opKodas[0] + opKodas[1]).equals("BP")|| ((opKodas[0] + opKodas[1]).equals("SP"))) {
				if ((opKodas[0] + opKodas[1]).equals("SP") && RealiMasina.C == 'N') {
					RealiMasina.IC += 1;
				}
			} else {
				RealiMasina.IC += 1;
			}
			if (RealiMasina.IC > 99) {
				RealiMasina.IC = RealiMasina.IC % 100;
			}
		}
		if (baigti == 0) {
			pereitiIS(RealiMasina.plr, RealiMasina.C, RealiMasina.R,RealiMasina.IC);
			baigti = pazingsninisRezimas.poZingsnio(atmintis);

		}
		return baigti;
	}

	private void apdorotiKomanda(String[] opKodas, int x1, int x2) {
		Komandos komandos = new Komandos(atmintis);
		//System.out.println("miauuuuUUUUUUUUU");
		switch (opKodai.valueOf(opKodas[0] + opKodas[1])) {
		case AD: { // sudetis
			komandos.sudeti(x1, x2);
			Reali.laikmatis--;
			break;
		}
		case SU: {// atimtis
			komandos.atimti(x1, x2);
			Reali.laikmatis--;
			break;
		}
		case RA: { // i R is a
			komandos.pakrautiRegistra(x1, x2);
			Reali.laikmatis--;
			break;
		}
		case AR: { // i a is R
			komandos.siustiRegistra(x1, x2);
			
			Reali.laikmatis--;
			break;
		}
		case LG: { // lygu
			komandos.palyginti(x1, x2);
			Reali.laikmatis--;
			break;
		}

		case DG: { // daugiau
			komandos.daugiau(x1, x2);
			Reali.laikmatis--;
			break;
		}
		case MZ: { // maziau
			komandos.maziau(x1, x2);
			Reali.laikmatis--;
			break;
		}
		case BP: { // perduoti valdyna
			komandos.perduotiValdyma(x1, x2); // ---------keiciasi KS---
			Reali.laikmatis--;
			break;
		}

		case SP: { // salyginis perdavimas
			komandos.salyginisValdymas(x1, x2);
			Reali.laikmatis--;
			break;
		}

		case DI: { // isvesti
			komandos.isvestiDuomenis();
			if (Reali.laikmatis < 3) {
				Reali.laikmatis = 0;
			} else {
				Reali.laikmatis = Reali.laikmatis - 3;
			}
			break;
		}

		case DN: { // nuskaityti
			komandos.nuskaitytiDuomenis();
			if (Reali.laikmatis < 3) {
				Reali.laikmatis = 0;
			} else {
				Reali.laikmatis = Reali.laikmatis - 3;
			}
			break;
		}
		case PP: { // pakeisti psulapiavimo lentele
			komandos.pakeistiPuslapiuLentele(x1, x2);
			Reali.laikmatis--;
			break;
		}

		case PT: { // isaukia pertraukima
			komandos.issauktiPertraukima(x1, x2);
			Reali.laikmatis--;
			break;
		}
		case NV: // nutraukia vygdyma
		{
			komandos.nutrauktiValdyma();
			Reali.laikmatis--;
			break;
		}

		default:
			Reali.pi = 1;
		}
		if (Reali.laikmatis == 0) {
			Reali.ti = 1;
		}
	}

	public int tikrinti(int x) {
		int tikrint;
		if (x == 1) {
			tikrint = Reali.pi;
		} else {
			if (x == 2) {
				tikrint = Reali.si;
			} else {
				if (x == 3) {
					tikrint = Reali.ti;
				} else if ((Reali.pi + Reali.si + Reali.ti) > 0) {
					tikrint = 1;
				} else
					tikrint = 0;
			}
		}

		return tikrint;
	}

	public void pereitiIS(int plr, char l, String r, int ic) {
		String zodis = "0" + String.valueOf(plr);
		atmintis.idetiZodi(zodis, 9, 0);
		zodis = "000" + l;
		atmintis.idetiZodi(zodis, 9, 1);
		atmintis.idetiZodi(r, 9, 2);
		zodis = "00" + String.valueOf(ic);
		if (zodis.length() == 3) {
			zodis = "0" + zodis;
		}
		atmintis.idetiZodi(zodis, 9, 3);
		Reali.mode = 'S';
		System.out.println("Ivyko pertraukimas.SAVE busena.MODE=S.");
	}
}