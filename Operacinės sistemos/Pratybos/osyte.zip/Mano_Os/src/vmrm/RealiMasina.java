package vmrm;

import ivedimoIsvedimoImitavimas.IsvedimoIvedimoIrenginiai;
import Atmintys.*;

public class RealiMasina 
{
	
	public static int IC;
    public static String R;
    public static char C;
    public static int plr;
    public static char mode;// s arba v
    public static int laikmatis;
    public static int pi, si, ti;  
	public RealiosMasinosAtmintis  rmatmintis;
	public SupervizorineAtmintis spatmintis;
	public IsorineAtmintis isatmintis;
	public KanaliniIrenginys kanalinis;
	public  IsvedimoIvedimoIrenginiai  isvedimasIvedimas;

	public RealiMasina() 
    {
		this.rmatmintis = new RealiosMasinosAtmintis();
		this.rmatmintis=rmatmintis.gautiAtminti();
	    this.spatmintis = new SupervizorineAtmintis();
	    this.isatmintis = new IsorineAtmintis();
	    this.isvedimasIvedimas= new  IsvedimoIvedimoIrenginiai();
	    this.kanalinis=  new KanaliniIrenginys(rmatmintis,spatmintis,isatmintis,isvedimasIvedimas);
	}
    
	public void stabdytiDarba()
	{
		System.out.println("Reali Masina darba baige.");
		System.exit(0);
	}
	

	public void isvedimas()        //isvedimo metodas, kvieciantis isvedimo irenginio klase
	{
		System.out.println("MIAUUUU");
		int x1 = Integer.valueOf(R) / 10 % 1000;
		int x2 = Integer.valueOf(R) % 10;
		String eilute = "";
		for (int i = 0; i < 10; i++)
		{
			eilute = eilute + rmatmintis.gautiAtminti().grazintiZodiRM(x1, x2);
			System.out.println("MIAUUUU");
			if (x2 < 9)
			{
				x2++;
			}
            else
			{
				x1++;
				x2 = 0; 
			}      
		}
		 isvedimasIvedimas.rasyti(eilute);
	 }
     
	public void ivedimas()                                                      //ivedimo metodas, kvieciantis ivedimo irenginio klase
	{
		//IvedimoIrenginys ivedimoIrenginys = new IvedimoIrenginys();
		int x1 = Integer.valueOf(R) / 10 % 1000;
		int x2 = Integer.valueOf(R) % 10;
		String eilute =  isvedimasIvedimas.skaityti();
        String zodziai[];
        if (eilute.length() > 4)
        {
            int liekana = eilute.length() % 4;
            int dydis = eilute.length() / 4;
            if (liekana == 0)
            {
                zodziai = new String[dydis];
                int a = 0;
                for(int i = 0;i < dydis; i++)
                {
                    zodziai[i] = eilute.substring(0+a, 4+a);
                    a=a+4;
                }  
            }
            else
            {
                dydis = dydis + 1;
                zodziai = new String[dydis];
                int a = 0;
                for(int i=0;i < dydis-1; i++)
                {
                    zodziai[i] = eilute.substring(0+a, 4+a);
                    a=a+4;
                }
                 int likes = eilute.length() - liekana;
                 String likesZodis = eilute.substring(likes);
                 String zod = sutvarkytiZodiAtgal(likesZodis);
                 zodziai[dydis-1] = zod;
            }
            for(int j = 0; j < dydis; j++)
            {
                String zod = zodziai[j];
                rmatmintis.idetiZodiRM(zod, x1, x2);
                if (x2 < 9)
                {
                    x2++;
                }
                else
                {
                    x1++;
                    x2 = 0;
                }
            }            
        }
        else
        {
            String zod = sutvarkytiZodi(eilute);
            rmatmintis.idetiZodiRM(zod, x1, x2);
        }
	}
	public String sutvarkytiZodi(String eilute)
    {
        if (eilute.length() < 1)
        {
            eilute = "0000";
        }
        if (eilute.length() < 2)
        {
            eilute = "000" + eilute;
        }
        if (eilute.length() < 3)
        {
            eilute = "00" + eilute;
        }
        if (eilute.length() < 4)
        {
            eilute = "0" + eilute;
        }
        return eilute;
    }
    
    public String sutvarkytiZodiAtgal(String eilute)
    {
        if (eilute.length() < 1)
        {
            eilute = "0000";
        }
        if (eilute.length() < 2)
        {
            eilute = eilute + "000";
        }
        if (eilute.length() < 3)
        {
            eilute = eilute + "00";
        }
        if (eilute.length() < 4)
        {
            eilute = eilute + "0";
        }
        return eilute;
    }
    
	public void uzkrautiLentele(int[] lentele) 
	{
		for (int i = 1;i < 10; i++)
		{
			String adr = Integer.toString(lentele[i]);
			System.out.println(adr);
			switch (Integer.toString(adr.length()).charAt(0))
			{
				case '3':
				{
					adr = "0" + adr;
					break;
				}
				case '2':
				{
					adr = "00" + adr;
					break;
				}
				case '1':
				{		
					adr = "000" + adr;
					break;
				}
			}
			rmatmintis.gautiAtminti().idetiZodiRM(adr, plr%100, i);
		}
		
	}
    
    public void pereitiIV(VirtualiosMasinosAtmintis atmintis)
    {
        RealiMasina.plr = Integer.parseInt(atmintis.grazintiZodi(9, 0));
        atmintis.idetiZodi("0000", 9, 0);
        RealiMasina.C = (atmintis.grazintiZodi(9, 1)).charAt(3);
        atmintis.idetiZodi("0000", 9, 1);
        RealiMasina.R = atmintis.grazintiZodi(9, 2);
        atmintis.idetiZodi("0000", 9, 2);
        RealiMasina.IC = Integer.parseInt(atmintis.grazintiZodi(9, 3));
        atmintis.idetiZodi("0000", 9, 3);
        RealiMasina.mode = 'V';
        System.out.println("MODE=V");
    }
}

