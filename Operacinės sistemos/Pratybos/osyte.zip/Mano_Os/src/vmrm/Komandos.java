package vmrm;

import Atmintys.VirtualiosMasinosAtmintis;

public class Komandos
{
    protected VirtualiosMasinosAtmintis atmintisVM;
   
    public Komandos(VirtualiosMasinosAtmintis atmintisVM)
    {
        this.atmintisVM = atmintisVM;
    }
    public void sudeti(int x1, int x2)
    {
        int suma;
        suma = Integer.parseInt(atmintisVM.grazintiZodi(x1, x2)) + Integer.parseInt(RealiMasina.R);
        String tarp = String.valueOf(suma);
        if (suma > 9999)
        {
        	RealiMasina.R = tarp.substring(1);
        	RealiMasina.pi = 2;
        }
        else
        {
        	RealiMasina.R = tarp;
        }
    }
    
    public void atimti(int x1, int x2)
    {
        int skirtumas;
        skirtumas = Integer.parseInt(RealiMasina.R) - Integer.parseInt(atmintisVM.grazintiZodi(x1, x2));
        String tarp = String.valueOf(skirtumas);
        if (skirtumas < 0)
        {
        	RealiMasina.R = "0000";
        	RealiMasina.pi = 3;
        }
        else
        {
        	RealiMasina.R = tarp;
        }
    }
    
    public void pakrautiRegistra(int x1, int x2)         
    {
    	RealiMasina.R = atmintisVM.grazintiZodi(x1, x2);
    }
    
    public void siustiRegistra(int x1, int x2)
    {
        atmintisVM.idetiZodi(RealiMasina.R, x1, x2);
    }
    
    public void pakeistiPuslapiuLentele(int x1, int x2)
    {
    	int plr = Integer.parseInt(atmintisVM.grazintiZodi(x1, x2));
    	RealiMasina.plr = plr;
    }
    
    public void palyginti(int x1, int x2)
    {
        if ((RealiMasina.R).equals(atmintisVM.grazintiZodi(x1, x2)))
        {
        	RealiMasina.C = 'T';
        }
        else
        {
        	RealiMasina.C = 'N';
        }
    }
    
    public void daugiau(int x1, int x2)
    {
        if (Integer.parseInt(RealiMasina.R) > Integer.parseInt(atmintisVM.grazintiZodi(x1, x2)))
        {
        	RealiMasina.C = 'T';        
        }
        else
        {
        	RealiMasina.C = 'N';
        }
    }
   
    public void maziau(int x1, int x2)
    {
        if (Integer.parseInt(RealiMasina.R) < Integer.parseInt(atmintisVM.grazintiZodi(x1, x2)))
        {
        	RealiMasina.C = 'T';
        }
        else
        {
        	RealiMasina.C = 'N';
        }
    }
    
    public void perduotiValdyma(int x1, int x2)
    {
        int adresas;
        adresas = x1 * 10 + x2;
        RealiMasina.IC = adresas;
    }
    
    public void salyginisValdymas(int x1, int x2)
    {
        if (RealiMasina.C == 'T')
        {
            int adresas;
            adresas = x1 * 10 + x2;
            RealiMasina.IC = adresas;
        }        
    }
    
    public void isvestiDuomenis()
    {
    	RealiMasina.si = 2;
    }
    
    public void nuskaitytiDuomenis()
    {
    	RealiMasina.si = 1;
    }
    
    public void nutrauktiValdyma()
    {
    	RealiMasina.si = 3;
    }
    
    public void issauktiPertraukima(int x1, int x2)
    {
    	RealiMasina.si = x1 * 10 + x2;
    }
}
