package vmrm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import Atmintys.RealiosMasinosAtmintis;
import Atmintys.VirtualiosMasinosAtmintis;
public class PazingsninisRezimas
{  
	static protected String[] istorija;
	public PazingsninisRezimas(){}
	public String skaitytiIsekrano() 
    {	
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String eilute = null; 
		try 
        {					
			eilute = br.readLine();
		} 
        catch (IOException ioe) 
        {
			ioe.printStackTrace();
		}
		return eilute;
	}

	public int poZingsnio(VirtualiosMasinosAtmintis vmatmintis) 
    {
		int baigti = 0;
		int nuskaitytasZodis;
    		nuskaitytasZodis = 0;
    		
    			switch (nuskaitytasZodis)
    			{
		   			case '0':
		   			{
		   				break;
		   			}
		   			
		   			case '3':
		   			{
		   				spausdintiRM();
		   				break;
		   			}
		   		
    			}         
    	return baigti;
	}

	private void spausdintiRM() {
		boolean blogasPuslapiuSkaicius = true;
		int kiekis = 0;
		while (blogasPuslapiuSkaicius)
		{
			blogasPuslapiuSkaicius = false;
			System.out.println("Kiek puslapiu spausdinti?[1..100]");
			String nuskaityta = skaitytiIsekrano();
			if(nuskaityta.codePointAt(0) > 47 && nuskaityta.codePointAt(0) < 58 && nuskaityta.length() > 0)
			{
				if(nuskaityta.length() == 1)
				{
					kiekis = Integer.parseInt(nuskaityta);
					if (kiekis < 1 || kiekis > 100)
					{
						blogasPuslapiuSkaicius = true;
					}
				}
				else if(nuskaityta.length() == 2)
					{
						if(nuskaityta.codePointAt(1) > 47 && nuskaityta.codePointAt(1) < 58)
						{
							kiekis = Integer.parseInt(nuskaityta);
							if (kiekis < 1 || kiekis > 100)
							{
								blogasPuslapiuSkaicius = true;
							}
						}
						else blogasPuslapiuSkaicius = true;
					}
					else if(nuskaityta.length() == 3)
						{
							if(nuskaityta.codePointAt(2) > 47 && nuskaityta.codePointAt(2) < 58)
							{
								kiekis = Integer.parseInt(nuskaityta);
								if (kiekis < 1 || kiekis > 100)
								{
									blogasPuslapiuSkaicius = true;
								}
							}
							else blogasPuslapiuSkaicius = true;
						}
						else blogasPuslapiuSkaicius = true;				
			}
			else blogasPuslapiuSkaicius = true;
			if (blogasPuslapiuSkaicius == true)
			{
				System.out.println("Ivedete ne skaiciu is intervalo [1..100]");
			}
		}
		String puslapiai = "";
		boolean neTiekPuslapiu = true;
		String[] zodziai = new String[100];
		for (int i = 0; i < 100; i++)
		{
			zodziai[i] = " ";
		}
		while (neTiekPuslapiu)
		{
			neTiekPuslapiu = false;
			System.out.println("Iveskite " + kiekis + " puslapiu numerius atskirtus tik kableliais");
			puslapiai = skaitytiIsekrano();
			String skirtukai = ",";
   			zodziai = puslapiai.split(skirtukai);
   			int tikrasKiekis = zodziai.length;
   			if (tikrasKiekis != kiekis)
   			{
   				neTiekPuslapiu = true;
   				System.out.println("Ivedete " + tikrasKiekis + " puslapiu. Turejote ivesti " + kiekis + " puslapiu.");
   			}
		}
		System.out.println();
		System.out.println("Reali atmintis:");
		System.out.println("psl 0     1    2   3    4    5    6    7    8    9");
		for(int i=0;i<kiekis;i++)
		{
			int psl = Integer.parseInt(zodziai[i]);
			System.out.print(psl + "  ");
			for(int j=0;j<10;j++)
			{
				System.out.print(RealiosMasinosAtmintis.gautiAtminti().grazintiZodiRM(psl, j) + " ");
			}
			System.out.println();
		}  	    	
		System.out.println();				
	}

	public int poPabaigos(VirtualiosMasinosAtmintis vmatmintis) {
		System.out.println("Virtuali masina baige darba. Rinkites ka daryti toliau.");
		int baigti = 0;
		boolean netvarkingaiIvesta = true;
		String nuskaitytasZodis = "";
		while (netvarkingaiIvesta)
		{
			netvarkingaiIvesta = false;
			System.out.println("Baigti darba - 1; Per naujo paleisti realia masina - 2;");
    		nuskaitytasZodis = skaitytiIsekrano();
    		if (nuskaitytasZodis.length() == 1)
    		{
    			switch (nuskaitytasZodis.charAt(0))
    			{
		   			case '1':
		   			{
		   				baigti = 1;
		   				break;
		   			}
		   			case '2':
		   			{
		   				baigti = 2;
		   				break;
		   			}
		   			default:	
		   			{
		   				System.out.println("Tokio pasirinkimo nera. Galite rinktis:");
		   				netvarkingaiIvesta = true;
		   			}
    			}
		   	}
			else
			{
   				System.out.println("Tokio pasirinkimo nera. Galite rinktis:");
   				netvarkingaiIvesta = true;
			}
    	}        
    	return baigti;
	}

}