package Procesai;

import Resursai.IsVartotojo;
import descriptoriai.ProcesuDeskriptorius;
import descriptoriai.ResursuDeskriptorius;
import planuojuSkirstau.Planuotojas;
import planuojuSkirstau.ResursuPaskirstytojas;
import primityvai.ResursuPrimityvai;
import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import vmrm.RealiMasina;


public class NiekoNeveikiu1 extends ProcesuDeskriptorius{
	

	
	public NiekoNeveikiu1(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
		ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai) {
	
		super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso,Rveiksmai);
	}
	public void goGo(){
		System.out.println("Dirbu Niekoneveikiu1 ");
		switch(PFinish){
			case(0):{ //  blokuojasi ir laukia resurso 2
				this.PFinish=1;
				Rveiksmai.prasyti(this.PId,"niekoNeveikiu2");
				break;
			}
			
			case(1):{ // naikina gauta resursa ir sukuria ir atlaisvina arba tik atlaisvina jeigu toks jau yra resursa 2
				
				this.PFinish=0;
				
				Rveiksmai.naikinti("niekoNeveikiu2",this.PId);
				

				if(arToksYra("niekoNeveikiu1")){
					Rveiksmai.atlaisvinti("niekoNeveikiu1", this.PId);
				} else{
					ResursuDeskriptorius niekoNeveikiu1=new ResursuDeskriptorius("niekoNeveikiu1",2,this.PId,1,LaukiantysResurso,Resursai,Procesai);
					Rveiksmai.atlaisvinti("niekoNeveikiu1", this.PId);		
				}
			}		
		}	
	}
	
	public boolean arToksYra(String ieskoti){
		boolean yra=false;
		for(int j=0;j<=Resursai.getDydis()-1;j++){ // jeigu toks jau yra tik atlaisvina
			if(Resursai.getNumeris(j).RId.equals(ieskoti)){	
				yra=true;
				break;
			}
			
		}
		return yra;
		
	}
}
