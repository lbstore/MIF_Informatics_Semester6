	package Procesai;


	import java.lang.reflect.Field;
	import planuojuSkirstau.*;
	import primityvai.*;
	import sarasiukai.*;
	import vmrm.*;
import descriptoriai.*;

	public class Loader extends ProcesuDeskriptorius {
		
		public RealiMasina Reali;
		int nuo;// cia nuo kur super arm klaida yra 
		
		public Loader(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
				ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai,RealiMasina reali) {
				super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso, Rveiksmai);
				this.Reali= reali;
			}
			public void goGo(){

				System.out.println("Dirbu Loaderis");
				switch(PFinish){
					case(0):{ //  blokuojasi laukai Pakrovimo paketas resurso
						this.PFinish=1;
						Rveiksmai.prasyti(this.PId,"PakrovimoPaketas");
						break;
					}
					
					case(1):{  // Laukia kanalu irenginio resurso
						this.PFinish=2;
						Rveiksmai.prasyti(this.PId,"kanaluIrenginys");		
					break;
					}
					
					case(2):{  //Ivygdo exchange :P
						this.PFinish=3;
						nuo=Reali.rmatmintis.gautiAtminti().prasoAtminties();
						int so=7;
						int nuoku=getParamether("nuoKur");
						int kiek = 10;
						int iki=nuoku;
						for (int i=0;i<kiek;i++){
							iki=iki+1;
						}
				   Reali.kanalinis.xchg(so,nuoku,iki);
				   Rveiksmai.atlaisvinti("kanaluIrenginys", this.PId);
					break;
					}
					
					case(3):{//istrina eilute atmintyje ir sukuria kad baige darba ;}
						this.PFinish=0;
						for(int i=1;i<100;i++)
				        {
				            for(int j=0;j<10;j++)
				            {
				            	System.out.print(Reali.rmatmintis.gautiAtminti().grazintiZodiRM(i-1, j));
				            	
				            }
				            System.out.println();
				        }
						Rveiksmai.naikinti("PakrovimoPaketas", this.PId);
						ResursuDeskriptorius BaigiauLoader =new  ResursuDeskriptorius("BaigiauLoader",2,this.PId,1,LaukiantysResurso,Resursai,Procesai);
						Rveiksmai.atlaisvinti("BaigiauLoader", this.PId);
							break;
					}
					
				}
			}
			public int getParamether(String kagauti){
				Field field = null;
				int fieldValue = 0;
				
				try {
					field =GautiResursai.getNumeris(0).getClass().getDeclaredField(kagauti);
				} catch (SecurityException e) {
					e.printStackTrace();
				} catch (NoSuchFieldException e) {
					e.printStackTrace();
				}
		
				try {
					fieldValue =  field.getInt(GautiResursai.getNumeris(0));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
				return fieldValue;	
			}
	}


