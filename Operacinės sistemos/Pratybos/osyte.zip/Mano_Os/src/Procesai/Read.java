package Procesai;


import java.lang.reflect.Field;

import Resursai.uzduotisIsorAtmintyje;
import planuojuSkirstau.*;
import primityvai.*;
import sarasiukai.*;
import vmrm.*;
import descriptoriai.*;
import ivedimoIsvedimoImitavimas.*;

public class Read  extends ProcesuDeskriptorius {
	
	public IvedimasIsvedimas skaitysiu= new IvedimasIsvedimas();
	public RealiMasina Reali;
	public String[][] zodziai;
	public int atmintis;
	
	public Read(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
			ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai,RealiMasina reali) {
			super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso, Rveiksmai);
			Reali= reali;
		}
		public void goGo(){

			System.out.println("Dirbu Read ");
			switch(PFinish){
				case(0):{ //  blokuojasi ir laukia resurso Is vartotojo
					this.PFinish=1;
					Rveiksmai.prasyti(this.PId,"IsVartotojo");
					break;
				}
				
				case(1):{  // blokuojasi laukdamas KanaluIrenginys resurso
					this.PFinish=2;
					Rveiksmai.prasyti(this.PId,"kanaluIrenginys");
				break;
				}
				case(2):{  //nuskaito i stringa musu faila;
					this.PFinish=3;
					String kaNuskaityti=getFileName();
					zodziai = skaitysiu.skaitytiVisusZodziusIsFailo(kaNuskaityti);
					Rveiksmai.prasyti(this.PId,"IsorAtmintis");
				break;
				}
				
				case(3):{  // kopijuoja eilutes i isorine atminti ir sukuria atlaisvina resursa JLC
					this.PFinish=4;
					Reali.kanalinis.dirbs(3);
					atmintis=Reali.isatmintis.gautiAtminti().prasoAtminties();
					int iki=atmintis+11; // iki kur kopijuoti
					for(int h=0;h<=5;h++){
				//	System.out.println(zodziai[0][h]);
					//	zodziai[0][h]="0000";
				
					Reali.isatmintis.gautiAtminti().idetiZodiRM(zodziai[0][h], atmintis, h);
					//System.out.println(zodziai[0][h]);
					}
					int ka=1;
					for(int i=atmintis+2;i<iki;i++)
			        {
			            for(int j=0;j<10;j++)
			            { 
			            	String zodis = zodziai[ka][j];
			            	for (int h=0;h<4;h++)
			            	{
			            		zodis = zodis.replaceAll("-", " ");
			            	}
			            	Reali.isatmintis.gautiAtminti().idetiZodiRM(zodis, i-1, j);
			            }
			            ka++;
			        }
					for(int i=1;i<100;i++)
			        {
			            for(int j=0;j<10;j++)
			            {
			            	System.out.print(Reali.isatmintis.gautiAtminti().grazintiZodiRM(i-1, j));
			            	
			            }
			            System.out.println();
			        }
					Reali.kanalinis.baigeDirbti();
					Rveiksmai.atlaisvinti("IsorAtmintis", this.PId);
				break;
				}
				case(4):{
					this.PFinish=5;
					Rveiksmai.atlaisvinti("kanaluIrenginys",this.PId);
					break;
				}
				case(5):{
					this.PFinish=0;
					Rveiksmai.naikinti("IsVartotojo", this.PId);
					uzduotisIsorAtmintyje uzduotisIsorAtmintyje=new uzduotisIsorAtmintyje("uzduotisIsorAtmintyje",2,this.PId,1,LaukiantysResurso,Resursai,Procesai,atmintis);
					Rveiksmai.atlaisvinti("uzduotisIsorAtmintyje", this.PId);
					break;
				}
			}
		}
		
		public String getFileName(){ // reiktu apibendrint
			Field field = null;
			String fieldValue=null;
			try {
				field =GautiResursai.getNumeris(0).getClass().getDeclaredField("failoVardas");
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			}
	
			try {
				fieldValue = (String) field.get(GautiResursai.getNumeris(0));
				System.out.println("fieldValue = " + fieldValue);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
			return fieldValue;	
		}
}
