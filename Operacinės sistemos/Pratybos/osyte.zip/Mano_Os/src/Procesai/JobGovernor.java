package Procesai;






import Resursai.PakrovimoPaketas;

import planuojuSkirstau.*;
import primityvai.*;
import sarasiukai.*;
import vmrm.*;
import descriptoriai.*;
import Atmintys.*;

public class JobGovernor  extends ProcesuDeskriptorius {
	
	public RealiMasina Reali;
	int kur;// cia  nuo kurio isorineje atmintyje
	int nuo;// cia nuo kur super arm klaida yra 
	
	public JobGovernor(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
			ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai,RealiMasina reali) {
			super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso, Rveiksmai);
			this.Reali= reali;
		}
		public void goGo(){

			System.out.println("Dirbu JobGovernor ");
			switch(PFinish){
				case(0):{ // blokuojasi laukia VartAtmintis resurso
					this.PFinish=1;
					Rveiksmai.prasyti(this.PId,"VartAtmintis");
					break;
				}
				case(1):{ // blokuojasi laukia Isorine atmintis resurso
					this.PFinish=2;
					Rveiksmai.prasyti(this.PId,"IsorAtmintis");
					break;
				}
				case(2):{ //cia nustato registrus is failo ir sukuria pakrovimo paketas resursa
					this.PFinish=3;
					kur=Reali.rmatmintis.gautiAtminti().prasoAtminties();
					registrai();
					PakrovimoPaketas pakrovimoPaketas=new PakrovimoPaketas("PakrovimoPaketas",2,this.PId,1,LaukiantysResurso,Resursai,Procesai,nuo);
					Rveiksmai.atlaisvinti("PakrovimoPaketas", this.PId);
					break;
				}
				case(3):{
					this.PFinish=4;
					Rveiksmai.prasyti(this.PId,"BaigiauLoader");
					break;
				}
				case(4):{
					this.PFinish=5;
					Rveiksmai.naikinti("programaIsorinejeAtmintyje", this.PId);
					Rveiksmai.atlaisvinti("IsorAtmintis", this.PId);
					break;
				}
				case(5):{
					this.PFinish=6;
					Reali.pi = 0;
			        Reali.ti = 0; 
					Reali.si = 0;
			        System.out.println("((((=Kuriama VM=))))");
					VirtualiosMasinosAtmintis vmatmintis = new VirtualiosMasinosAtmintis(Reali.rmatmintis, Reali.plr);
					VirtualiMasina virtualiMasina = new VirtualiMasina(vmatmintis,Reali); 
			        int[] lentele = {0,1,2,3,4,5,6,7,8,9};
			        Reali.uzkrautiLentele(lentele);
			       // VM vm=new VM("vm",9,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali,virtualiMasina,vmatmintis);
			        Planuoja.planuok();
					break;
				}
				case(6):{
					this.PFinish=0;
					
					break;
				}
				
				
			}
		}
	public void  registrai(){
		 int tarpi = Integer.parseInt(Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuo,0));
	        if (tarpi > -1 || tarpi < 100)
	        {
	           int IC = tarpi;
	           Reali.IC=IC;
	           System.out.println(IC);
	        }
	        String tarps = (Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuo, 1));
	        if (tarps.length() == 4)
	        {
	            String R = tarps;
	            Reali.R=R;
	            System.out.println(R);
	        }
	        char tarpc = (Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuo, 2)).charAt(0);
	        if (tarpc == 'T' || tarpc == 'N')
	        {
	        	char C = tarpc;
	        	Reali.C=C;
	        	System.out.println(C);
	        }		
	        tarpi = Integer.parseInt(Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuo, 3));
	        if (tarpi > 0 || tarpi < 1000)
	        {
	        	int plr = tarpi;
	        	Reali.plr=plr;
	        	System.out.println(plr);
	        }
	        tarpc = (Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuo, 4)).charAt(0);
	        if (tarpc == 'S' || tarpc == 'V')
	        {
	        	char mode = tarpc;
	        	Reali.mode=mode;
	        	System.out.println(mode);
	        }
	        tarpi = Integer.parseInt(Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuo, 5));
	        if (tarpi > -1 || tarpi < 100)
	        {
	            int laikmatis = tarpi;
	            Reali.laikmatis=laikmatis;
	            System.out.println(laikmatis);
	        } 
	}
		
}
