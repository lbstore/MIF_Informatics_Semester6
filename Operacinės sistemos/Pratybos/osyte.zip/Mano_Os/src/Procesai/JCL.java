package Procesai;


import java.lang.reflect.Field;

import Resursai.EiluteAtmintyje;
import Resursai.ProgramaIsorinejeAtmintyje;

import planuojuSkirstau.*;
import primityvai.*;
import sarasiukai.*;
import vmrm.*;
import descriptoriai.*;
import Atmintys.*;

public class JCL  extends ProcesuDeskriptorius {
	
	public RealiMasina Reali;
	int nuokur;// cia  nuo kurio isorineje atmintyje
	int nuo;// cia nuo kur super arm klaida yra 
	
	public JCL(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
			ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai,RealiMasina reali) {
			super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso, Rveiksmai);
			this.Reali= reali;
		}
		public void goGo(){

			System.out.println("Dirbu JCL ");
			switch(PFinish){
				case(0):{ //  blokuojasi laukia uzduotis isorineje atmintyje resurso
					this.PFinish=1;
					Rveiksmai.prasyti(this.PId,"uzduotisIsorAtmintyje");
					break;
				}
				case(2):{  // Laukia kanalu irenginio resurso
					this.PFinish=3;
					Rveiksmai.prasyti(this.PId,"kanaluIrenginys");		
				break;
				}
				
				case(1):{  //laukia Isorine atmintis resurso
					this.PFinish=2;
					Rveiksmai.prasyti(this.PId,"IsorAtmintis");	
				break;
				}
				
				case(3):{//tikrina validuma
					Reali.kanalinis.dirbs(3);
					boolean nekorektiska=false;
					boolean radau=false;
					nuokur=getParamether();
					int iki = nuokur+10;
					
					
					for(int j=0;j<5;j++) // tikrina ar yra parametrai
		            { if(Reali.isatmintis.gautiAtminti().grazintiZodiRM(nuokur, j).equals("0000")){ 
		            	nekorektiska=true;
		            	break;
		            }else {
		            	break;
		            }	
		            }
				
					for(int i=nuokur+1;i<iki;i++) // tikrina ar yra end
			        {
			            for(int j=0;j<10;j++){
			            	if(Reali.isatmintis.gautiAtminti().grazintiZodiRM(i, j).equals("NV00")){
			            	radau=true;
			            	break;
			            	}	
			            }
			        }
					if(radau==false){
						nekorektiska=true;
					}
					
					if(nekorektiska){
						this.PFinish=4;
						Rveiksmai.prasyti(this.PId,"SuperAtmintis");
					}else {
						this.PFinish=5;
						Reali.kanalinis.baigeDirbti();
						Rveiksmai.atlaisvinti("IsorAtmintis", this.PId);
					}
				break;
				}
				case(4):{  // praso supervizorines atmintie skur ikis savo eilute i super atmnti
					this.PFinish=10;
					Reali.kanalinis.dirbs(2);
					String[] zodis={"Neko","rekt","iska"," pro","gram","a"};
					nuo=Reali.spatmintis.gautiAtminti().prasoAtminties();
					
					for (int i=0;i<=5;i++){
						Reali.spatmintis.gautiAtminti().idetiZodiRM(zodis[i], nuo, i);
					}
					
					Reali.kanalinis.baigeDirbti();
					EiluteAtmintyje EiluteAtmintyje=new EiluteAtmintyje("EiluteAtmintyje",2,this.PId,1,LaukiantysResurso,Resursai,Procesai,nuo,5,1);
					Rveiksmai.atlaisvinti("EiluteAtmintyje", this.PId);
					break;
				}
				case(5):{
					this.PFinish=6;
					Rveiksmai.naikinti("uzduotisIsorAtmintyje", this.PId);
					Rveiksmai.atlaisvinti("kanaluIrenginys", this.PId);
					break;
				}
				case(6):{
					this.PFinish=0;
				    ProgramaIsorinejeAtmintyje programaIsorinejeAtmintyje=new ProgramaIsorinejeAtmintyje("programaIsorinejeAtmintyje",2,this.PId,1,LaukiantysResurso,Resursai,Procesai,nuokur,false,this.PId);
					Rveiksmai.atlaisvinti("programaIsorinejeAtmintyje", this.PId);
					break;
				}
				case(7):{ // blokuosis ir lauks pabaigos
					this.PFinish=8;
					Rveiksmai.prasyti(this.PId,"BaigiauPrint");	
					break;
				}
								
				case(8):{
					this.PFinish=9;
					Rveiksmai.atlaisvinti("SuperAtmintis", this.PId);
					break;
				}
				
				case(9):{
					System.out.println("stadija 7");
					this.PFinish=10;
					Rveiksmai.atlaisvinti("IsorAtmintis", this.PId);
					break;
				}
				case(10):{
					System.out.println("stadija 8");
					this.PFinish=7;
					Rveiksmai.naikinti("uzduotisIsorAtmintyje", this.PId);
					Rveiksmai.atlaisvinti("kanaluIrenginys", this.PId);
					break;
				}
				
			}
		}
		public int getParamether(){
			Field field = null;
			int fieldValue = 0;
			
			try {
				field =GautiResursai.getNumeris(0).getClass().getDeclaredField("nuoKur");
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			}
	
			try {
				fieldValue =  field.getInt(GautiResursai.getNumeris(0));
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
			return fieldValue;	
		}
}
