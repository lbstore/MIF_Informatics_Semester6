package Procesai;

import descriptoriai.ProcesuDeskriptorius;
import descriptoriai.ResursuDeskriptorius;
import planuojuSkirstau.Planuotojas;
import planuojuSkirstau.ResursuPaskirstytojas;
import primityvai.ResursuPrimityvai;
import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import vmrm.RealiMasina;


public class NiekoNeveikiu2 extends ProcesuDeskriptorius{
	public int kuris;
	
	public NiekoNeveikiu2(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
	 ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai) {
	 super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso,Rveiksmai);
	}
	
	public void goGo(){
		System.out.println("Dirbu Niekoneveikiu2 ");
		switch(PFinish){
			case(0):{ //  blokuojasi ir laukia resurso 2
				this.PFinish=1;
				Rveiksmai.prasyti(this.PId,"niekoNeveikiu1");
				break;
			}
			
			case(1):{ // naikina gauta resursa ir sukuria ir atlaisvina arba tik atlaisvina jeigu toks jau yra resursa 2
				
				this.PFinish=0;
				
				Rveiksmai.naikinti("niekoNeveikiu1",this.PId);

				if(arToksYra("niekoNeveikiu2")){
					Rveiksmai.atlaisvinti( "niekoNeveikiu2", this.PId);
				} else{
					ResursuDeskriptorius niekoNeveikiu2=new ResursuDeskriptorius("niekoNeveikiu2",2,this.PId,1,LaukiantysResurso,Resursai,Procesai);
					Rveiksmai.atlaisvinti( "niekoNeveikiu2", this.PId);		
				}
				break;
			}		
		}	
	}
	public boolean arToksYra(String ieskoti){
		boolean yra=false;
		for(int j=0;j<=Resursai.getDydis()-1;j++){ // jeigu toks jau yra tik atlaisvina
			if(Resursai.getNumeris(j).RId.equals(ieskoti)){	
				yra=true;
				break;
			}
			
		}
		return yra;
		
	}
}
