package Procesai;




	import java.lang.reflect.Field;

	import Resursai.EiluteAtmintyje;
	import Resursai.PakrovimoPaketas;
	import Resursai.ProgramaIsorinejeAtmintyje;

	import planuojuSkirstau.*;
	import primityvai.*;
	import sarasiukai.*;
	import vmrm.*;
	import descriptoriai.*;
import Atmintys.*;

	public class VM extends ProcesuDeskriptorius {
		
		public RealiMasina Reali;
		public VirtualiMasina vm;
		int nuo;// cia nuo kur sup
		public VirtualiosMasinosAtmintis vmatmintis;
		
		public VM(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
				ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai,RealiMasina reali,VirtualiMasina vm,VirtualiosMasinosAtmintis vmatmintis) {
				super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso, Rveiksmai);
				this.Reali= reali;
				this.vm=vm;
				this.vmatmintis=vmatmintis;
			}
			public void goGo(){

				System.out.println("Dirbu VM ");
				switch(PFinish){
					case(0):{ // pereina u vartotojaus rezima
						 zingsnis(vm, vmatmintis);
					 
						break;
					}
					case(1):{ // vykdoma programa
						this.PFinish=2;
						Rveiksmai.prasyti(this.PId,"IsorAtmintis");
						break;
					}
					case(2):{ //jeigu ivedimas isvedimas nv hals ti=0;
						this.PFinish=3;
					
						break;
					}
					case(3):{
						this.PFinish=4;
						Rveiksmai.prasyti(this.PId,"BaigiauLoader");
						break;
					}
					case(4):{
						this.PFinish=5;
						
						break;
					}
					case(5):{
						this.PFinish=6;
						break;
					}
					case(6):{
						this.PFinish=0;
						
						break;
					}
					
					
				}
			}
			public void  zingsnis(VirtualiMasina virtualiMasina, VirtualiosMasinosAtmintis vmatmintis)
			{
				int arBaigti = 0;
				while (arBaigti == 0)
				{
			    	if (RealiMasina.mode == 'S') Reali.pereitiIV(vmatmintis);
			        Reali.pi = 0;
			        Reali.ti = 0; 
					Reali.si = 0;
					arBaigti = 0;
					arBaigti = virtualiMasina.vykdyti();
					if (arBaigti == 1) break;
				  	if (virtualiMasina.tikrinti(2) == 1)
					{
				  		//this.PFinish=1;
						Reali.ivedimas();
					}
					if (virtualiMasina.tikrinti(2) == 2)
					{
					//this.PFinish=2;
					///Reali.isvedimas();
						Reali.isvedimasIvedimas.rasyti("miau");
					}
					if (Reali.si == 3 || Reali.ti == 1 )
					{	
						// cia baigia darba :]
						break;
						
					}
			        if (Reali.si != 3) {Reali.pi=Reali.si=0;}
				}
			}

}
