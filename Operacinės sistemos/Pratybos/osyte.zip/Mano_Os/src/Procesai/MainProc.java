package Procesai;

import java.lang.reflect.Field;

import Resursai.IsVartotojo;
import descriptoriai.ProcesuDeskriptorius;
import descriptoriai.ResursuDeskriptorius;
import planuojuSkirstau.Planuotojas;
import planuojuSkirstau.ResursuPaskirstytojas;
import primityvai.ResursuPrimityvai;
import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;
import vmrm.RealiMasina;


public class MainProc extends ProcesuDeskriptorius{
	public int name=0;
	public RealiMasina Reali;
	public String name1;
	
	public MainProc(String vardas, int prioritetas, String tevas,ProcesuSarasas procesai, Planuotojas planuoja,
		ResursuSarasas resursai, VisuLaukianciuSarasas laukiantysResurso,ResursuPrimityvai Rveiksmai, RealiMasina reali) {
	
		super(vardas, prioritetas, tevas, procesai, planuoja, resursai, laukiantysResurso,Rveiksmai);
		this.Reali=reali;
	}
	public void goGo(){
		System.out.println("Dirbu MainProc ");
		switch(PFinish){
			case(0):{ //  Laukia resurso programa isorineje atmintyje;
				this.PFinish=1;
				this.name=name+1;
				Rveiksmai.prasyti(this.PId,"programaIsorinejeAtmintyje");
				break;
			}
			
			case(1):{ // naikina gauta resursa ir sukuria ir atlaisvina arba tik atlaisvina jeigu toks jau yra resursa 2
				this.PFinish=0;
				if(getParamether()){
					String vardas=getName();
					for(int i=0;i<=Procesai.getDydis()-1;i++){
						if(Procesai.getNumeris(i).PId.equals(vardas)){
							Procesai.trink(i);
							break;
						}
						
					}
					Rveiksmai.naikinti("programaIsorinejeAtmintyje", this.PId);
					Planuoja.planuok();
				} else{
					String name2= "JobGovernor";
					name1=name2.concat(Integer.toString(name));
					JobGovernor JobGovernor=new JobGovernor(name1,8,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali);
					JobGovernor.nuo=getnuo();
					Rveiksmai.naikinti("programaIsorinejeAtmintyje", this.PId);
					Planuoja.planuok();

				}	
			Planuoja.planuok();	// sukure ir vsio
			}		
		}	
	}
	
	


	public boolean getParamether(){
		Field field = null;
		boolean fieldValue = false;
		
		try {
			field =GautiResursai.getNumeris(0).getClass().getDeclaredField("fiktyvus");
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}

		try {
			fieldValue =  field.getBoolean(GautiResursai.getNumeris(0));
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return fieldValue;	
	}
	
	public String getName(){ 
		Field field = null;
		String fieldValue=null;
		try {
			field =GautiResursai.getNumeris(0).getClass().getDeclaredField("TPid");
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}

		try {
			fieldValue = (String) field.get(GautiResursai.getNumeris(0));
			System.out.println("fieldValue = " + fieldValue);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return fieldValue;	
	}
	public int getnuo(){
		Field field = null;
		int fieldValue = 0;
		
		try {
			field =GautiResursai.getNumeris(0).getClass().getDeclaredField("nuoKur");
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}

		try {
			fieldValue =  field.getInt(GautiResursai.getNumeris(0));
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return fieldValue;	
	}

}
