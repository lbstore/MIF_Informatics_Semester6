package Procesai;

import Resursai.IsVartotojo;
import planuojuSkirstau.*;
import primityvai.ResursuPrimityvai;
import sarasiukai.*;
import vmrm.RealiMasina;
import descriptoriai.*;

public class StartStop extends ProcesuDeskriptorius{
	
	public RealiMasina Reali;
	
	public StartStop(String vardas, int prioritetas, String tevas, ProcesuSarasas procesai,Planuotojas planuoja, ResursuSarasas resursai, VisuLaukianciuSarasas laukiantys,ResursuPrimityvai rveiksmai,RealiMasina reali ) {
		super(vardas, prioritetas, tevas, procesai, planuoja, resursai,laukiantys,rveiksmai);
		Reali= reali;
		Planuoja.planuok();	// iskvieciamas planuotojas;
	}
	
	 public void goGo() {
		 
		 System.out.println("Dirbu StartStop");
		 
		 switch(PFinish){
		 case(0):{ // sisteminiu resursu kurimas ir  procesu
			 
			 /*------------------------------------------Resursai------------------------------------------------------------*/
			ResursuDeskriptorius niekoNeveikiu1=new ResursuDeskriptorius("niekoNeveikiu1",2,this.PId,1,LaukiantysResurso,Resursai,Procesai);
			ResursuDeskriptorius niekoNeveikiu2=new ResursuDeskriptorius("niekoNeveikiu2",2,this.PId,1,LaukiantysResurso,Resursai,Procesai);
			ResursuDeskriptorius osDarboPabaiga=new ResursuDeskriptorius("osDarboPabaiga",1,this.PId,2,LaukiantysResurso,Resursai,Procesai);
			ResursuDeskriptorius kanaluIrenginys=new ResursuDeskriptorius("kanaluIrenginys",1,this.PId,1,LaukiantysResurso,Resursai,Procesai);
			IsVartotojo IsVartotojo=new IsVartotojo("IsVartotojo",2,this.PId,1,LaukiantysResurso,Resursai,Procesai,"/Users/Julyte/Desktop/1.txt");
			IsVartotojo IsVartotojo2=new IsVartotojo("IsVartotojo",2,this.PId,1,LaukiantysResurso,Resursai,Procesai,"/Users/Julyte/Desktop/2.txt");
			ResursuDeskriptorius IsorAtmintis=new ResursuDeskriptorius("IsorAtmintis",1,this.PId,1,LaukiantysResurso,Resursai,Procesai);
			ResursuDeskriptorius SuperAtmintis=new ResursuDeskriptorius("SuperAtmintis",1,this.PId,1,LaukiantysResurso,Resursai,Procesai);
			ResursuDeskriptorius VartAtmintis=new ResursuDeskriptorius("VartAtmintis",1,this.PId,1,LaukiantysResurso,Resursai,Procesai);
			 /*------------------------------------------Procesai------------------------------------------------------------*/
			NiekoNeveikiu1 NiekoNeveikiu1=new NiekoNeveikiu1("NiekoNeveikiu1",0,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai);
			NiekoNeveikiu2 NiekoNeveikiu2=new NiekoNeveikiu2("NiekoNeveikiu2",0,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai);
			Read Read=new Read("Read",10,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali);
			JCL Jcl=new JCL("jcl",8,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali);
			PrintLines PrintLines=new PrintLines("PrintLines",9,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali);
			MainProc mainproc =new MainProc("mainproc",7,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali);
			Loader loader =new Loader("Loader",8,this.PId,Procesai,Planuoja,Resursai,LaukiantysResurso,Rveiksmai,Reali);

			 /*------------------------------------------Praso resurso OS darbo pabaiga------------------------------------------------------------*/
			this.PFinish=1; 
			Rveiksmai.prasyti(this.PId,"osDarboPabaiga");
				
		 }
		 }		 
	    }
	

}
