package planuojuSkirstau;

import sarasiukai.ProcesuSarasas;
import sarasiukai.ResursuSarasas;
import sarasiukai.VisuLaukianciuSarasas;


public class ResursuPaskirstytojas {
	public Planuotojas Planuoja;
	public ResursuSarasas Resursai;
	public ProcesuSarasas Procesai;
	public VisuLaukianciuSarasas LaukiantysResurso;
	
	
public ResursuPaskirstytojas(ProcesuSarasas procesai, ResursuSarasas resursai, Planuotojas planuoja, VisuLaukianciuSarasas laukiantys){
	Planuoja=planuoja;
	Resursai=resursai;
	Procesai=procesai;
	LaukiantysResurso=laukiantys;
}

public void Skirstau(int resursoNr, int LSarNr){
	System.out.println("Skirstau");
	if(Resursai.getNumeris(resursoNr).RUzimtumas.equals("Uzimtas")){
		Planuoja.planuok();
	} else {
		if(LaukiantysResurso.getNumeris(LSarNr).getDydis()!=0){
		LaukiantysResurso.getNumeris(LSarNr).getNumeris(0).GautiResursai.setElementas(Resursai.getNumeris(resursoNr)); // ideda i gautuju sarasa
		Resursai.getNumeris(resursoNr).setUzimtumas(2);
		LaukiantysResurso.getNumeris(LSarNr).getNumeris(0).ImkResursa();
		LaukiantysResurso.getNumeris(LSarNr).trink(0);
		Planuoja.planuok();
		} else {
		Planuoja.planuok();}
	}
	
	
	
}

}
