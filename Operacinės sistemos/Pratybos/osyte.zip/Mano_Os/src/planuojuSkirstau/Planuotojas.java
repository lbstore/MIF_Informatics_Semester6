package planuojuSkirstau;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import descriptoriai.ProcesuDeskriptorius;

import sarasiukai.ProcesuSarasas;

public class Planuotojas {
	public ProcesuSarasas Procesai;
	public ProcesuDeskriptorius EinamasisProcesas= new ProcesuDeskriptorius();
	int i;
	
	public Planuotojas(ProcesuSarasas procesai ){
		Procesai=procesai;
		EinamasisProcesas.setPasiruoses();
	}
	
	public void planuok() {
		System.gc();
		
		System.out.println("Planuotojas iskviestas");
		System.out.println();
		if (EinamasisProcesas.PState.equals("Vykdomas")){
			EinamasisProcesas.setPasiruoses();
		}
		for( i=0; i<=Procesai.getDydis()-1;i++){
			if (Procesai.getNumeris(i).PState.equals("Pasiruoses")){ // pereina per procesu sarasa ir ziuri kuris pasiruoses ta pirma ir ima
				perduoduValdyma(i);
				break;
			}
		}

		
	}

	public void perduoduValdyma(int i) { // cia jis perduoda valdyma kitam procesui ir priskiria jam  Vygdomas busena :}
		Object action = Procesai.getNumeris(i);
		Procesai.getNumeris(i).setVykdomas();
		EinamasisProcesas=Procesai.getNumeris(i);
		Method method = null;
		try {
			method = Procesai.getNumeris(i).getClass().getMethod("goGo");
		} catch (NoSuchMethodException e) { /* HTTP ERROR 404 */
		}

		try {
			method.invoke(action); // perduodam valdyma procesui kuris gavo procesoriu
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			throw new RuntimeException(e.getCause());
		}

		
	}
}
