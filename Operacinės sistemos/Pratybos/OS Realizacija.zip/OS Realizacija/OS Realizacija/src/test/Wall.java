/*
 * Wall.java
 *
 * Created on May 11, 2008, 5:33 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package test;

import java.io.Console;
import osrealizacija.*;

/**
 *
 * @author giedrius
 */
public class Wall extends Resource{
    
    
    /** Creates a new instance of Wall */
    public Wall() {
    }
    
    public String getID() {
        return "Wall";
    }
    
    private String wall;
    public void paint(String s) {
        wall+=s+"\n";
        System.out.println(s);
    }
    
    
}
