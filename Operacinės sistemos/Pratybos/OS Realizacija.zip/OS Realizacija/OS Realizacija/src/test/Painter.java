/*
 * Painter.java
 *
 * Created on May 11, 2008, 6:12 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package test;

import osrealizacija.*;

/**
 *
 * @author giedrius
 */
public class Painter extends osrealizacija.Process{
    private final static int STATE_START=1;
    private final static int STATE_WAIT=2;
     Wall w =null;
    
    /** Creates a new instance of Painter */
    public Painter(String des) {
        state = STATE_START;
        setDescription(des);
    }
    
   
    /** Creates a new instance of MainProc */
    

    public void run() {
       
        switch (state)
        {
            case STATE_START:                
                w = (Wall)Kernel.getInstance().getResource("Wall");
                if (w== null)return;
            case STATE_WAIT:
                state = STATE_WAIT;
                
                Pen p = (Pen)Kernel.getInstance().getResource("Pen");
                if (p == null) return;
                w.paint(getDescription()+ p.color+"\n");
                Kernel.getInstance().freeResource(p);
                Kernel.getInstance().freeResource(w);
                state = STATE_START;
                
        }
    }
    
}
