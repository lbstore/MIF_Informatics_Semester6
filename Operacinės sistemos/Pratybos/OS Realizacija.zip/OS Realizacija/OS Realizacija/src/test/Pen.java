/*
 * Pen.java
 *
 * Created on May 11, 2008, 6:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package test;

import osrealizacija.*;

/**
 *
 * @author giedrius
 */
public class Pen extends Resource{
    
    /** Creates a new instance of Pen */
    String color;
    public Pen(String color) {
        this.color = color;
    }

    public String getID() {
        return "Pen";
    }
    
}
