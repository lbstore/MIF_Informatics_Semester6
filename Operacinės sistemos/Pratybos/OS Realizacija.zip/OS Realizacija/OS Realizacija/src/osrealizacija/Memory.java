/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author Lukas
 */
public class Memory {
	private int[] data = new int[256*16]; //256 blokai po 16 zodziu
	public int getMemoryContents(int adress) {
		return data[adress];
	}

	public void setMemoryContents(int adress, int value) {
		data[adress]=value;

	}

}

