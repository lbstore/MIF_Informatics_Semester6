/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author Lukas
 */
public class Converter {

	// labai kreivas budas pavert musu ascii skaicius dvejetainius, kazkaip
	// veikia
	public static int AsciitoInt(int ascii) {
		String hex = Integer.toHexString(ascii);
                if (hex.length()%2 == 1 || hex.length()>8 || hex.length()==0)
                {
                    int u = 7;
                }
		while (hex.length() != 8)
			hex = "30" + hex;
		char c1 = (char) (int) Integer.decode("0x" + hex.substring(0, 2));
		//System.out.println(c1);
		char c2 = (char) (int) Integer.decode("0x" + hex.substring(2, 4));
		//System.out.println(c2);
		char c3 = (char) (int) Integer.decode("0x" + hex.substring(4, 6));
		//System.out.println(c3);
		char c4 = (char) (int) Integer.decode("0x" + hex.substring(6, 8));
		//System.out.println(c4);
		int r = Integer.parseInt("" + c1 + c2 + c3 + c4, 16);
		//System.out.println(r);
		return r;
	}

	// dar kreivesnis budas paverst is dvejetainiu skaicu i ascii, irgi veikia
	// turbut
	public static int InttoAscii(int ascii) {
		String hex = Integer.toHexString(ascii & 0xFFFF); //na tenka kartais ir ne savo bugus taisyt
		
		while (hex.length() != 4)
			hex = "0" + hex;
		char c1 = hex.charAt(0);
		char c2 = hex.charAt(1);
		char c3 = hex.charAt(2);
		char c4 = hex.charAt(3);
		int r = Integer.decode("0x" + Integer.toHexString((byte) c1)
				+ Integer.toHexString((byte) c2)
				+ Integer.toHexString((byte) c3)
				+ Integer.toHexString((byte) c4));
		//System.out.println(r);
		return r;
	}
	//musu formata pavercia i stringa
	public static String AsciitoString(int ascii) {
		String hex = Integer.toHexString(ascii);
		while (hex.length() != 8)
			hex = "0" + hex;
		char c1 = (char) (int) Integer.decode("0x" + hex.substring(0, 2));
		//System.out.println(c1);
		char c2 = (char) (int) Integer.decode("0x" + hex.substring(2, 4));
		//System.out.println(c2);
		char c3 = (char) (int) Integer.decode("0x" + hex.substring(4, 6));
		//System.out.println(c3);
		char c4 = (char) (int) Integer.decode("0x" + hex.substring(6, 8));
		//System.out.println(c4);
		String r = "" + c1 + c2 + c3 + c4;
		//System.out.println(r.length());
		return r;
	}
	public static int StringtoAscii(String ascii) {
		if (ascii.length()>4) throw new RuntimeException("Stringas turetu but 4 ilgio, ar jus norit int[]?");
		String Hex="0x";
		for (int i =0; i< ascii.length();i++)
		{
			String t = Integer.toHexString(ascii.charAt(i));
			if (t.length()>2)throw new RuntimeException("Stringe gali but tik acii charai");
			while (t.length()!=2)
				t = "0"+t;
			Hex+=t;
		}
		for (int i =ascii.length(); i<4 ;i++)
			Hex+="20"; //pridedam tarpu i gala?
		int r = Integer.decode(Hex);		
		//System.out.println(r);
		return r;
	}
	

}
