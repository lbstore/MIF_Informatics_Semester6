/*
 * Loader.java
 *
 * Created on May 13, 2008, 5:44 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package osrealizacija.procesai;

import java.util.logging.Level;
import java.util.logging.Logger;
import osrealizacija.IODevice;
import osrealizacija.Kernel;
import osrealizacija.Memory;
import osrealizacija.resursai.KanaluIrenginys;
import osrealizacija.resursai.LeidimasKraut;
import osrealizacija.resursai.LoaderDarboPabaiga;

/**
 *
 * @author giedrius
 */
public class Loader extends osrealizacija.Process {

    public static final int STATE_START = 1;
    public static final int STATE_HAVE_LEIDIMAS = 2;
    public static final int STATE_WAIT_CH_DEVICE = 3;
    LeidimasKraut lk = null;
    KanaluIrenginys ki = null;

    /** Creates a new instance of Loader */
    public Loader() {
        state = STATE_START;
    }

    public void run() {
        try {
            switch (state) {
                case STATE_START:
                    if ((lk = (LeidimasKraut) osrealizacija.Kernel.getInstance().getResource("LeidimasKraut")) == null) {
                        return;
                    }
                case STATE_HAVE_LEIDIMAS:
                    state = STATE_HAVE_LEIDIMAS;
                    if (lk.isFork()) {
                        Memory mem = Kernel.getInstance().getM();
                        for (int i = 0; i < 16; i++) {
                            for (int j = 0; j < 16; j++) {
                                int c = mem.getMemoryContents((lk.getSourceBlocks()[i] * 16) + j);
                                mem.setMemoryContents((lk.getDestinationBlocks()[i] * 16) + j, c);
                            }
                        }
                        LoaderDarboPabaiga ldp = new LoaderDarboPabaiga();
                        Kernel.getInstance().registerResuorce(ldp);
                        Kernel.getInstance().freeResource(ldp);
                        Kernel.getInstance().destroyResource(lk);
                        state = STATE_START;
                        return;
                    }
                case STATE_WAIT_CH_DEVICE:
                    state = STATE_WAIT_CH_DEVICE;
                    if ((ki = (KanaluIrenginys) osrealizacija.Kernel.getInstance().getResource("KanaluIrenginys")) == null) {
                        return;
                    }
                    int start = lk.getSource();
                    start /= 4;
                    for (int i = 0; i < 16; i++) {
                        ki.getCd().read(IODevice.HDD, start, 16, lk.getDestinationBlocks()[i] * 16);
                        //BIG PROBLEM!!! HOUSTON WE HAVE A PROBLEM!!!
                        start += 16; //gal 4?
                    }
                    //nuskaitom is disko
                    //dar kazka darom
                    //problemos su loader darbo pabaiga, etc
                    Thread.sleep(10000);
                    state = STATE_START; //griztam
                    Kernel.getInstance().freeResource(ki);
                    LoaderDarboPabaiga ldp = new LoaderDarboPabaiga();
                    Kernel.getInstance().registerResuorce(ldp);
                    Kernel.getInstance().freeResource(ldp);
                    Kernel.getInstance().destroyResource(lk);
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Loader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
