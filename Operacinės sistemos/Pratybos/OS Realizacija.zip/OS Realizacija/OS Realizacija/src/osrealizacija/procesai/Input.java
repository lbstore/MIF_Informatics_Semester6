/*
 * Read.java
 *
 * Created on May 13, 2008, 5:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package osrealizacija.procesai;

import osrealizacija.Kernel;
import osrealizacija.Keyboard;
import osrealizacija.resursai.*;

/**
 *
 * @author giedrius
 */
public class Input extends osrealizacija.Process {

    public static final int STATE_START = 1;
    private LaisvasKanaluIrenginys lki;
    String text = "";

    public Input() {
        state = STATE_START;
    }

    public void run() {
        switch (state) {
            case STATE_START:
                if (Keyboard.hasNewSymbol) {
                    Keyboard.hasNewSymbol = false;
                    if (isChange(Keyboard.newSymbol)) {
                        KonsolesKeitimas kk = new KonsolesKeitimas(true, null);
                        Kernel.getInstance().registerResuorce(kk);
                        Kernel.getInstance().freeResource(kk);
                    } else {
                        text += Keyboard.newSymbol;
                    }
                    if (Keyboard.newSymbol == '\n') {
                        if (text.length() > 1) {
                            Eilute e = new Eilute(text.substring(0, text.length() - 1), Kernel.getInstance().getCurrentconsole());
                            Kernel.getInstance().registerResuorce(e);
                            Kernel.getInstance().freeResource(e);
                            text = "";
                        }
                        if (text.equals("\n")) text ="";
                    }
                }
                if (Kernel.getInstance().getCd().getIORegister() == 0) {
                    if ((lki = (LaisvasKanaluIrenginys) osrealizacija.Kernel.getInstance().getResource("LaisvasKanaluIrenginys")) != null) {
                        Kernel.getInstance().freeResource(lki);
                    }
                    else
                    {
                    LaisvasKanaluIrenginys lki = new LaisvasKanaluIrenginys();
                    Kernel.getInstance().registerResuorce(lki);
                    Kernel.getInstance().freeResource(lki);
                    }
                }

        }
    }

    public boolean isChange(char c) {

        return c == '`';
    //TODO sutvarkyti sita reik
    }
}
