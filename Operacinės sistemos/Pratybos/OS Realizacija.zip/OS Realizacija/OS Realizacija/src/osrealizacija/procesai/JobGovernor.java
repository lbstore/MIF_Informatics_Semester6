/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package osrealizacija.procesai;

import osrealizacija.Converter;
import osrealizacija.IODevice;
import osrealizacija.Kernel;
import osrealizacija.resursai.*;

/**
 *
 * @author Lukas
 */
public class JobGovernor extends osrealizacija.Process {

    public static final int STATE_START = 1;
    public static final int STATE_WAIT_LDP = 2;
    public static final int STATE_HAS_LDP = 3;
    public static final int STATE_WAIT_FROM_INTERRUPT = 4;
    public static final int STATE_WAIT_EILUTE = 5;
    
    private Memory mem;
    private LeidimasKraut lk;
    private LoaderDarboPabaiga ldp;
    private FromInterrupt fi;
    private Eilute eil;
    private VM vm = null;
    private boolean fromFork=false;
    private VirtualMachine.Registrai r;
    private VirtualMachine.VM vm2;
    private osrealizacija.procesai.VM vmp;

    
    
    public JobGovernor(int source)
    {
        state=STATE_START;
        lk = new LeidimasKraut(source);
        
        
    }
    public JobGovernor(int[] blocks, osrealizacija.procesai.VM vm)
    {
        vmp = vm;
        state=STATE_START;
        lk = new LeidimasKraut(blocks);
        fromFork = true;
        vm2 = vm.vm;
        r = vm.r;
        
    }
    @Override
    public void run() {
        switch (state) {
            case STATE_START:
                if ((mem = (Memory) osrealizacija.Kernel.getInstance().getResource("Memory")) == null) {
                    return;
                }
                lk.setDestinationBlocks(mem.blocks);
                Kernel.getInstance().registerResuorce(lk);
                Kernel.getInstance().freeResource(lk);
            case STATE_WAIT_LDP:
                state = STATE_WAIT_LDP;
                if ((ldp = (LoaderDarboPabaiga) osrealizacija.Kernel.getInstance().getResource("LoaderDarboPabaiga")) == null) {
                    return;
                }
            case STATE_HAS_LDP:
                state = STATE_HAS_LDP;
                
                osrealizacija.Memory m= Kernel.getInstance().getM();
                for (int i =0; i<16; i++)
                {
                    m.setMemoryContents(mem.blocks[16]*16+i, Converter.InttoAscii( mem.blocks[i]));
                }
                String ptr = "0"+Integer.toHexString(mem.blocks[16])+"F";
               if (fromFork) 
               {
                   vm = new VM( vm2,r);
                   vm.vm.changeCF(false);
                   vmp.vm.changeCF(true);
                   Kernel.getInstance().unblockProcess(vmp);
               } else
               {
                    vm = new VM(new VirtualMachine.VM(),new VirtualMachine.Registrai());
               vm.vm.setIP(Converter.InttoAscii(0));
		vm.r.setIOI((byte)Converter.InttoAscii(0));
		vm.r.setSI((byte)Converter.InttoAscii(0));
		vm.r.setPI((byte)Converter.InttoAscii(0));
		vm.r.setTI((byte)255);
               }
                vm.vm.setPTR(Converter.StringtoAscii(ptr));
                
               Switch.addConsole(this);
                Kernel.getInstance().addProcess(vm);
            case STATE_WAIT_FROM_INTERRUPT:
                state = STATE_WAIT_FROM_INTERRUPT;
                if ((fi = (FromInterrupt) osrealizacija.Kernel.getInstance().getResource("FromInterrupt")) == null) {
                    return;
                }
                if (fi.getP()!=this.vm){
                    Kernel.getInstance().freeResource(fi);
                    return;
                }
                if (fi.isIOI()) {
                    if (fi.isInput()) {
                        //read zemiau
                    } else {
                        //printina (raso i buferi)
                        
                        String command=Converter.AsciitoString( Kernel.getInstance().getPd().getMemoryContents(vm.vm.getPTR(),Converter.InttoAscii( Converter.AsciitoInt( vm.vm.getIP())-1))); //nuskaito komanda
			int adress=Integer.parseInt(command.substring(2,4), 16);
                        buf += formatString(IODevice.Monitor,vm.vm,adress)+"\n";
                        
                        KonsolesKeitimas kk = new KonsolesKeitimas(false, this);//reikia info

                        Kernel.getInstance().registerResuorce(kk);
                        Kernel.getInstance().freeResource(kk);
                        
                        Kernel.getInstance().unblockProcess(vm);
                        return;
                    }
                } else if (fi.isFork()) {
                    ProgramosRes pr = new ProgramosRes(true, 0, mem.blocks,vm);//ka mes forkinam? kur dabar issaugoje sita programa
                    Kernel.getInstance().registerResuorce(pr);
                    Kernel.getInstance().freeResource(pr);
                    //Kernel.getInstance().unblockProcess(vm); Atblokuos naujas jg
                    return;
                } else {
                    Kernel.getInstance().unblockProcess(vm);
                    Kernel.getInstance().destroyProcess(vm);
                    //atlaisvina atminti
                    ProgramosRes pr = new ProgramosRes(true, this);
                    Kernel.getInstance().registerResuorce(pr);
                    Kernel.getInstance().freeResource(pr);
                    Kernel.getInstance().blockProcess(this);
                    
                    return;
                }
            case STATE_WAIT_EILUTE:
                state = STATE_WAIT_EILUTE;
                if ((eil = (Eilute) osrealizacija.Kernel.getInstance().getResource("Eilute")) == null) {
                    return;
                }
                if (eil.getP() !=this)
                {
                    Kernel.getInstance().freeResource(eil);
                    return;
                }
                String command = Converter.AsciitoString(Kernel.getInstance().getPd().getMemoryContents(vm.vm.getPTR(), Converter.InttoAscii(Converter.AsciitoInt(vm.vm.getIP()) - 1))); //nuskaito komanda

                int adress = Integer.parseInt(command.substring(2, 4), 16);		//cia blogai?
                //BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

//			try {
                //s=stdin.readLine();
                //	s = JOptionPane.showInputDialog("Iveskite teksta");
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
                String s = eil.getEilute();
                buf+=s+"\n";
                s = s + '\0';//ar pavers i ascii?

                for (; s.length() >= 4;) {
                    //String st = s.substring(0, 4);
                    Kernel.getInstance().getPd().setMemoryContents(vm.vm.getPTR(), Converter.InttoAscii(adress), Converter.StringtoAscii(s.substring(0, 4)));

                    s = s.substring(4);
                    adress++;
                }
                if (s.length() != 0) {
                    Kernel.getInstance().getPd().setMemoryContents(vm.vm.getPTR(), Converter.InttoAscii(adress), Converter.StringtoAscii(s));


                }
                Kernel.getInstance().unblockProcess(vm);
                state = STATE_WAIT_FROM_INTERRUPT;


        }
    }

    public String getBuf() {
        return buf;
    }
    protected String formatString(IODevice dev,VirtualMachine.VM vm, int start)
	{
		if (dev.equals(IODevice.Monitor)) 
		{	
			String txt="";
			String tmp;
			int i=start;
			for(;;i++)	//i++ 
			{
				tmp=Converter.AsciitoString(Kernel.getInstance().getPd().getMemoryContents(vm.getPTR(), Converter.InttoAscii(i)));//nuskaito
				if (tmp.charAt(0)!='\0'){
					txt=txt+tmp.charAt(0);
				} else {break;}
				if (tmp.charAt(1)!='\0'){
					txt=txt+tmp.charAt(1);
				} else {break;}
				if (tmp.charAt(2)!='\0'){
					txt=txt+tmp.charAt(2);
				} else {break;}
				if (tmp.charAt(3)!='\0'){
					txt=txt+tmp.charAt(3);
				} else {break;}
				
			}
			return txt;
			
		}
		throw new RuntimeException("Galima rasyt tik i monitoriu");
	}

}
