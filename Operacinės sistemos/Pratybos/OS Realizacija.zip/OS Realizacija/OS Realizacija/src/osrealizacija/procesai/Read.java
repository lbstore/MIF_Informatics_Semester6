/*
 * Read.java
 *
 * Created on May 13, 2008, 5:20 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija.procesai;

import java.awt.image.Kernel;
import osrealizacija.Converter;
import osrealizacija.IODevice;
import osrealizacija.resursai.*;

/**
 *
 * @author giedrius
 */
public class Read extends osrealizacija.Process{
    public static final int STATE_START=1;
    public static final int STATE_HAVE_LINE=2;
    public static final int STATE_WAIT_CH=3;
    public static final int STATE_WAIT_LKI=4;
    public Eilute e;
    private LaisvasKanaluIrenginys lki;
    private KanaluIrenginys ki;
    private int[] ft=null;
    /** Creates a new instance of Read */
    public Read() {
        state = STATE_START;
        Switch.addConsole(this);
    }

    public void run() {
        switch (state)
        {
            case STATE_START:
                if ( (e= (Eilute)osrealizacija.Kernel.getInstance().getResource("Eilute")) == null)
                {
                return;   
                }
                if (e.getP() !=this)
                {
                    osrealizacija.Kernel.getInstance().freeResource(e);
                    return;
                }
            case STATE_HAVE_LINE:
                state=STATE_HAVE_LINE;
                buf+=e.getEilute()+"\n";
                if (e.getEilute().equalsIgnoreCase("quit"))
                {
                    EndOfTheWorld end = new EndOfTheWorld();
                    osrealizacija.Kernel.getInstance().registerResuorce(end);
                    osrealizacija.Kernel.getInstance().freeResource(end);
                    state = STATE_START;
                    return;
                }
            case STATE_WAIT_CH:
                state=STATE_WAIT_CH;
                 if ((ki = (KanaluIrenginys) osrealizacija.Kernel.getInstance().getResource("KanaluIrenginys")) == null) {
                    return;
                }
                ft = ki.getCd().read(IODevice.HDD, 4, 160);
            case STATE_WAIT_LKI:
                state = STATE_WAIT_LKI;
                if ((lki = (LaisvasKanaluIrenginys) osrealizacija.Kernel.getInstance().getResource("LaisvasKanaluIrenginys")) == null) {
                    return;
                }
                osrealizacija.Kernel.getInstance().destroyResource(lki);
                int place=0;
                int size =0;
                osrealizacija.Kernel.getInstance().freeResource(ki);
                for (int i = 0; i<10;i++)
                {
                    String name = Converter.AsciitoString(ft[i*4])+ Converter.AsciitoString(ft[i*4+1]);
                    if (e.getEilute().equals(name))
                    {
                    place = ft[i*4+2];
                     size = ft[i*4+3];
                    }
                }
                if (place!=0)
                {
                    ProgramosRes pr = new ProgramosRes(false, place,null,null);
                    osrealizacija.Kernel.getInstance().registerResuorce(pr);
                    osrealizacija.Kernel.getInstance().freeResource(pr);
                }
                state = STATE_START;
                return;
                
        }
    }
    
}
