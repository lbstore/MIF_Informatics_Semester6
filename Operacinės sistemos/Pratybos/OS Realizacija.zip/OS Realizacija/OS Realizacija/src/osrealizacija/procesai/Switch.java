/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.procesai;

import java.util.ArrayList;
import java.util.HashMap;

import osrealizacija.Kernel;
import osrealizacija.resursai.*;

/**
 *
 * @author Lukas
 */
public class Switch extends osrealizacija.Process {
private static ArrayList<osrealizacija.Process> hm = new ArrayList<osrealizacija.Process>();
    public static final int STATE_START=1;
    public static final int STATE_WAIT_CH_DEVICE=2;
    public static final int STATE_WAIT_CH_FREE=3;
    public static final int STATE_HAS_CH_DEVICE=4;
    
    private KonsolesKeitimas kk;
    private KanaluIrenginys ch;
    private LaisvasKanaluIrenginys lki;
    private static osrealizacija.Process currentProcess;
    public Switch(){
        state=STATE_START;
    }
            public void run() {
        switch (state)
        {
            case STATE_START:
               if ( (kk= (KonsolesKeitimas)osrealizacija.Kernel.getInstance().getResource("KonsolesKeitimas")) == null)
                {
                    return;
                }  
                 if (currentProcess == kk.getCallingProcess() || kk.isChange())
                {
                    
                }else {
                   Kernel.getInstance().destroyResource(kk);
                   state = STATE_START;
                   return;
                }
              
            case STATE_WAIT_CH_DEVICE:
                state = STATE_WAIT_CH_DEVICE;
                if ( (ch= (KanaluIrenginys)osrealizacija.Kernel.getInstance().getResource("KanaluIrenginys")) == null)
                {
                    return;
                } 
            case STATE_HAS_CH_DEVICE:
                state = STATE_HAS_CH_DEVICE;
               //perduoda info CH !!!!!!!!!!!
                if (kk.isChange())
               {
                   if (hm.indexOf(currentProcess) == hm.size()-1) 
                   {
                       currentProcess = hm.get(0);
                   }
                   else
                   {
                   currentProcess = hm.get(hm.indexOf(currentProcess)+1);
                   }
                   Kernel.getInstance().setCurrentconsole(currentProcess);
               }
                ch.getCd().write(currentProcess.getBuf());
            case STATE_WAIT_CH_FREE:
                state = STATE_WAIT_CH_FREE;
                 if ( (lki= (LaisvasKanaluIrenginys)osrealizacija.Kernel.getInstance().getResource("LaisvasKanaluIrenginys")) == null)
                {
                    return;
                } 
                Kernel.getInstance().freeResource(ch);
                Kernel.getInstance().destroyResource(lki);
                state = STATE_START;
            
        
        }
    }
    public static void addConsole(osrealizacija.Process p){
        
        if (hm.size()==0)
        {
            currentProcess = p;
        }
        hm.add(p);
        Kernel.getInstance().setCurrentconsole(currentProcess);
    }

    public static void removeConsole (osrealizacija.Process p){
        hm.remove(p);
    }
}
