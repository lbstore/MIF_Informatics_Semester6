/*
 * MainProc.java
 *
 * Created on May 11, 2008, 6:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija.procesai;

import osrealizacija.*;
import osrealizacija.resursai.ProgramosRes;
import test.Painter;
import test.Pen;
import test.Wall;

/**
 *
 * @author giedrius
 */
public class MainProc extends osrealizacija.Process{
    public static final int STATE_START = 1;
    public static final int STATE_WAIT_END = 2;
    private ProgramosRes pr;
    public  MainProc()
    {
    state = STATE_START;
    }
    
    public void run() {
        switch (state)
        {
            case STATE_START:
                if (( pr= (ProgramosRes) osrealizacija.Kernel.getInstance().getResource("ProgramosRes")) == null) {
                    return;}
                if (pr.isNaikinti()){
                    Kernel.getInstance().unblockProcess(pr.getProcessToDestroy());
                    Kernel.getInstance().destroyProcess(pr.getProcessToDestroy());
                    return;
                }
                
                if(!pr.isFork())
                {JobGovernor jg = new JobGovernor(pr.getSource());
                Kernel.getInstance().addProcess(jg);
                }
                else
                {
                    JobGovernor jg = new JobGovernor(pr.getBlocks(),pr.getVm());
                    Kernel.getInstance().addProcess(jg);
                }
        }
        
        
    }
    
    
    
}
