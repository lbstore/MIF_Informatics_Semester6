/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package osrealizacija.procesai;

import VirtualMachine.*;
import java.util.*;
import osrealizacija.*;
import osrealizacija.resursai.Pertraukimas;

/**
 *
 * @author Lukas
 */
public class VM extends osrealizacija.Process {

    public static final int STATE_START = 1;

    /**
     * @param args
     */
    public VM(VirtualMachine.VM vm, Registrai r)
    {
        state=STATE_START;
        this.vm = (VirtualMachine.VM)vm.Clone();
        this.r = new Registrai();
        this.r.setIOI(r.getIOI());
        this.r.setPI(r.getPI());
        this.r.setSI(r.getSI());
        this.r.setTI(r.getTI());
        
        
        
        commands = new HashMap<String, CommandInterface>();
        interrupthandlers = new HashMap<InterruptType, InterruptHandler>();
        
        pd = Kernel.getInstance().getPd();
        //cd = new ;
        //cd = new ChannelingDeviceGui(m,pd);
        //os = new OS();
       Add add_ = new Add();
		commands.put(add_.getOpcode(), (CommandInterface)add_);
		Cmp cmp_ = new Cmp();
		commands.put(cmp_.getOpcode(), cmp_);
		Div div_ = new Div();
		commands.put(div_.getOpcode(), div_);
		Jmp jmp_ = new Jmp();
		commands.put(jmp_.getOpcode(), jmp_);
		Load load_ = new Load();
		commands.put(load_.getOpcode(), load_);
		Mod mod_ = new Mod();
		commands.put(mod_.getOpcode(), mod_);
		Mul mul_ = new Mul();
		commands.put(mul_.getOpcode(), mul_);
		Print print_ = new Print();
		commands.put(print_.getOpcode(), print_);
		Put put_ = new Put();
		commands.put(put_.getOpcode(), put_);
		Quit quit_ = new Quit();
		commands.put(quit_.getOpcode(), quit_);
                Fork fork_ = new Fork();
		commands.put(fork_.getOpcode(), fork_);
		VirtualMachine.Read read_ = new VirtualMachine.Read();
		commands.put(read_.getOpcode(), read_);
		Sub sub_ = new Sub();
		commands.put(sub_.getOpcode(), sub_);

    }
    @Override
    public void run() {
        // TODO Auto-generated method stub
        switch (state) {
            case STATE_START:
                 r.setSI((byte)Converter.InttoAscii(0));
                 r.setPI((byte)Converter.InttoAscii(0));
                 r.setIOI((byte)Converter.InttoAscii(0));
                 r.setTI((byte)Converter.InttoAscii(0));
                Execute();
                if (r.getSI() != (byte) Converter.InttoAscii(0)) {
                    Pertraukimas p = new Pertraukimas();
                    p.setIt(InterruptType.SI);
                    p.setVm(this);
                    Kernel.getInstance().registerResuorce(p);
                    Kernel.getInstance().freeResource(p);
                   Kernel.getInstance().blockProcess(this);

                }
                if (r.getPI() != (byte) Converter.InttoAscii(0)) {
                    Pertraukimas p = new Pertraukimas();
                    p.setIt(InterruptType.PI);
                    p.setVm(this);
                    Kernel.getInstance().registerResuorce(p);
                    Kernel.getInstance().freeResource(p);
                    Kernel.getInstance().blockProcess(this);
                }
                if (r.getIOI() != (byte) Converter.InttoAscii(0)) {
                   Pertraukimas p = new Pertraukimas();
                    p.setIt(InterruptType.IOI);
                    p.setVm(this);
                    Kernel.getInstance().registerResuorce(p);
                    Kernel.getInstance().freeResource(p);
                    Kernel.getInstance().blockProcess(this);

                }
                if (r.getTI() == 0) {
                    Pertraukimas p = new Pertraukimas();
                    p.setIt(InterruptType.TI);
                    p.setVm(this);
                    Kernel.getInstance().registerResuorce(p);
                    Kernel.getInstance().freeResource(p);
                   Kernel.getInstance().blockProcess(this);
                }
                
//bugas su keliain interuptais
        }

    //while (rm.isAlive()) //sito dar nera, bet kazka tokio reik daryt
    //	rm.Execute();

    }
    private int count = 0;
    private boolean alive = false;
    public VirtualMachine.VM vm;
    public Registrai r;
    //private ChannelingDevice cd;
    public PagingDevice pd;
    private Map<String, CommandInterface> commands;
    private Map<InterruptType, InterruptHandler> interrupthandlers;

    public void AddinterruptHandler(InterruptHandler ih) {
        interrupthandlers.put(ih.getIT(), ih);

    }

    public void Execute() {
        String instruction = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
        count++;
        CommandInterface c;
        if ( (c = commands.get(instruction)) != null) {
            c.Execute(vm, r, pd);
        } else if ( (c = commands.get(instruction.substring(0, 2))) != null) {
            c.Execute(vm, r, pd);
        } else if ( (c = commands.get(instruction.substring(0, 1))) != null) {
            c.Execute(vm, r, pd);
        } else {
            throw new RuntimeException("Ner tokios komandos "+instruction);
        }
        r.setTI((byte) (r.getTI() - 1));//nah castas + makalyne, reiktu pergalvot?

        checkInterrupts();

    }

    public void Init() {
               // setAlive(true);
       // os.Start(vm, r, cd, m, this);
    }
    //patikrina ar nekilo pertraukimas + apdoroja
    //gal but reik pakeist eile

    private void checkInterrupts() {
//		if (r.getSI()!=(byte)Converter.InttoAscii(0))
//		{
//			interrupthandlers.get(InterruptType.SI).Handle(vm, r, pd, cd, this);
//		}
//		if (r.getPI()!=(byte)Converter.InttoAscii(0))
//		{
//			interrupthandlers.get(InterruptType.PI).Handle(vm, r, pd, cd, this);
//		}
//		if (r.getIOI()!=(byte)Converter.InttoAscii(0))
//		{
//			interrupthandlers.get(InterruptType.IOI).Handle(vm, r, pd, cd, this);
//		}
//		if (r.getTI()==0)
//		{
//			interrupthandlers.get(InterruptType.TI).Handle(vm, r, pd, cd, this);
//		}
    }

    
}

