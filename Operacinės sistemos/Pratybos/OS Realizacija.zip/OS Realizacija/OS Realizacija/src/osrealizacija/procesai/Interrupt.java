/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.procesai;
import osrealizacija.*;
import VirtualMachine.InterruptType; 

import osrealizacija.Converter;
import osrealizacija.resursai.*;

/**
 *
 * @author Lukas
 */
public class Interrupt extends osrealizacija.Process{
    public static final int STATE_START=1;
    public static final int STATE_HAS_INT=2;
    public static final int STATE_HAS_LDP=3;
    public static final int STATE_WAIT_FROM_INTERRUPT=4;
    public static final int STATE_WAIT_EILUTE=5;
    
    private Pertraukimas pertr;
    public Interrupt(){
        state=STATE_START;
    }
    @Override
    public void run() {
        switch(state){
            case STATE_START:
                if ( (pertr= (Pertraukimas)osrealizacija.Kernel.getInstance().getResource("Pertraukimas")) == null)
                {
                    return;
                }
                boolean IOI= false;
                boolean input=false;
                boolean fork = false; //sutvarkyti fork !!!!!!!!!!!!!!11
                switch(pertr.getIt())
                {
                    case IOI:
                        IOI = true;
                        break;
                    case SI:
                        if (Converter.AsciitoInt(pertr.getVm().r.getSI())==1);
                        if (Converter.AsciitoInt(pertr.getVm().r.getSI())==2) IOI=true;
                        if (Converter.AsciitoInt(pertr.getVm().r.getSI())==3) {IOI= true; input = true;}
                        if (Converter.AsciitoInt(pertr.getVm().r.getSI())==4) fork = true;
                        break;
                    case PI:
                        break;      
                }
                FromInterrupt fi = new FromInterrupt(fork, input, IOI,pertr.getVm());
                Kernel.getInstance().registerResuorce(fi);
                Kernel.getInstance().freeResource(fi);
                
                
            
        }
    }

}
