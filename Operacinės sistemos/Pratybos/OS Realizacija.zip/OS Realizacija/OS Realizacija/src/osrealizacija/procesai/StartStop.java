/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.procesai;

import osrealizacija.Kernel;
import osrealizacija.resursai.EndOfTheWorld;
import osrealizacija.resursai.KanaluIrenginys;

/**
 *
 * @author Lukas
 */
public class StartStop extends osrealizacija.Process{

    public static final int STATE_START=1;
    public static final int STATE_WAIT=2;
    EndOfTheWorld eotw;
    public StartStop(){
        state=STATE_START;
    }
    @Override
    public void run() {
        switch (state){
            case STATE_START:
                Kernel.getInstance().addProcess(new Input());
                Kernel.getInstance().addProcess(new Interrupt());
                Kernel.getInstance().addProcess(new Read());
                Kernel.getInstance().addProcess(new MainProc());
                Kernel.getInstance().addProcess(new Switch());
                Kernel.getInstance().addProcess(new Loader());
                KanaluIrenginys ki=new KanaluIrenginys();
                Kernel.getInstance().registerResuorce(ki);
                Kernel.getInstance().freeResource(ki);
                
            case STATE_WAIT:
                state=STATE_WAIT;
                if ( (eotw= (EndOfTheWorld)osrealizacija.Kernel.getInstance().getResource("EndOfTheWorld")) == null)
                {
                    return;
                } 
                Kernel.getInstance().setIsAlive(false);
        }
    }
    
    

}
