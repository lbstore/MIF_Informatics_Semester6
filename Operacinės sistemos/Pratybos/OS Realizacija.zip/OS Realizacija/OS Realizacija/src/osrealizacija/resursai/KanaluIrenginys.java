/*
 * KanaluIrenginys.java
 *
 * Created on May 13, 2008, 5:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija.resursai;

import osrealizacija.ChannelingDevice;
import osrealizacija.Kernel;
import osrealizacija.Resource;

/**
 *
 * @author giedrius
 */
public class KanaluIrenginys extends Resource{
    
    /** Creates a new instance of KanaluIrenginys */
    private osrealizacija.ChannelingDevice cd; 
    public KanaluIrenginys() {
        cd = Kernel.getInstance().getCd();
    }
    //sugalvot reiktu kaip cia kas :)

    public String getID() {
        return "KanaluIrenginys";
    }

    public

    /** Creates a new instance of KanaluIrenginys */
    osrealizacija.ChannelingDevice getCd() {
        return cd;
    }
    
}
