/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.resursai;

/**
 *
 * @author Lukas
 */
public class LaisvasKanaluIrenginys extends osrealizacija.Resource {

    @Override
    public String getID() {
        return "LaisvasKanaluIrenginys";
    }

}
