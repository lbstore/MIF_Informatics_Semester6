/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.resursai;

import VirtualMachine.InterruptType;
import osrealizacija.procesai.VM;

/**
 *
 * @author Lukas
 */

public class Pertraukimas extends osrealizacija.Resource{
    private InterruptType it;
    private VM vm;
    
    @Override
    public String getID() {
        return "Pertraukimas";
    }

    public InterruptType getIt() {
        return it;
    }

    public void setIt(InterruptType it) {
        this.it = it;
    }

    public VM getVm() {
        return vm;
    }

    public void setVm(VM vm) {
        this.vm = vm;
    }
    
    

}
