/*
 * EndOfTheWorld.java
 *
 * Created on May 13, 2008, 5:26 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija.resursai;

import osrealizacija.Resource;

/**
 *
 * @author giedrius
 */
public class EndOfTheWorld extends Resource{
    
    /** Creates a new instance of EndOfTheWorld */
    public EndOfTheWorld() {
    }

    public String getID() {
        return "EndOfTheWorld";
    }
    
}
