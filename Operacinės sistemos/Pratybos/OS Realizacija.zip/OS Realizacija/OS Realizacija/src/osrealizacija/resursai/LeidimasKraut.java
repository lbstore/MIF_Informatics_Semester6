/*
 * LeidimasKraut.java
 *
 * Created on May 13, 2008, 5:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija.resursai;

import osrealizacija.Resource;

/**
 *
 * @author giedrius
 */
public class LeidimasKraut extends Resource{
    
    /** Creates a new instance of LeidimasKraut */
    private boolean fork;
    private int source;
    private int[] sourceBlocks;//naudotinas tik jei fork
    private int[] destinationBlocks;
    public LeidimasKraut(int source) {
        fork = false;
        this.source = source;
        
    }
    public LeidimasKraut(int [] blocks)
    {
        fork = true;
        this.sourceBlocks = blocks;
    }

    public String getID() {
        return "LeidimasKraut";
    }

    public boolean isFork() {
        return fork;
    }

    public int getSource() {
        return source;
    }

    public int[] getSourceBlocks() {
        return sourceBlocks;
    }

    public int[] getDestinationBlocks() {
        return destinationBlocks;
    }

    public void setDestinationBlocks(int[] destinationBlocks) {
        this.destinationBlocks = destinationBlocks;
    }
    
}
