/*
 * Eilute.java
 *
 * Created on May 13, 2008, 5:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija.resursai;

import osrealizacija.Resource;

/**
 *
 * @author giedrius
 */
public class Eilute  extends Resource{
    private String eilute;
    
    /** Creates a new instance of Eilute */
    private osrealizacija.Process p;
    public Eilute(String s, osrealizacija.Process targetP) {
        eilute = s;
        p = targetP;
    }
    

    public String getID() {
        return "Eilute";
    }

    public String getEilute() {
        return eilute;
    }

    public osrealizacija.Process getP() {
        return p;
    }
    
}
