/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package osrealizacija.resursai;

/**
 *
 * @author Lukas
 */
public class ProgramosRes extends osrealizacija.Resource {

    private boolean fork;
    private int source;
    private int[] blocks;
    private osrealizacija.procesai.VM vm;
    private boolean naikinti = false;
    private osrealizacija.Process processToDestroy;

    public String getID() {
        return "ProgramosRes";
    }

    public ProgramosRes(boolean fork, int source, int[] blocks, osrealizacija.procesai.VM vm) {
        this.fork = fork;
        this.blocks = blocks;
        this.source = source;
        this.vm = vm;
    }

    public ProgramosRes(boolean naikinti, osrealizacija.Process processToDestroy) {
        this.naikinti = naikinti;
        this.processToDestroy = processToDestroy;
    }

    public boolean isFork() {
        return fork;
    }

    public int getSource() {
        return source;
    }

    public int[] getBlocks() {
        return blocks;
    }

    public boolean isNaikinti() {
        return naikinti;
    }

    public osrealizacija.Process getProcessToDestroy() {
        return processToDestroy;
    }

    public osrealizacija.procesai.VM getVm() {
        return vm;
    }
}
