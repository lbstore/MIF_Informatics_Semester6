/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.resursai;

/**
 *
 * @author Lukas
 */
public class Memory extends osrealizacija.Resource{
public int[] blocks;
    public String getID() {
        return("Memory");
    }
    public Memory(int[] blocks)
    {
        this.blocks = blocks;
    }

}
