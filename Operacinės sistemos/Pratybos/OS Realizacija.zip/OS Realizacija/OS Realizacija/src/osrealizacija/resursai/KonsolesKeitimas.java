/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.resursai;

/**
 *
 * @author Lukas
 */
public class KonsolesKeitimas extends osrealizacija.Resource {

    @Override
    public String getID() {
        return "KonsolesKeitimas";
    }
    private osrealizacija.Process callingProcess;
    private boolean change;
    public KonsolesKeitimas(boolean change, osrealizacija.Process callingProc){
        this.change=change;
        this.callingProcess=callingProc;
      
    }

    public osrealizacija.Process getCallingProcess() {
        return callingProcess;
    }

    public boolean isChange() {
        return change;
    }
    

}
