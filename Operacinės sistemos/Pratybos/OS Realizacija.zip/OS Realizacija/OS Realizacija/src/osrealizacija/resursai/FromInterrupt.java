/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija.resursai;

/**
 *
 * @author Lukas
 */
public class FromInterrupt extends osrealizacija.Resource {

    @Override
    public String getID() {
        return "FromInterrupt";
    }
    private boolean IOI;
    private boolean fork;
    private boolean input;
    private osrealizacija.Process p;
    public FromInterrupt(boolean fork,boolean input, boolean IOI, osrealizacija.Process p )
    {
        this.IOI = IOI;
        this.input = input;
        this.fork = fork;
        this.p=p;
    }
    
    public boolean isIOI(){
        return IOI; //reiks tvarkyt
    }
    public boolean isInput()
    {
        return input; //reiks tvarkyt
    }
    
   public boolean isFork()
   {
       return fork; //reiks tvarkyti
   }

    public osrealizacija.Process getP() {
        return p;
    }

}
