/*
 * Magic.java
 *
 * Created on May 13, 2008, 5:00 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author giedrius
 */
public class Keyboard {
    
    /** Creates a new instance of Magic */
    public Keyboard() {
    }
    public static boolean hasNewSymbol;
    public static char newSymbol;
    
}
