/*
 * Main.java
 *
 * Created on May 11, 2008, 5:27 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija;

import osrealizacija.procesai.*;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author giedrius
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
      
        
        Kernel.getInstance().addProcess(new StartStop());
        Thread t = new Thread(Kernel.getInstance());
        t.start();
        
        while (t.isAlive())
        {
           
            char ch = (char)System.in.read();
            Keyboard.hasNewSymbol = true;
            Keyboard.newSymbol = ch;
            Thread.sleep(200);
        }
    }
    
}

