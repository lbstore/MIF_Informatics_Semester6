/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author Lukas
 */
public class PagingDevice {
	private Memory m;

	public PagingDevice(Memory m) {
		this.m = m;

	}

	public int getMemoryContents(int PTR, int adress) {
		 
		 return m.getMemoryContents(getRealAdress(PTR, adress));
		
		//return m.getMemoryContents(adress);
	}

	public void setMemoryContents(int PTR, int adress, int value) {
		
		m.setMemoryContents(getRealAdress(PTR, adress), value);
		//m.setMemoryContents(0 + adress, value); // nesu tikras ar
															// tai veikia :D

	}
	private int getRealAdress(int PTR, int adress)
	{
		adress = Converter.AsciitoInt(adress); //paimam zmoniska adresa
		 String r = Converter.AsciitoString(PTR);
		 PTR = Integer.parseInt(r.substring(1,3),16);//paimam zmoniska PTR
		 PTR*=0x10;
		 PTR+= adress/0x10; //adresas kuriame yra reikalingo bloko nr
		 int block = Converter.AsciitoInt(m.getMemoryContents(PTR)); //paimam reikalinga bloka
		 return block*16+adress%16;
	}

}
