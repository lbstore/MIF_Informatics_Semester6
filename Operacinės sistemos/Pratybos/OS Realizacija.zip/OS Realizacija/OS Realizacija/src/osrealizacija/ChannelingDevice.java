/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package osrealizacija;

/**
 *
 * @author Lukas
 */
import VirtualMachine.*;

public class ChannelingDevice implements Runnable {

    private HDD hdd;
    private Memory m;
    private PagingDevice pd;
    private int state;
    IODevice dev;
    int start;
    int length;
    int adress;
    VM vm;
    private volatile int IORegister;
    private String s;

    public ChannelingDevice(Memory m, PagingDevice pd) {
        this.m = m;
        this.hdd = new HDD();
        this.pd = pd;
    }

    public void read(IODevice dev, int start, int length, int adress) //be puslapiavimao
    {

        this.dev = dev;
        this.start = start;
        this.length = length;
        this.adress = adress;
        state = 1;
    }

    public void readT() //be puslapiavimao
    {
        if (dev.equals(IODevice.HDD)) {
            for (int i = 0; i <= length; i++) //OMG, reikia ascii?
            {
                m.setMemoryContents(i + adress, hdd.getContent(i + start));
            }

        }

    }

    public int[] read(IODevice dev, int start, int length) {
        IORegister = 1;
        start /= 4;
        int[] buf = new int[length / 4];
        for (int i = 0; i < length / 4; i++) {
            buf[i] = hdd.getContent(start++);
        }
        IORegister = 0;
        return buf;
    }

    public void write(IODevice dev, VM vm, int start) //neuzmirst, kad VM pridejau
    {//tik i monitoriu?


        this.dev = dev;
        this.vm = vm;
        this.start = start;
        state = 2;
    }

    public void writeT(int i) //neuzmirst, kad VM pridejau
    {//tik i monitoriu?

        IORegister = 1;
        if (dev.equals(IODevice.Monitor)) {
            System.out.println(formatString(dev, vm, start));
        } else {
            throw new RuntimeException("Galima rasyt tik i monitoriu");
        }
        IORegister = 0;
    }

    public void write(String s) {

        this.s = s;
        state = 3;
    }

    public void writeT() {
        IORegister = 1;
        for (int i = 0; i < 25; i++) {
            System.out.println();
        }
        System.out.println(s);
        IORegister = 0;
    }

    protected String formatString(IODevice dev, VM vm, int start) {

        if (dev.equals(IODevice.Monitor)) {
            String txt = "";
            String tmp;

            int i = start;
            for (;; i++) //i++ 
            {
                tmp = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), Converter.InttoAscii(i)));//nuskaito

                if (tmp.charAt(0) != '\0') {
                    txt = txt + tmp.charAt(0);
                } else {
                    break;
                }

                if (tmp.charAt(1) != '\0') {
                    txt = txt + tmp.charAt(1);
                } else {
                    break;
                }

                if (tmp.charAt(2) != '\0') {
                    txt = txt + tmp.charAt(2);
                } else {
                    break;
                }

                if (tmp.charAt(3) != '\0') {
                    txt = txt + tmp.charAt(3);
                } else {
                    break;
                }

            }

            return txt;

        }

        throw new RuntimeException("Galima rasyt tik i monitoriu");
    }

    public int getIORegister() {
        return IORegister;
    }

    @Override
    public void run() {
        while (true) {
            switch (state) {
                case 1:
                    readT();
                    state = 0;
                    break;
                case 2:
                    writeT(1);
                    state = 0;
                    break;
                case 3:
                    writeT();
                    state = 0;
                    break;
            }

        }
    }
}


