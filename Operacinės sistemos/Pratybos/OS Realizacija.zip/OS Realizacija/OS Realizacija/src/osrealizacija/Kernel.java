/*
 * Kernel.java
 *
 * Created on May 11, 2008, 5:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package osrealizacija;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author giedrius
 */
public class Kernel  implements Runnable{

    public static Kernel kernel = null;
    private ArrayList<Resource> resources = new ArrayList<Resource>();
    private ArrayList<Resource> usedResources = new ArrayList<Resource>();
    private ArrayList<Integer> freeblocks = new ArrayList<Integer>();
    private Process currentconsole;
    private boolean isAlive = true;
    private Memory m = new Memory();
    private PagingDevice pd = new PagingDevice(m);
    private ChannelingDevice cd = new ChannelingDevice(m, pd);
    private ArrayList<Process> processes = new ArrayList<Process>();
    private ArrayList<Process> blockedProcesses = new ArrayList<Process>();

    private Kernel() { //ner ko jo kurt, Singleton ftw

        for (int i = 0; i < 256; i++) {
            freeblocks.add(i);
        }
        new Thread(cd).start();
    }

    public static Kernel getInstance() {
        if (kernel == null) {
            kernel = new Kernel();
        }
        return kernel;
    }

    public void registerResuorce(Resource r) {
        if (resources.contains(r)) {
            throw new RuntimeException("toks jau yra");
        }
        if (usedResources.contains(r)) {
            throw new RuntimeException("toks jau yra");
        }
        usedResources.add(r);
        r.setInUse(true);
    }

    public void freeResource(Resource r) {
        r.setInUse(false);
        usedResources.remove(r);
        resources.add(r);
    }

    public Resource getResource(String id) { //jei gauni null reiskia negavai

        Resource req = null;
        for (Resource r : resources) {
            if (r.getID().equals(id)) {
                req = r;
                continue;
            }
        }
        if (req != null) {
            req.setInUse(true);
            usedResources.add(req);
            resources.remove(req);
        }
        if (id.equals("Memory")) {

            if (freeblocks.size() >= 17) {
                int a[] = new int[17];
                for (int i = 0; i < 17; i++) {
                    a[i] = freeblocks.get(0);
                    freeblocks.remove((Integer) a[i]);
                }
                osrealizacija.resursai.Memory m = new osrealizacija.resursai.Memory(a);
                return m;
                
            }

        }
        return req;
    }

    public void addProcess(Process p) {
        if (processes.contains(p)) {
            throw new RuntimeException("toks jau yra");
        }
        processes.add(p);
    }

    public void destroyProcess(Process p) {
        if (processes.contains(p)) {
            processes.remove(p);
        }
    }

    public void blockProcess(Process p) {
        processes.remove(p);
        blockedProcesses.add(p);
    }

    public void unblockProcess(Process p) {
        blockedProcesses.remove(p);
        processes.add(p);
    }

    public void run() {
        Process curp = null;
        while (isAlive) {
            curp = processes.get(0);
              curp.run();
             if (!blockedProcesses.contains(curp))
            {
             processes.remove(0);
            processes.add(curp);
            }
        }
    }

    public void destroyResource(Resource r) {
        if (!usedResources.contains(r)) {
            throw new RuntimeException("nera ko naikinti to kas nebuvo sukurta arba to mko neturi");
        }
        resources.remove(r);
    }

    public Process getCurrentconsole() {
        return currentconsole;
    }

    public void setCurrentconsole(Process currentconsole) {
        this.currentconsole = currentconsole;
    }

    public boolean isIsAlive() {
        return isAlive;
    }

    public void setIsAlive(boolean isAlive) {
        this.isAlive = isAlive;
    }

    public Memory getM() {
        return m;
    }

    public PagingDevice getPd() {
        return pd;
    }

    public ChannelingDevice getCd() {
        return cd;
    }
}


