/*
 * Resource.java
 *
 * Created on May 11, 2008, 5:29 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author giedrius
 */
public abstract class Resource {
    
    /** Creates a new instance of Resource */
    private boolean inUse = false;
    public abstract String getID();

    public boolean isInUse() {
        return inUse;
    }

    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }
   
    
}
