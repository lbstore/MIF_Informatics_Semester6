/*
 * Process.java
 *
 * Created on May 11, 2008, 5:37 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author giedrius
 */
public abstract class Process {
    
    /** Creates a new instance of Process */
    protected String description;
    protected int state;
    protected String buf="";
    public abstract void run();

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBuf() {
        return buf;
    }
    
}
