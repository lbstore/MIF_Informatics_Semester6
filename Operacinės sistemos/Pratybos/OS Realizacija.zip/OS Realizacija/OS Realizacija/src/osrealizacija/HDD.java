/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package osrealizacija;

/**
 *
 * @author Lukas
 */
import java.io.*;
public class HDD {
	RandomAccessFile hdd;// = new RandomAccessFile("xanadu.txt", "r");
	public HDD()
	{
		try {
			hdd = new RandomAccessFile("xanadu.txt", "r");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int getContent(int adress)
	{
		try {
			hdd.seek(adress*4);
			return hdd.readInt();
		} catch (IOException e) {
	}
		throw new RuntimeException("ne");

	}

}
