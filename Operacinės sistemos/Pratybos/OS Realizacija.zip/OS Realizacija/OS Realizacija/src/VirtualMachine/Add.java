/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Add implements CommandInterface
{
	private int a;
	private int b;
	String command = "";
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("a"))
		{
			if(command.substring(1,2).equalsIgnoreCase("d"))
			{
				if(command.substring(2,4).equalsIgnoreCase("ab"))
				{
					adab(vm);
				}
				else if(command.substring(2,4).equalsIgnoreCase("ba"))
				{
					adba(vm);
				}
			}
			else if(command.substring(1,2).equalsIgnoreCase("a"))
			{
				aaxx(vm, Integer.parseInt(command.substring(2), 16));
			}
			else if(command.substring(1,1).equalsIgnoreCase("b"))
			{
				abxx(vm, Integer.parseInt(command.substring(2), 16));
			}
		};
		if (Converter.AsciitoInt(vm.getIP()) == 255)
		{
			vm.setIP(Converter.InttoAscii(0));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
		return 0;
	}
	public String getOpcode()
	{
		return "a";
	}
	
	private void adab(VM vm)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		vm.setA(Converter.InttoAscii(a + b));
		if (a + b > 65535)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if  ((a + b) % 0x10000 == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void adba(VM vm)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		vm.setB(Converter.InttoAscii(b + a));
		if (b + a > 65535)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if ((b + a) % 0x10000 == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void aaxx(VM vm, int xx)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = xx;
		vm.setA(Converter.InttoAscii(a + b));
		if (a + b > 65535)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if ((a + b) % 0x10000 == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void abxx(VM vm, int xx)
	{
		a = xx;
		b = Converter.AsciitoInt(vm.getB());
		vm.setB(Converter.InttoAscii(b + a));
		if (b + a > 65535)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if ((b + a) % 0x10000 == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}

}
