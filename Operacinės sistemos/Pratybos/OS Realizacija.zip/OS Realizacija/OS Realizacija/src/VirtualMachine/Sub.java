/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;
/**
 *
 * @author Lukas
 */

public class Sub implements CommandInterface
{
	private int a;
	private int b;
	String command;
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("s"))
		{
			if(command.substring(1,2).equalsIgnoreCase("u"))
			{
				if(command.substring(2,4).equalsIgnoreCase("ab"))
				{
					suab(vm);
				}
				else if(command.substring(2,4).equalsIgnoreCase("ba"))
				{
					suba(vm);
				}
			}
			else if(command.substring(1,2).equalsIgnoreCase("a"))
			{
				saxx(vm, Integer.parseInt(command.substring(2), 16));
			}
			else if(command.substring(1,2).equalsIgnoreCase("b"))
			{
				sbxx(vm, Integer.parseInt(command.substring(2), 16));
			}
		};
		if (Converter.AsciitoInt(vm.getIP()) == 255)
		{
			vm.setIP(Converter.InttoAscii(0));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
		return 0;
	}
	public String getOpcode()
	{
		return "s";
	}
	
	private void suab(VM vm)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		vm.setA(Converter.InttoAscii(a - b));
		if (a < b)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (a == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void suba(VM vm)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		vm.setB(Converter.InttoAscii(b - a));
		if (b < a)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (b == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void saxx(VM vm, int xx)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = xx;
		vm.setA(Converter.InttoAscii(a - b));
		if (a < b)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (a == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void sbxx(VM vm, int xx)
	{
		a = xx;
		b = Converter.AsciitoInt(vm.getB());
		vm.setB(Converter.InttoAscii(b - a));
		if (b < a)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (b == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}

}
