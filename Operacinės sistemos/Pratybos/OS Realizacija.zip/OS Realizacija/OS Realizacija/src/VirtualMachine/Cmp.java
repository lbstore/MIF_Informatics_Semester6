/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Cmp implements CommandInterface
{
	private int a;
	private int b;
	String command;
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("c"))
		{
			if(command.substring(1,2).equalsIgnoreCase("m"))
			{
				if(command.substring(2,4).equalsIgnoreCase("ab"))
				{
					cmab(vm);
				}
				else if(command.substring(2,4).equalsIgnoreCase("ba"))
				{
					cmba(vm);
				}
			}
			else if(command.substring(1,2).equalsIgnoreCase("a"))
			{
				caxx(vm, Integer.parseInt(command.substring(2), 16));
			}
			else if(command.substring(1,2).equalsIgnoreCase("b"))
			{
				cbxx(vm, Integer.parseInt(command.substring(2), 16));
			}
		};
		if (Converter.AsciitoInt(vm.getIP()) == 255)
		{
			vm.setIP(Converter.InttoAscii(0));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
		return 0;
	}
	public String getOpcode()
	{
		return "c";
	}
	
	private void cmab(VM vm)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		if (a < b)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (a == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void cmba(VM vm)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		if (b < a)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (b == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void caxx(VM vm, int xx)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = xx;
		if (a < b)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (a == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void cbxx(VM vm, int xx)
	{
		a = xx;
		b = Converter.AsciitoInt(vm.getB());
		if (b < a)
		{
			vm.changeCF(true);
		}else vm.changeCF(false);
		if (b == b)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}

}
