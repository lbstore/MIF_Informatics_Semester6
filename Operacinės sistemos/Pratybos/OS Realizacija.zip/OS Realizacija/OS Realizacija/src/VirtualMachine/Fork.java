/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Fork implements CommandInterface
{
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		if(Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP())).equalsIgnoreCase("fork"))
		{
			r.setSI((byte)Converter.InttoAscii(4));
		}
                
             if (Converter.AsciitoInt(vm.getIP()) == 255)
			{
				vm.setIP(Converter.InttoAscii(0));
			}else 
			{
				vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
			}
                
		return 0;
	}
	
	public String getOpcode()
	{
		return "fork";
	}
}

