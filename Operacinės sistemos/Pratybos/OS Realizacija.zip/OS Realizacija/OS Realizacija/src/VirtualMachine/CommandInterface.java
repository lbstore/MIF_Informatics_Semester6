/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;

import osrealizacija.PagingDevice;

/**
 *
 * @author Lukas
 */
public interface CommandInterface {
	public int Execute(VM vm, Registrai r, PagingDevice pd);

	public String getOpcode();
	// 1 arba 4 ilgis, nieko kito11111111111111111111111
}
