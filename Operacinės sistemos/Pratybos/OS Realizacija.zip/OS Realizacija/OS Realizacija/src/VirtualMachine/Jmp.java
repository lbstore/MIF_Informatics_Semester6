/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Jmp implements CommandInterface
{
	private int a;
	String command;
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("j"))
		{
			if(command.substring(1,2).equalsIgnoreCase("p"))
			{
				jpyy(vm, Integer.parseInt(command.substring(2), 16), r);
			}
			else if(command.substring(1,2).equalsIgnoreCase("e"))
			{
				jeyy(vm, Integer.parseInt(command.substring(2), 16), r);
			}
			else if(command.substring(1,2).equalsIgnoreCase("n"))
			{
				jnyy(vm, Integer.parseInt(command.substring(2), 16), r);
			}
			else if(command.substring(1,2).equalsIgnoreCase("m"))
			{
				jmyy(vm, Integer.parseInt(command.substring(2), 16), r);
			}
			else if(command.substring(1,2).equalsIgnoreCase("l"))
			{
				jlyy(vm, Integer.parseInt(command.substring(2), 16), r);
			}
		};
		return 0;
	}
	public String getOpcode()
	{
		return "j";
	}
	
	private void jpyy(VM vm, int yy, Registrai r)
	{
		a = yy;
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setIP(Converter.InttoAscii(a));
	}
	
	private void jeyy(VM vm, int yy, Registrai r)
	{
		a = yy;
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		if(vm.getZF())
		{
		vm.setIP(Converter.InttoAscii(a));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
	}
	
	private void jnyy(VM vm, int yy, Registrai r)
	{
		a = yy;
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		if(!vm.getZF())
		{
		vm.setIP(Converter.InttoAscii(a));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
	}
	
	private void jmyy(VM vm, int yy, Registrai r)
	{
		a = yy;
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		if(!vm.getCF() && !vm.getZF())
		{
		vm.setIP(Converter.InttoAscii(a));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
	}
	private void jlyy(VM vm, int yy, Registrai r)
	{
		a = yy;
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		if(vm.getCF() && !vm.getZF())
		{
		vm.setIP(Converter.InttoAscii(a));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
	}

}
