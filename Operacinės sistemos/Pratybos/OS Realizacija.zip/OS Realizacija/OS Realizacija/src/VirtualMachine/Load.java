/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Load implements CommandInterface
{
	private int a;
	private int b;
	String command;
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("l"))
		{
			if(command.substring(1,2).equalsIgnoreCase("a"))
			{
				layy(vm, Integer.parseInt(command.substring(2), 16), r, pd);
			}
			else if(command.substring(1,2).equalsIgnoreCase("b"))
			{
				lbyy(vm, Integer.parseInt(command.substring(2,4), 16), r, pd);
			}
		};
		if (Converter.AsciitoInt(vm.getIP()) == 255)
		{
			vm.setIP(Converter.InttoAscii(0));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
		return 0;
	}
	public String getOpcode()
	{
		return "l";
	}
	
	private void layy(VM vm, int yy, Registrai r, PagingDevice pd)
	{;
		b = yy;
		if(b < 0 || b > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setA(pd.getMemoryContents(vm.getPTR(), Converter.InttoAscii(b)));
	}
	
	private void lbyy(VM vm, int yy, Registrai r, PagingDevice pd)
	{
		a = yy;
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setB(pd.getMemoryContents(vm.getPTR(), Converter.InttoAscii(a)));
	}

}
