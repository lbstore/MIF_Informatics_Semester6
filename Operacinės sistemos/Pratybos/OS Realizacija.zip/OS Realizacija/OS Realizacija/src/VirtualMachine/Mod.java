/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Mod implements CommandInterface
{
	private int a;
	private int b;
	String command;
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("o"))
		{
			if(command.substring(1,2).equalsIgnoreCase("d"))
			{
				if(command.substring(2,4).equalsIgnoreCase("ab"))
				{
					diab(vm, r);
				}
				else if(command.substring(2,4).equalsIgnoreCase("ba"))
				{
					diba(vm, r);
				}
			}
			else if(command.substring(1,2).equalsIgnoreCase("a"))
			{
				daxx(vm, Integer.parseInt(command.substring(2), 16), r);
			}
			else if(command.substring(1,2).equalsIgnoreCase("b"))
			{
				dbxx(vm, Integer.parseInt(command.substring(2), 16), r);
			}
		};
		if (Converter.AsciitoInt(vm.getIP()) == 255)
		{
			vm.setIP(Converter.InttoAscii(0));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
		return 0;
	}
	public String getOpcode()
	{
		return "o";
	}
	
	private void diab(VM vm, Registrai r)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		if (b == 0)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setA(Converter.InttoAscii(a % b));
		if (a % b == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void diba(VM vm, Registrai r)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = Converter.AsciitoInt(vm.getB());
		if(a == 0)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setB(Converter.InttoAscii(b % a));
		if (b % a == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void daxx(VM vm, int xx, Registrai r)
	{
		a = Converter.AsciitoInt(vm.getA());
		b = xx;
		if(b == 0)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setA(Converter.InttoAscii(a % b));
		if (a % b == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}
	
	private void dbxx(VM vm, int xx, Registrai r)
	{
		a = xx;
		b = Converter.AsciitoInt(vm.getB());
		if(a == 0)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		vm.setB(Converter.InttoAscii(b % a));
		if (b % a == 0)
		{ 
			vm.changeZF(true);
		}else vm.changeZF(false);
	}

}

