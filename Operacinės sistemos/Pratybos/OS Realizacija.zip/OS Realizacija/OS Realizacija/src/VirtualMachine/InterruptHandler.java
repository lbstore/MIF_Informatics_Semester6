/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;

import osrealizacija.*;

/**
 *
 * @author Lukas
 */
public interface InterruptHandler {
	public void Handle(VM vm, Registrai r, PagingDevice pd, ChannelingDevice cd, osrealizacija.procesai.VM rm);
	public InterruptType getIT();
}

