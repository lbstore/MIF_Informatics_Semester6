/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;

/**
 *
 * @author Lukas
 */
public class Registrai {
	private byte SI;

	private byte PI;

	private byte IOI;

	private byte TI;

	public byte getSI() {
		return SI;
	}

	public void setSI(byte si) {
		SI = si;
	}

	public byte getPI() {
		return PI;
	}

	public void setPI(byte pi) {
		PI = pi;
	}

	public byte getIOI() {
		return IOI;
	}

	public void setIOI(byte ioi) {
		IOI = ioi;
	}

	public byte getTI() {
		return TI;
	}

	public void setTI(byte ti) {
		TI = ti;
	}

}

