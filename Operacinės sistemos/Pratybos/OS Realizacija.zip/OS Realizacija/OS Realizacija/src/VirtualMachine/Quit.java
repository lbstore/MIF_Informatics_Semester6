/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;

/**
 *
 * @author Lukas
 */

public class Quit implements CommandInterface
{
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		if(Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP())).equalsIgnoreCase("quit"))
		{
			r.setSI((byte)Converter.InttoAscii(1));
		}
		return 0;
	}
	
	public String getOpcode()
	{
		return "quit";
	}
}
