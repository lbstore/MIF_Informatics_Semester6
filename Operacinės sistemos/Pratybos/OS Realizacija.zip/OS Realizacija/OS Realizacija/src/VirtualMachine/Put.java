/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;
import osrealizacija.*;
/**
 *
 * @author Lukas
 */

public class Put implements CommandInterface
{
	private int a;
	private int b;
	String command;
	
	public int Execute(VM vm, Registrai r, PagingDevice pd)
	{
		command = Converter.AsciitoString(pd.getMemoryContents(vm.getPTR(), vm.getIP()));
		if(command.substring(0,1).equalsIgnoreCase("p"))
		{
			if(command.substring(3,4).equalsIgnoreCase("a"))
			{
				pyya(vm, Integer.parseInt(command.substring(1,3), 16), r, pd);
			}
			else if(command.substring(3,4).equalsIgnoreCase("b"))
			{
				pyyb(vm, Integer.parseInt(command.substring(1,3), 16), r, pd);
			}
		};
		if (Converter.AsciitoInt(vm.getIP()) == 255)
		{
			vm.setIP(Converter.InttoAscii(0));
		}else 
		{
			vm.setIP(Converter.InttoAscii(Converter.AsciitoInt(vm.getIP())+1));
		}
		return 0;
	}
	public String getOpcode()
	{
		return "p";
	}
	
	private void pyya(VM vm, int yy, Registrai r, PagingDevice pd)
	{
		a = vm.getA();
		b = yy;
		if(b < 0 || b > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		pd.setMemoryContents(vm.getPTR(), Converter.InttoAscii(b), a);
	}
	
	private void pyyb(VM vm, int yy, Registrai r, PagingDevice pd)
	{
		a = yy;
		b = vm.getB();
		if(a < 0 || a > 255)
		{
			r.setPI((byte)Converter.InttoAscii(1));
		}
		pd.setMemoryContents(vm.getPTR(), Converter.InttoAscii(a), b);
	}

}

