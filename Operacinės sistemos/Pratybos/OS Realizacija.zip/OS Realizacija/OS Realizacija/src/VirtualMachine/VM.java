/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package VirtualMachine;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lukas
 */
public class VM implements Cloneable {

    private int A;
    private int B;
    private int IP;
    private int Flags;
    private int PTR;

    public int getPTR() {
        return PTR;
    }

    public void setPTR(int ptr) {
        PTR = ptr;
    }

    public void changeCF(boolean v) {

        if (v) {
            Flags |= 1;
        } else {
            Flags &= ~1;
        }
    }

    public boolean getCF() {
        return (Flags & 1) > 0;
    }

    public void changeZF(boolean v) {

        if (v) {
            Flags |= 2;
        } else {
            Flags &= ~2;
        }

    }

    public boolean getZF() {
        return (Flags & 2) > 0;
    }

    public int getA() {
        return A;
    }

    public void setA(int a) {
        A = a;
    }

    public int getB() {
        return B;
    }

    public void setB(int b) {
        B = b;
    }

    public int getIP() {
        return IP;
    }

    public void setIP(int ip) {
        IP = ip;
    }

    public Object Clone() {
        Object tmp = null;
        try {
            tmp = super.clone();
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(VM.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tmp;
    }
}

