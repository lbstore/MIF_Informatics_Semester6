/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package VirtualMachine;

/**
 *
 * @author Lukas
 */
public enum InterruptType {
	SI, PI, IOI, TI
}

