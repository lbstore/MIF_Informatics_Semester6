#include <iostream>
#include <fstream>
#include <cstdlib>
 
using namespace std;

char atmintis[300][4];
bool uzimtasBlokas[30];  

void naujaAtmintis(){
  for(int i=0; i<300; i++){
    for(int j=0; j<4; j++){
		atmintis[i][j]='0';
    }
  }
  for(int i=0; i<30; i++){
    uzimtasBlokas[i]=false;
  }
}

int laisvasBlokas(){
  for (int i=0; i<30; i++){
    if(!uzimtasBlokas[i]){
       return i;
       }
  }
  return 30;
}

class VirtMasina{
private:
  char R[4];
  bool C;
  short IC;
  short PLR[4];
public:
  VirtMasina();
  int realAdresas(char x1, char x2);
  bool naujasPLR();
  bool pakrautiPrograma(char* failas);
  void LR(char x1, char x2);  //Pakrauti registra is  [x1,x2]
  void SR(char x1, char x2);  //Siusti registra i  [x1,x2]
  void CR(char x1, char x2);  //Palyginti registra su  [x1,x2]
  void BT(char x1, char x2);  //Jei C, tai  IC=10*x1+x2
  void GD(char x1); //Gauti duomenis is bloko x1
  void PD(char x1); //Padeti duomenis i bloka x1
  void HALT();
  void AD(char x1, char x2); //Sudeti [x1,x2] i registro reiksme
  void vykdytiPrograma();
  void rodytiBusena();
};

VirtMasina::VirtMasina(){
  for (int i=0; i<4; i++){
    R[i]='0';
  }
  C=true;
  IC=0;
  naujasPLR();
}

int VirtMasina::realAdresas(char x1, char x2){
  return 10*(atmintis[10*(10*PLR[2]+PLR[3])+x1-'0'][3]-'0')+
         100*(atmintis[10*(10*PLR[2]+PLR[3])+x1-'0'][2]-'0')+
         x2-'0';
}

bool VirtMasina::naujasPLR(){
  PLR[0]=0;
  PLR[1]=0;
  int blokoNr=laisvasBlokas();
  if(blokoNr==30){
    cout<<"Nera vietos atmintyje naujai puslapiu lentelei."<<endl;
    return  false;
  }
  else{
    PLR[2]=blokoNr/10;
    PLR[3]=blokoNr%10;
    uzimtasBlokas[blokoNr]=true;
  }
}

bool VirtMasina::pakrautiPrograma(char* failas){
  int i=0;
  char duom;
  ifstream iv;
  iv.open(failas);
  if (!iv.is_open()){
    cout<<"Nepavyko atidaryti failo '"<<failas<<"'. Programa nepakrauta."<<endl;
    return false;
  }
  while(!iv.eof()){
    if(i%10==0){
      int blokoNr=laisvasBlokas();
      if (blokoNr==30){
        cout<<"Neuztenka atminties. Programa nepakrauta."<<endl;
        return false;
      }
      atmintis[10*(10*PLR[2]+PLR[3])+PLR[1]][3]=blokoNr%10+'0';
      atmintis[10*(10*PLR[2]+PLR[3])+PLR[1]][2]=blokoNr/10+'0';
      uzimtasBlokas[blokoNr]=true;
      PLR[1]++;
    }
    for(int j=0; j<4; j++){
      iv.get(duom);
      if (iv.eof()){break;}
      atmintis[realAdresas(i/10+'0', i%10+'0')][j]=duom;
    }
    i++;
  }
  return true;
}

void VirtMasina::LR(char x1, char x2){
  for (int i=0; i<4; i++){
    R[i]=atmintis[realAdresas(x1, x2)][i];
  }
}

void VirtMasina::SR(char x1, char x2){
  for (int i=0; i<4; i++){
    atmintis[realAdresas(x1, x2)][i]=R[i];
  }
}

void VirtMasina::CR(char x1, char x2){
  if(atmintis[realAdresas(x1, x2)]==R){C=true;}
  else C=false;
}

void VirtMasina::BT(char x1, char x2){
  if (C) {IC=(x1-'0')*10+x2-'0';}
}

void VirtMasina::GD(char x1){
  int sk;
  for (int i=0; i<2; i++){
    char x2 = i+'0';
    cin>>sk;
    atmintis[realAdresas(x1, x2)][3]=sk%10+'0';
    atmintis[realAdresas(x1, x2)][2]=sk/10%10+'0';
    atmintis[realAdresas(x1, x2)][1]=sk/100%10+'0';
    atmintis[realAdresas(x1, x2)][0]=sk/1000%10+'0';
  }
}


void VirtMasina::PD(char x1){
  for (int i=0; i<10; i++){
    char x2 = i+'0';
    cout<<atmintis[realAdresas(x1, x2)][0]
        <<atmintis[realAdresas(x1, x2)][1]
        <<atmintis[realAdresas(x1, x2)][2]
        <<atmintis[realAdresas(x1, x2)][3];
  }
}

void VirtMasina::HALT(){
  cout<<"Virtuali masina sustabdyta."<<endl;
}

void VirtMasina::AD(char x1, char x2){
  int suma=(R[0]-'0')*1000+
           (R[1]-'0')*100+
           (R[2]-'0')*10+
           (R[3]-'0')+
           (atmintis[realAdresas(x1, x2)][0]-'0')*1000+
           (atmintis[realAdresas(x1, x2)][1]-'0')*100+
           (atmintis[realAdresas(x1, x2)][2]-'0')*10+
           (atmintis[realAdresas(x1, x2)][3]-'0');
  R[3]=suma%10+'0';
  R[2]=suma%100/10+'0';
  R[1]=suma%1000/100+'0';
  R[0]=suma%10000/1000+'0';
}

void VirtMasina::vykdytiPrograma(){
  char kmd[4];
  do{
    rodytiBusena();
    for(int i=0; i<4; i++){
      kmd[i]=atmintis[realAdresas(IC/10+'0', IC%10+'0')][i];
    }
    cout<<"Komanda: "<<kmd[0]<<kmd[1]<<kmd[2]<<kmd[3]<<endl;
    
    //system("PAUSE");
    IC++;
    switch(kmd[0]){
      case 'L' :
        if (kmd[1]=='R'){
        LR(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'S' :
        if (kmd[1]=='R'){
        SR(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'C' :
        if (kmd[1]=='R'){
        CR(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'B' :
        if (kmd[1]=='T'){
        BT(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
    case 'G' :
        if (kmd[1]=='D'){
        GD(kmd[2]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'P' :
        if (kmd[1]=='D'){
        PD(kmd[2]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'A' :
        if (kmd[1]=='D'){
        AD(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
    }
  } while (kmd[0]!='H');
  HALT();
}

void VirtMasina::rodytiBusena(){
  cout<<endl<<"R:"<<R[0]<<R[1]<<R[2]<<R[3]<<endl
      <<"C:"<<C<<endl
      <<"IC:"<<IC<<endl
      <<"PLR:"<<PLR[0]<<PLR[1]<<PLR[2]<<PLR[3]<<endl;
}

void atmintiiFaila(){
  ofstream isv("rez.txt");
  for(int i=0; i<300; i++){
    isv<<endl<<i/100<<i/10%10<<i%10<<" ";
    for (int j=0; j<4; j++){
      isv<<atmintis[i][j];
    }
  }
}

int main(){
      naujaAtmintis();
      uzimtasBlokas[0]=true;
      uzimtasBlokas[2]=true;
      VirtMasina vm;
      vm.pakrautiPrograma("duom.txt");
      vm.vykdytiPrograma();
      atmintiiFaila();
      vm.rodytiBusena();
    //  system("PAUSE");
      return 0;
}
