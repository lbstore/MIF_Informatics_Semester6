#include <iostream>
int main(){
char i = 'x';
char x2 = i+'0';
cout<<x2;
}
