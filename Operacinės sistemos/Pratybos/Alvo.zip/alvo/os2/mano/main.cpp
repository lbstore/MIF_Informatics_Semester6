#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char atmintis [110][5];
char R[5]="abcd";
int C=1; // 1 - true, 0 - false
int IC=10;
//char d[400];
FILE *F, *F1;
void init_atmintis(void){
  for (int i=0; i<100; i++) {
    for (int j=0; j<4; j++) {
          atmintis[i][j]='-'; }}
   }   
void psl_lentele(void){
  char p[5]={"\0"};
  for (int i=1; i<=10; i++) {
  int svd = i/1000;
  int liekana=i%1000;
  p[0]=svd+48;
  svd = liekana/100;  
  liekana=liekana%100;
  p[1]=svd+48;
  svd = liekana/10;
  liekana=liekana%10;  
  p[2]=svd+48;
  p[3]=liekana+48;    
  atmintis[i+99]=p;
    }
}
  
void print_atmintis(){
  fprintf(F1, "\nAtminties bukle\n");
  for (int i=0; i<110; i++) {
    if (atmintis[i]!="----") fprintf(F1, "%d: %s | ", i, atmintis[i]);
    else fprintf(F1, "%s: ---- | ");
    if ((i+1)%5==0) fprintf(F1, "\n");}
    fprintf(F1, "R - %s, IC - %d, C- %c\n", R, IC, C);
}

int realus_adresas(char adr[4]){
   char r_adr[5]={"\0"}; //realus adresas char formoje
   r_adr = atmintis[100+adr[2]-48-1]; 
   int realus=(r_adr[0]-48)*1000+(r_adr[1]-48)*100+(r_adr[2]-48)*10+(r_adr[3]-48);
   realus=realus*10+(adr[3]-48); 
   return realus;
}   

void GD(char adr[4], char data[40]){
   int realus=realus_adresas(adr);
   int count=0;
   for (int i=0; i<strlen(data); i++) {
     if (count==4) {realus++; count=0;}
   atmintis[realus][count]=data[i];
   count++;}
} 
void PD(char adr[4]){
  int realus=realus_adresas(adr);
  int count=0;
  printf("gauti duomenys");
  while (atmintis[realus][count]!='-') {
    if (count==4) {realus++; count=0;}
    printf("%c", atmintis[realus][count]);
    count++;
    }
}    
void LR(char adr[4]){
   int realus=realus_adresas(adr);
   R=atmintis[realus];
   }
void SR(char adr[4]){
   int realus=realus_adresas(adr);
      printf("%d", realus);
   atmintis[realus]=R;
   }
void CR(char adr[4]){
    int realus=realus_adresas(adr);
    char A[5];
    A=atmintis[realus];
    C=0;
    if ((A[0]==R[0])&&(A[1]==R[1])&&(A[2]==R[2])&&(A[3]==R[3])) C=1;
}
void BT(char adr[4]){
    int realus=realus_adresas(adr);
   // C=1;
    if (C==1) IC=realus-1;
    printf("%d",IC);
}

  void AD(char adr[4]){
   int realus=realus_adresas(adr);
   int tmp=(R[0]-48)*1000+(R[1]-48)*100+(R[2]-48)*10+(R[3]-48)+(atmintis[realus][0]-48)*1000+(atmintis[realus][1]-48)*100+(atmintis[realus][2]-48)*10+(atmintis[realus][3]-48);
  int svd = tmp/1000;
  int liekana=tmp%1000;
  char p[5];
  p[0]=svd+48;
  svd = liekana/100;  
  liekana=liekana%100;
  p[1]=svd+48;
  svd = liekana/10;
  liekana=liekana%10;  
  p[2]=svd+48;
  p[3]=liekana+48;    
  R=p;
  } 
void main(int argc, char *argv[])
{
  char adr[5], eil[5], duom[40], kom[5]={"\0"};

 F=fopen("duom.txt");
  while (!feof(F)) {
  fscanf(F, "%s", p);
  printf("%s\n", p);}*/
  init_atmintis(); //nusibruksniuoja atmintis
  psl_lentele(); //puslapiavimo lentele padarom
     F1=fopen("atmintis.txt","wt");
   print_atmintis();
  if (!(F=fopen(argv[1],"rt"))) printf("klaida");
  fscanf(F, "%s", eil);   
   while (!feof(F)){
    if (eil[0]=='$') adr=eil;
    else { GD(adr, eil); adr[3]=((adr[3]-48)+1)+48; }
    fscanf(F, "%s", eil);
  }  

   print_atmintis(); 
  //-------------------padejimas i atminty-------------
  //-----------LR, SR---------------
 while (kom[0]!='H'){
  kom=atmintis[IC];
  if (kom[0]=='S') SR(kom);

  else if (kom[0]=='L') LR(kom);
  //----------GD, PD---------------------
  else if (kom[0]=='G') {scanf("%s", duom); GD(kom, duom);}
  else if (kom[0]=='P') PD(kom);
  else if (kom[0]=='C') CR(kom);
  //---------------------
  else if (kom[0]=='A') AD(kom);
  else if (kom[0]=='B') BT(kom);
  else if (kom[0]!='H') printf("nezinoma komanda %s", kom);

  print_atmintis(); 
  IC++; }
  fclose(F);
}

