/*
Vaidotas Vitkauskas
Informatika 
3 kursas
1 grupe
*/

#include <iostream>
#include <fstream>

using namespace std;

char atmintis[300][4];
bool uzimtasBlokas[30];  

void naujaAtmintis(){
  for(int i=0; i<300; i++){
    for(int j=0; j<4; j++){
       atmintis[i][j]='0';
    }
  }
  for(int i=0; i<30; i++){
    uzimtasBlokas[i]=false;
  }
}

int laisvasBlokas(){
  for (int i=0; i<30; i++){
    if(!uzimtasBlokas[i]){return i;}
  }
  return 30;
}

class VirtualiMasina{
private:
  char R[4];
  bool C;
  short IC;
  short PLR[4];
public:
  VirtualiMasina();
  int realusAdr(char x1, char x2);
  bool naujasPLR();
  bool pakrautiPrograma(char* failas);
  void LR(char x1, char x2);  //Load Register from [x1,x2]
  void SR(char x1, char x2);  //Store Register at [x1,x2]
//  void CR(char x1, char x2);  //Compare Register with [x1,x2]
//  void BT(char x1, char x2);  //If C, then IC=10*x1+x2
  void GD(char x1); //Get Data from block x1
  void PD(char x1); //Put Data to block x1
  void HALT();
  void AD(char x1, char x2); //ADd [x1,x2] to register value
  void vykdytiPrograma();
  void rodytiBusena();
};

VirtualiMasina::VirtualiMasina(){
  for (int i=0; i<4; i++){
    R[i]='0';
  }
  C=true;
  IC=0;
  naujasPLR();
}

int VirtualiMasina::realusAdr(char x1, char x2){
  return 10*(atmintis[10*(10*PLR[2]+PLR[3])+x1-'0'][3]-'0')+
         100*(atmintis[10*(10*PLR[2]+PLR[3])+x1-'0'][2]-'0')+
         x2-'0';
}

bool VirtualiMasina::naujasPLR(){
  PLR[0]=0;
  PLR[1]=0;
  int blokoNr=laisvasBlokas();
  if(blokoNr==30){
    cout<<"Nera vietos atmintyje naujai puslapiu lentelei."<<endl;
    return  false;
  }
  else{
    PLR[2]=blokoNr/10;
    PLR[3]=blokoNr%10;
    uzimtasBlokas[blokoNr]=true;
  }
}

bool VirtualiMasina::pakrautiPrograma(char* failas){
  int i=0;
  char duom;
  ifstream iv;
  iv.open(failas);
  if (!iv.is_open()){
    cout<<"Nepavyko atidaryti failo '"<<failas<<"'. Programa nepakrauta."<<endl;
    return false;
  }
  while(!iv.eof()){
    if(i%10==0){
      int blokoNr=laisvasBlokas();
      if (blokoNr==30){
        cout<<"Neuztenka atminties. Programa nepakrauta."<<endl;
        return false;
      }
      atmintis[10*(10*PLR[2]+PLR[3])+PLR[1]][3]=blokoNr%10+'0';
      atmintis[10*(10*PLR[2]+PLR[3])+PLR[1]][2]=blokoNr/10+'0';
      uzimtasBlokas[blokoNr]=true;
      PLR[1]++;
    }
    for(int j=0; j<4; j++){
      iv.get(duom);
      if (iv.eof()){break;}
      atmintis[realusAdr(i/10+'0', i%10+'0')][j]=duom;
    }
    i++;
  }
  return true;
}

void VirtualiMasina::LR(char x1, char x2){
  for (int i=0; i<4; i++){
    R[i]=atmintis[realusAdr(x1, x2)][i];
  }
}

void VirtualiMasina::SR(char x1, char x2){
  for (int i=0; i<4; i++){
    atmintis[realusAdr(x1, x2)][i]=R[i];
  }
}
/*
void VirtualiMasina::CR(char x1, char x2){
  if(atmintis[realusAdr(x1, x2)]==R){C=true;}
  else C=false;
}

void VirtualiMasina::BT(char x1, char x2){
  if (C) {IC=(x1-'0')*10+x2-'0';}
}
*/
void VirtualiMasina::GD(char x1){
  int sk;
  for (int i=0; i<2; i++){
    char x2 = i+'0';
    cin>>sk;
    atmintis[realusAdr(x1, x2)][3]=sk%10+'0';
    atmintis[realusAdr(x1, x2)][2]=sk/10%10+'0';
    atmintis[realusAdr(x1, x2)][1]=sk/100%10+'0';
    atmintis[realusAdr(x1, x2)][0]=sk/1000%10+'0';
  }
}


void VirtualiMasina::PD(char x1){
  for (int i=0; i<10; i++){
    char x2 = i+'0';
    cout<<atmintis[realusAdr(x1, x2)][0]
        <<atmintis[realusAdr(x1, x2)][1]
        <<atmintis[realusAdr(x1, x2)][2]
        <<atmintis[realusAdr(x1, x2)][3];
  }
}

void VirtualiMasina::HALT(){
  cout<<"Virtuali masina sustabdyta."<<endl;
}

void VirtualiMasina::AD(char x1, char x2){
  int suma=(R[0]-'0')*1000+
           (R[1]-'0')*100+
           (R[2]-'0')*10+
           (R[3]-'0')+
           (atmintis[realusAdr(x1, x2)][0]-'0')*1000+
           (atmintis[realusAdr(x1, x2)][1]-'0')*100+
           (atmintis[realusAdr(x1, x2)][2]-'0')*10+
           (atmintis[realusAdr(x1, x2)][3]-'0');
  R[3]=suma%10+'0';
  R[2]=suma%100/10+'0';
  R[1]=suma%1000/100+'0';
  R[0]=suma%10000/1000+'0';
}

void VirtualiMasina::vykdytiPrograma(){
  char kmd[4];
  do{
    rodytiBusena();
    for(int i=0; i<4; i++){
      kmd[i]=atmintis[realusAdr(IC/10+'0', IC%10+'0')][i];
    }
    cout<<"Komanda: "<<kmd[0]<<kmd[1]<<kmd[2]<<kmd[3]<<endl;
    
    system("PAUSE");
    IC++;
    switch(kmd[0]){
      case 'L' :
        if (kmd[1]=='R'){
        LR(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'S' :
        if (kmd[1]=='R'){
        SR(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
/*      case 'C' :
        if (kmd[1]=='R'){
        CR(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'B' :
        if (kmd[1]=='T'){
        BT(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
*/    case 'G' :
        if (kmd[1]=='D'){
        GD(kmd[2]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'P' :
        if (kmd[1]=='D'){
        PD(kmd[2]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
        break;
      case 'A' :
        if (kmd[1]=='D'){
        AD(kmd[2], kmd[3]);
        }
        else {
          cout<<"Nezinoma komanda. Programos vykdymas nutraukiamas.";
          kmd[0]='H';
        }
    }
  } while (kmd[0]!='H');
  HALT();
}

void VirtualiMasina::rodytiBusena(){
  cout<<endl<<"R:"<<R[0]<<R[1]<<R[2]<<R[3]<<endl
      <<"C:"<<C<<endl
      <<"IC:"<<IC<<endl
      <<"PLR:"<<PLR[0]<<PLR[1]<<PLR[2]<<PLR[3]<<endl;
}

void atmintiFailan(){
  ofstream isv("rez.txt");
  for(int i=0; i<300; i++){
    isv<<endl<<i/100<<i/10%10<<i%10<<" ";
    for (int j=0; j<4; j++){
      isv<<atmintis[i][j];
    }
  }
}

int main(){
      naujaAtmintis();
      uzimtasBlokas[0]=true;
      uzimtasBlokas[2]=true;
      uzimtasBlokas[1]=true;
      uzimtasBlokas[3]=true;
      uzimtasBlokas[5]=true;
      uzimtasBlokas[6]=true;
      uzimtasBlokas[7]=true;
      uzimtasBlokas[4]=true;
      uzimtasBlokas[8]=true;
      uzimtasBlokas[9]=true;
      VirtualiMasina vm;
      vm.pakrautiPrograma("duom.txt");
      vm.vykdytiPrograma();
      atmintiFailan();
      vm.rodytiBusena();
      system("PAUSE");
      return 0;
}
