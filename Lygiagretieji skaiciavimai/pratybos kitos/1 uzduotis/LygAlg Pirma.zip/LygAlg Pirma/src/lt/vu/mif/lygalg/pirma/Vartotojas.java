package lt.vu.mif.lygalg.pirma;

public class Vartotojas {
	private String vardas;
	private boolean uzimtas;
	
	public Vartotojas(String vardas) {
		this.vardas = vardas;
	}
	
	public String getVardas() {
		return this.vardas;
	}
	
	public void setUzimtas(boolean uzimtas) {
		this.uzimtas = uzimtas;
	}
	
	public boolean getUzimtas() {
		return this.uzimtas;
	}
}
