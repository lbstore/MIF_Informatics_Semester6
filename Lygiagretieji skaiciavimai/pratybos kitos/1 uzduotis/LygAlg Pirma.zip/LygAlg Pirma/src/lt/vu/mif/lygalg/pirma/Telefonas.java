package lt.vu.mif.lygalg.pirma;
/*
 * Lauryno Paradausko VU MIF Informatikos bakalauras 1 grupė Kompiuterių mokslas, 3 kursas
 * 
 * Problema: vartotojas gauna sms iš 2 žmonių. 
 * Kiekvienas iš jų siunčia po 10000 sms.
 * 
 * Laukiamas rezultatas: 20 000
 * 
 */
public class Telefonas extends Thread {
	private static boolean sync;
	private static int klaidu = 0;
	private boolean uzemus;
	private Vartotojas vartotojas;
	private static Telefonas gija1;
	private static Telefonas gija2;
	
	public static void main(String[] args) {
		System.out.println("Pradedam skambinti");
		if (args.length>0)
			sync = Boolean.parseBoolean(args[0]);
		Vartotojas vartotojas = new Vartotojas("Jonas");
		gija1 = new Telefonas(vartotojas);
		gija2 = new Telefonas(vartotojas);
		gija1.start();
		gija2.start();
		try {
			gija1.join(); 
			gija2.join();
		} catch (InterruptedException e) {
			System.out.println("klaida "+e.getMessage());
			e.printStackTrace();
		}
		System.out.println("Klaidu skaicius: "+klaidu);
		System.out.println("Baigiame skambinti");
	}
	
	public Telefonas(Vartotojas vartotojas) {
		this.vartotojas = vartotojas;
		this.uzemus = false;
	}
	
	@Override
	public void run() {
		if (sync)
			this.siusti();
		else 
			this.siustiBeSync();
	}
	
	private void siustiBeSync() {
		//>> skambinama vartotojui be synchronized
		for (int i=0; i<10000; i++) {
			this.uzemus = true;
			vartotojas.setUzimtas(true);
			if (gija1.getUzemus() && gija2.getUzemus()) {
				klaidu++;
				System.out.println("ABI GIJOS SKAMBINA VIENU METU!!!");
			}
			vartotojas.setUzimtas(false);
			this.uzemus = false;
		}
		//<< be sync pabaiga
	}

	public void siusti() {
		//>> skambinama vartotojui su synchronized
		
			for (int i=0; i<10000; i++) {
				synchronized (vartotojas) {
					this.uzemus = true;
					vartotojas.setUzimtas(true);
					if (gija1.getUzemus() && gija2.getUzemus()) {
						klaidu++;
						System.out.println("ABI GIJOS SKAMBINA VIENU METU!!!");
					}
					vartotojas.setUzimtas(false);
					this.uzemus = false;
				}
			}
		
		//<< su sync pabaiga
	}
	
	public boolean getUzemus() {
		return this.uzemus;
	}
	
}
