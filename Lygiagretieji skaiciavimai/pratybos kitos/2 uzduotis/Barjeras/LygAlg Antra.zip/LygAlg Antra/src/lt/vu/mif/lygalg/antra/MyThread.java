/*
 *  Laurynas Paradauskas 1 grupė Kompiuterių mokslas 
Barjeras - su duomenų apsikeitimu
Objektas inicializuojamas "sąveikoje" dalyvaujančių gijų skaiciumi (N).
Pagrindinė operacija -
    int  waitBarier(int reikšmė).
Kiekviena šį metodą iškvietusi giją laukia, kol kvietėjų skaičius taps lygus N.
Tada visos N gijos "paleidžiamos" - metodas gražina asociatyvios operacijos (pvz. sumos)
su visomis "reikšmėmis" rezultatą - o barjeras reinicializuojamas, t.y., paruošiamas
sekančiam waitBarier() kvietiniui.



PASTABA: giju skaicius = n, ir tos gijos kvieciamos keleta kartu (pvz su skirtingu value)
 */

package lt.vu.mif.lygalg.antra;

public class MyThread extends Thread {
	private Barrier barrier;
	
	public MyThread(Barrier barrier) {
		this.barrier = barrier;
	}

	public static void main(String[] args) {
		int n = 3;
		Barrier barrier = new Barrier(n);
		MyThread thread1 = new MyThread(barrier);
		MyThread thread2 = new MyThread(barrier);
		MyThread thread3 = new MyThread(barrier);
		
		thread1.start();
		thread2.start();
		thread3.start();
		try {
			thread1.join();
			thread2.join();
			thread3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			for(int i=0; i<10; i++)
				System.out.println("Suma: "+this.barrier.wait(i));
		} 
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}