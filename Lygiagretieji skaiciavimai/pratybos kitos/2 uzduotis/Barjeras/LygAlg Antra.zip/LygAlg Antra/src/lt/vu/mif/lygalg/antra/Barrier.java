package lt.vu.mif.lygalg.antra;

public class Barrier
{
    private int kvietejuSkaicius=0;
    private int tmpKvietejuSkaicius;
    private int sum;
    private int tmpSum;
    //private int tmpSum;
    private int n;
    
    public Barrier(int n) {
    	this.n = n;
    	this.sum = 0;
    }
    public synchronized Integer wait(int reiksme) throws InterruptedException
    {
    	kvietejuSkaicius++;
    	sum+=reiksme;
    	if (kvietejuSkaicius!=n)
    		wait();
    	else {
    		notifyAll();
    		tmpSum = sum;
    		sum = 0;
    		tmpKvietejuSkaicius = n;
    		kvietejuSkaicius = 0;
    	}
    	int tmpSuma = tmpSum;
    	tmpKvietejuSkaicius--;
    	if (tmpKvietejuSkaicius!=0) 
    		wait(); 
    	else {
    		notifyAll();
    		//sum = 0;
    	}		    	
    	return tmpSuma;
    }

}

