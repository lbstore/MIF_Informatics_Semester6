//package lt.vu.mif.lygalg.nqueen;

import java.util.concurrent.atomic.AtomicInteger;


public class Karalienes extends Thread {
	private int n;
	private int vietos[];
	private int stulpelis;
	private static AtomicInteger kiekVariantu = new AtomicInteger(0);
	
	public Karalienes(int n,int stulpelis, int vietos[]) {
		this.n = n;
		this.stulpelis = stulpelis;
		this.vietos = vietos;
	}
	
	private boolean arOk(int eilute, int stulpelis) {
		int tmpStulpelis = stulpelis-1;
		for(; tmpStulpelis>=1; tmpStulpelis--) {
			if ((vietos[tmpStulpelis]-eilute)==0) {
				return false;
			}
			
			int eiluciuSkirtumas = vietos[stulpelis] - vietos[tmpStulpelis];
			
			if ((eiluciuSkirtumas == stulpelis-tmpStulpelis) || 
					(eiluciuSkirtumas == tmpStulpelis-stulpelis)) {
				return false;
			}		
		}
		return true;
	}
	public void deliojam() {
		for(int i=1; i<=n ; i++ ) { //dirbam su eilute
			vietos[stulpelis] = i;
			if (arOk(i, stulpelis)) {
				if (stulpelis<n) {
					stulpelis++;
					deliojam();
					stulpelis--;
				}
				if (stulpelis==n) {
					kiekVariantu.incrementAndGet();
				}
			}	
		}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		deliojam();
	}
	
	public static int getVariantuSkaiciu() {
		return kiekVariantu.get();
	}
}
